/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: TextFile.cpp,v 1.37 2002/04/06 21:59:10 mike Exp $
 * 
 */

#include "TextFile.h"
#include "ZipFile.h"
#include "PDBFile.h"
#include "TextViewNG.h"
#include "ProgressDlg.h"
#include "Unicode.h"
#include "config.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

TextFile::TextFile(RFile *fp,CFile *savefp,const CString& name) :
  m_name(name), m_bookmarks(name), m_savefp(savefp)
{
  m_format=m_bookmarks.Format();
  m_enc=m_bookmarks.Encoding();
  if (m_format>=TextParser::GetNumFormats())
    m_format=-1;
  if (m_enc>=Unicode::GetNumCodePages())
    m_enc=-1;
  // create a buffered file for it
  m_fp=new CBufFile(auto_ptr<RFile>(fp));
  // and initialize parser
  SetFormatImp(m_format,&m_bookmarks);
  if (m_bookmarks.UserBookmarks()==0)
    m_bookmarks.LoadFromRegistry();
  m_bookmarks.NormalizeLevels();
}

void TextFile::SaveBookmarks(FilePos cur) {
  m_bookmarks.SetStartPos(cur);
  if (m_bookmarks.SaveInfo()) {
    if (!m_savefp || !m_tp.get() ||
	!(CTVApp::GetInt(_T("SaveToFiles"),DEF_SAVETOFILES)!=0) ||
	!m_tp->SaveBookmarks(m_bookmarks,*m_savefp))
      m_bookmarks.SaveToRegistry();
  }
}

void	      TextFile::SetEncoding(int enc) {
  TextParser	*np=NULL;
  CProgressDlg	dlg(Name(),AfxGetMainWnd());

  dlg.SetMax(m_fp->size());
  if (m_format<0) {
    m_fp->seek(0);
    int	  nf=TextParser::DetectFormat(m_fp.get());
    np=TextParser::Create(&dlg,m_fp.get(),nf,enc,NULL);
  } else
    np=TextParser::Create(&dlg,m_fp.get(),m_format,enc,NULL);
  if (np) {
    m_enc=enc;
    m_tp.reset(np);
    m_bookmarks.SetEncoding(enc);
  }
}

void	      TextFile::SetFormatImp(int format,Bookmarks *bmk) {
  TextParser  *np=NULL;
  CProgressDlg	  dlg(Name(),AfxGetMainWnd());

  dlg.SetMax(m_fp->size());
  if (format<0) {
    m_fp->seek(0);
    int	    nf=TextParser::DetectFormat(m_fp.get());
    np=TextParser::Create(&dlg,m_fp.get(),nf,m_enc,bmk);
  } else {
    if (m_tp.get() && format==m_tp->GetFormat()) {
      m_format=format;
      return;
    }
    np=TextParser::Create(&dlg,m_fp.get(),format,m_enc,bmk);
  }
  if (np==NULL)
    return;
  m_tp.reset(np);
  m_format=format;
  m_bookmarks.SetFormat(m_format);
}

void	      TextFile::Reparse() {
  TextParser  *np=NULL;
  CProgressDlg	  dlg(Name(),AfxGetMainWnd());

  dlg.SetMax(m_fp->size());
  int fmt=m_format<0 ? m_tp->GetFormat() : m_format;
  np=TextParser::Create(&dlg,m_fp.get(),fmt,m_enc,NULL);
  if (np==NULL)
    return;
  m_tp.reset(np);
}

const TCHAR   *TextFile::GetEncodingName(int enc) {
  return enc<0 ? _T("Auto") : Unicode::GetCodePageName(enc);
}

const TCHAR   *TextFile::GetFormatName(int format) {
  return format<0 ? _T("Auto") : TextParser::GetFormatName(format);
}

TextFile      *TextFile::Open(const CString& filename) {
  CFile		  *fp=new CFile();
  CFileException  exc;
  CString	  cur(filename);
  bool		  zip=false;
  RFile		  *rf=NULL;
  bool		  normfile=false;
  UINT		  mode;
  for (;;) {
    if ((!zip && fp->Open(cur,mode=CFile::modeReadWrite|CFile::shareDenyWrite,&exc)) ||
	fp->Open(cur,mode=CFile::modeRead|CFile::shareDenyWrite,&exc))
    {
      if (zip) { // try to decompress fp, if this is not the first try
	ZipFile	  *zf=new ZipFile(auto_ptr<CFile>(fp));
	if (!zf->ReadZip()) {
	  delete zf;
	  return NULL;
	}
	// good, now try to find the file in zip
	cur=filename.Mid(cur.GetLength());
	int   spos=cur.ReverseFind(_T('\\'));
	if (spos>=0) {
	  if (spos>0 && !zf->SetDir(cur.Left(spos))) { // no such dir
	      delete zf;
	      return NULL;
	  }
	  cur=cur.Mid(spos+1);
	}
	if (!zf->Open(cur)) { // no such file in zip
	  delete zf;
	  return NULL;
	}
	rf=zf;
      } else {
	if (PDBFile::IsPDB(*fp))
	  rf=new PDBFile(auto_ptr<CFile>(fp));
	else {
	  normfile=true;
	  rf=new RFile(auto_ptr<CFile>(fp));
	}
      }
      goto ok;
    } else { // unable to open, chop last piece
      int   spos=cur.ReverseFind(_T('\\'));
      if (spos<=0) // we failed
	break;
      cur.Delete(spos,cur.GetLength()-spos);
    }
    zip=true;
  }
  // when we get here we failed to open any prefix of filename
  delete fp;
  return NULL;
ok:{
    TextFile *tf;
    TRY {
      tf=new TextFile(rf,
	mode==(CFile::modeReadWrite|CFile::shareDenyWrite) && normfile ? fp : NULL,
	filename);
    } CATCH_ALL(e) {
      tf=NULL;
    }
    END_CATCH_ALL
    if (tf && !tf->Ok()) {
      delete tf;
      tf=NULL;
    }
    return tf;
  }
}

// these tricks are needed to distinguish between a true end of paragraph
// and position 0, which is difficult when length is also 0
int TextFile::GetPLength(int para) {
  int pl=m_tp->GetPLength(para);
  return pl==0 ? 1 : pl;
}

Paragraph TextFile::GetParagraph(int para) {
  Paragraph p(m_tp->GetParagraph(para));
  if (p.len==0) {
    p.len=1;
    p.str=Buffer<wchar_t>(1); p.str[0]=_T(' ');
    p.cflags=Buffer<Attr>(1);
    p.cflags[0].wa=0;
  }
  return p;
}
