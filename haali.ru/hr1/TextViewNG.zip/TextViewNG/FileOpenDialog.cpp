/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: FileOpenDialog.cpp,v 1.18 2002/04/20 11:21:59 mike Exp $
 * 
 */

#include "resource.h"
#include "FileOpenDialog.h"
#include "TextViewNG.h"
#include "config.h"
#include <afxcmn.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	PATH_HEIGHT 18

CString	GetFileName(CString *filepath,CWnd *parent) {
  CFileOpenDialog   dlg(parent);

  if (filepath && filepath->GetLength()>0) {
    DWORD attr=GetFileAttributes(*filepath);
    if (attr!=0xffffffff && ((attr&FILE_ATTRIBUTE_DIRECTORY) ||
	(filepath->GetLength()>4 && filepath->Right(4).CompareNoCase(_T(".zip"))==0)))
      dlg.m_path=*filepath;
  }
  int ret=dlg.DoModal();
  if (filepath)
    *filepath=dlg.m_path;
  if (ret==IDOK)
    return dlg.m_filename;
  return CString();
}

/////////////////////////////////////////////////////////////////////////////
// CFileOpenDialog dialog


CFileOpenDialog::CFileOpenDialog(CWnd* pParent /*=NULL*/)
: CDialog(CFileOpenDialog::IDD, pParent), m_path(_T("\\"))
{
  //{{AFX_DATA_INIT(CFileOpenDialog)
		// NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}


void CFileOpenDialog::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CFileOpenDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
  //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFileOpenDialog, CDialog)
//{{AFX_MSG_MAP(CFileOpenDialog)
ON_NOTIFY(LVN_ITEMACTIVATE, IDC_FILELIST, OnItemchangedFilelist)
ON_NOTIFY(LVN_KEYDOWN, IDC_FILELIST, OnKeydownFilelist)
ON_WM_SIZE()
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileOpenDialog message handlers

BOOL CFileOpenDialog::OnInitDialog()
{
  CDialog::OnInitDialog();

#if POCKETPC
  ((CCeCommandBar *)m_pWndEmptyCB)->LoadToolBar(IDR_DIALOG);
#endif

  CListCtrl *list=(CListCtrl*)GetDlgItem(IDC_FILELIST);
  if (!list)
    return TRUE;
  list->SetImageList(CTVApp::ImageList(),LVSIL_SMALL);
  // add the only column to the list
  RECT rc;
  GetClientRect(&rc);
  list->InsertColumn(0,_T("File name"),LVCFMT_LEFT,
    rc.right-rc.left-GetSystemMetrics(SM_CXVSCROLL));
#ifdef LVS_EX_ONECLICKACTIVATE
  list->SetExtendedStyle(list->GetExtendedStyle()|LVS_EX_ONECLICKACTIVATE|LVS_EX_FULLROWSELECT);
#endif
  // fill in the dialog
  DWORD	attr=GetFileAttributes(m_path);
  if (attr&FILE_ATTRIBUTE_DIRECTORY)
    FindFiles();
  else
    OpenItem(m_path);
  return TRUE;
}

#define	DIRFLAG	  0x80000000
#define	ISDIR(x)  ((x)&DIRFLAG)
#define	INDEX(x)  ((x)&~DIRFLAG)

static int   __stdcall compare_filenames(LPARAM i1,LPARAM i2,LPARAM sl) {
  CStringArray	*sa=(CStringArray*)sl;
  if (ISDIR(i1) && !ISDIR(i2))
    return -1;
  if (ISDIR(i2) && !ISDIR(i1))
    return 1;
  return sa->GetAt(INDEX(i1)).CompareNoCase(sa->GetAt(INDEX(i2)));
}

static int  get_file_icon(const TCHAR *name,bool inzip=false) {
  int	l=_tcslen(name);
  if (l<=4)
    return IM_FILE;
  if (!_tcsicmp(name+l-4,_T(".txt")) || !_tcsicmp(name+l-4,_T(".xml")) ||
      !_tcsicmp(name+l-4,_T(".prc")) || !_tcsicmp(name+l-4,_T(".pdb")))
    return IM_TEXT;
  if (!inzip && !_tcsicmp(name+l-4,_T(".zip")))
    return IM_ZIP;
  return IM_FILE;
}

void CFileOpenDialog::FindFiles()
{
  // show current path
  SetDlgItemText(IDC_FILEPATH,m_zip.get() ? m_filename : m_path);
  // fetch our control
  CListCtrl   *list=(CListCtrl*)GetDlgItem(IDC_FILELIST);
  if (!list)
    return;
  list->SendMessage(WM_SETREDRAW,0);
  // delete all files
  list->DeleteAllItems();
  // the list view control has a rather brandamaged sorting interface, so
  // we have to keep a copy of filenames only to sort the junk, even when
  // a list view has its own copy
  CStringArray	  sa;
  if (m_zip.get()) { // we are inside zip file
    bool    dir;
    CString cur;
    m_zip->Reset();
    for (int i=0;m_zip->GetNextFileInfo(cur,dir);++i) {
      list->InsertItem(LVIF_TEXT|LVIF_IMAGE|LVIF_PARAM,i,cur,0,0,
	dir?IM_DIR:get_file_icon(cur,true),sa.GetSize()|(dir ? DIRFLAG : 0));
      sa.Add(cur);
    }
  } else {
    // build a search pattern
    CString pat=m_path;
    if (pat.GetLength()==0 || pat[pat.GetLength()-1]!=_T('\\'))
      pat+=_T('\\');
    pat+=_T('*');
    // now try to find files
    WIN32_FIND_DATA   fd;
    HANDLE	    fh;
    bool		    run;
    fh=FindFirstFile(pat,&fd);
    run=fh!=INVALID_HANDLE_VALUE;
    for (int i=0;run;++i) {
      if (!(fd.cFileName[0]==_T('.') && (!fd.cFileName[1] ||
	    (fd.cFileName[1]==_T('.') && !fd.cFileName[2]))))
      {
	bool dir=(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)!=0;
	list->InsertItem(LVIF_TEXT|LVIF_IMAGE|LVIF_PARAM,i,fd.cFileName,0,0,
	  dir?IM_DIR:get_file_icon(fd.cFileName),sa.GetSize()|(dir ? DIRFLAG : 0));
	sa.Add(fd.cFileName);
      }
      run=FindNextFile(fh,&fd)!=0;
    }
    if (fh!=INVALID_HANDLE_VALUE)
      FindClose(fh);
  }
  list->SortItems(compare_filenames,(DWORD)&sa);
  if (m_path.GetLength()>1 || m_zip.get())
    list->InsertItem(LVIF_TEXT|LVIF_IMAGE|LVIF_PARAM,0,_T(".."),0,0,IM_DIR,DIRFLAG);
  list->SendMessage(WM_SETREDRAW,1);
  list->InvalidateRect(NULL);
}

void CFileOpenDialog::OnItemchangedFilelist(NMHDR* pNMHDR, LRESULT* pResult)
{
  NM_LISTVIEW	*lv = (NM_LISTVIEW*)pNMHDR;
  CListCtrl	*list=(CListCtrl*)GetDlgItem(IDC_FILELIST);
  *pResult = 0;

  if (!list)
    return;
  ActivateItem(list,lv->iItem);
}

void CFileOpenDialog::ActivateItem(CListCtrl *list, int item) {
  DWORD		info=list->GetItemData(item);

  if (ISDIR(info)) { // change dir
    CString   path=list->GetItemText(item,0);
    if (path==_T("..")) { // one level up
      int     bsp=m_path.ReverseFind(_T('\\'));
      if (bsp>0)
	m_path=m_path.Left(bsp);
      else
	m_path=_T("\\");
    } else {
      if (m_path.GetLength()>0 && m_path[m_path.GetLength()-1]!=_T('\\'))
	m_path+=_T('\\');
      m_path+=path;
    }
    if (m_zip.get() && !m_zip->SetDir(path)) // get out of this zip
      m_zip.reset();
    FindFiles();
  } else { // selected item
    m_filename=m_path;
    if (m_filename.GetLength()==0 || m_filename[m_filename.GetLength()-1]!=_T('\\'))
      m_filename+=_T('\\');
    m_filename+=list->GetItemText(item,0);
    if (!m_zip.get() && m_filename.GetLength()>4 &&
	!m_filename.Right(4).CompareNoCase(_T(".zip")))
    {
      OpenItem(m_filename);
    } else {
      if (m_zip.get())
	m_path=m_vpath;
      EndDialog(IDOK);
    }
  }
}

void CFileOpenDialog::OnKeydownFilelist(NMHDR* pNMHDR, LRESULT* pResult) 
{
  LV_KEYDOWN* key = (LV_KEYDOWN*)pNMHDR;
  CListCtrl   *list=(CListCtrl*)GetDlgItem(IDC_FILELIST);

  *pResult=0;
  if (!list)
    return;

  if (key->wVKey==VK_LEFT) {
    if (list->GetItemText(0,0)==_T(".."))
      ActivateItem(list,0);
    *pResult = 1;
  } else if (key->wVKey==VK_RIGHT) {
    int item=list->SendMessage(LVM_GETSELECTIONMARK);
    if (item>=0)
      ActivateItem(list,item);
    *pResult = 1;
  }
}

void CFileOpenDialog::OnSize(UINT nType, int cx, int cy) 
{
  CDialog::OnSize(nType, cx, cy);
  RECT	  r,rc;
  GetClientRect(&r);
  rc=r;
  rc.bottom=rc.top+PATH_HEIGHT;
  --rc.left; --rc.top; ++rc.right;
  CWnd *ctl=GetDlgItem(IDC_FILEPATH);
  if (ctl)
    ctl->MoveWindow(&rc);
  CListCtrl *list=(CListCtrl*)GetDlgItem(IDC_FILELIST);
  if (list) {
    rc=r;
    rc.top+=PATH_HEIGHT;
    list->MoveWindow(&rc);
    list->EnsureVisible(list->SendMessage(LVM_GETSELECTIONMARK),FALSE);
  }	
}

void CFileOpenDialog::OnOK() {
  CListCtrl   *list=(CListCtrl*)GetDlgItem(IDC_FILELIST);
  int	      item=list->SendMessage(LVM_GETSELECTIONMARK);
  if (item>=0)
    ActivateItem(list,item);
}

void CFileOpenDialog::OpenItem(const CString &path) { // looks like a zip file
  CFile	      *fp=new CFile;
  CFileException  ex;
  if (!fp->Open(path,CFile::modeRead|CFile::shareDenyWrite,&ex)) {
    MessageBox(_T("Can't open zip file"),_T("Error"),MB_OK|MB_ICONERROR);
    delete fp;
  } else {
    m_zip=new ZipFile(auto_ptr<CFile>(fp));
    if (!m_zip->ReadZip()) {
      MessageBox(_T("Invalid or unsupported ZIP file"),_T("Error"),MB_OK|MB_ICONERROR);
      m_zip.reset(0);
    } else {
      CString tmp;
      if (m_zip->IsSingleFile(&tmp)) {
	m_filename=path+_T("\\")+tmp;
	EndDialog(IDOK);
      } else {
	m_vpath=m_path;
	m_path=m_filename=path;
	FindFiles();
      }
    }
  }
}
