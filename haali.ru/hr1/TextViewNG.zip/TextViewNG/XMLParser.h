/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: XMLParser.h,v 1.27 2002/03/28 22:42:38 mike Exp $
 * 
 */

#if !defined(AFX_XMLPARSER_H__582B90AF_6795_4F8F_849D_100EFF8AC338__INCLUDED_)
#define AFX_XMLPARSER_H__582B90AF_6795_4F8F_849D_100EFF8AC338__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TextParser.h"
#include <afxtempl.h>
#include "FastArray.h"

class XMLParser : public TextParser  
{
protected:
  XMLParser(Meter *m,CBufFile *fp,Bookmarks *bmk,HANDLE heap);

  friend class TextParser;

  struct Frag {    // smallest element - character data
    DWORD   pos;    // offset into the file
    DWORD   len;    // raw char count
    DWORD   attr;   // attributes of this run
  };
  struct PE { // paragraph
    enum {
      FRAGBITS=10,
      MAXFRAGS=1<<FRAGBITS,
      FRAGSHIFT=32-FRAGBITS,
      IDXMASK=(1<<FRAGSHIFT)-1
    };
    DWORD	  idx_nf; // offset into m_frags
    int		  len; // parsed length
    DWORD	  linkidx_nl; // offset into m_links
    DWORD	  indent; // left and right indentation
    DWORD	  flags;
    DWORD	  nfrags() { return idx_nf>>FRAGSHIFT; }
    DWORD	  idx() { return idx_nf&IDXMASK; }
    DWORD	  nlinks() { return linkidx_nl>>FRAGSHIFT; }
    DWORD	  lidx() { return linkidx_nl&IDXMASK; }
    DWORD	  li() { return indent>>16; }
    DWORD	  ri() { return indent&0xffff; }
    void	  setidx_nf(DWORD idx,DWORD nf) { idx_nf=(idx&IDXMASK)|(nf<<FRAGSHIFT); }
    void	  setidx_nl(DWORD idx,DWORD nf) { linkidx_nl=(idx&IDXMASK)|(nf<<FRAGSHIFT); }
    void	  setindent(DWORD l,DWORD r) { indent=(l<<16)|(r&0xffff); }
    void	  Zero() { memset(this,0,sizeof(*this)); }
  };
  struct Link { // link to a note or some other object
    DWORD	  off; // offset into paragraph
    DWORD	  count; // number of chars
    int		  ref; // link target, <0 means id, not resolved yet
    DWORD	  pcount; // number of target paragraphs
  };

  CString		m_ebuf;
  FastArray<Frag>	m_frags;
  FastArray<PE>		m_pp;
  FastArray<Frag>	m_efrags;
  FastArray<PE>		m_pe;
  FastArray<Link>	m_links;
  HANDLE		m_heap;
  void			*m_parser;
  int			m_pioff;

  virtual bool		ParseFile(int encoding) = 0;
  static XMLParser	*MakeParser(Meter *m,CBufFile *fp,Bookmarks *bmk,HANDLE heap);
  Paragraph		GetParagraphImp(int idx,FastArray<PE>& pp,FastArray<Frag>& frags);
public:
  virtual ~XMLParser();

  virtual Paragraph	GetParagraph(int para);
  virtual int		Length(); // in paragraphs
  virtual int		GetPLength(int para);

  // footnotes
  virtual Paragraph	GetNoteParagraph(int note,int para);
  virtual int		GetNoteLength(int note); // in paragraphs
  virtual int		GetNotePLength(int note,int para);

  // bookmarks
  virtual bool		SaveBookmarks(Bookmarks& bmk,CFile& fp);

  // formatting details
  struct ElemFmt {
    char	fsz; //signed
    BYTE	bold;
    BYTE	italic;
    BYTE	color;
    BYTE	align;
    WORD	flags;
    int		lindent;
    int		rindent;
    CString	name;
    enum { NOCHG=127,
      ATITLE=0x01,  /* format title attribute with this style */
      PARA=0x02,    /* text container */
      NOTE=0x04,    /* formatting enclosed in [] */
      FMT=0x08,	    /* apply this style */
      ELINE=0x10,   /* add an empty line before this element */
      SPACE=0x20,   /* insert spaces between such elements */
      TITLE=0x40,   /* collect text contents and add a chapter */
      ENABLE=0x80,  /* enable P-type tags */
      LINKDEST=0x100,/* can have an id attribute */
      LINK=0x200,   /* link */
    };
    static const TCHAR	*flag_names;
  };

  typedef CArray<ElemFmt,ElemFmt&>  FmtArray; 
  static FmtArray& GetXMLStyles();

  static void	    SetStyle(bool old_setup);
  static void	    LoadStyles(bool old_setup);
  static void	    SaveStyles();
};

#endif // !defined(AFX_XMLPARSER_H__582B90AF_6795_4F8F_849D_100EFF8AC338__INCLUDED_)
