/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: TextParser.cpp,v 1.42 2002/04/06 21:59:10 mike Exp $
 * 
 */

#include <afxtempl.h>
#include <afxcmn.h>
#include "TextParser.h"
#include "XMLParser.h"
#include "Unicode.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

struct Para { // paragraph reference
  DWORD     off; // offset into file
  DWORD     len; // parsed length
  DWORD	    rlen; // raw length
};
typedef CArray<Para,Para&>  PArray;

struct SimpleFormat {
  const TCHAR		*name;
  DWORD			mask,cmp;
};

#define	MAXPLEN	4096

// soft hyphen
#define	SHY		0x00AD

// Moshkov's formatting
#define	STARTBOLD	20
#define	ENDBOLD		21

// formats list
static SimpleFormat	g_simple_formats[]={
  { _T("Line per paragraph"), 0xff, 0x0a },
  { _T("Indented first line"), 0xffff, 0x0a20 },
  { _T("MAC Line per paragraph"), 0xff, 0x0d },
  { _T("MAC Indented first line"), 0xffff, 0x0d20 }
};
#define	NUM_SIMPLE_FORMATS  (sizeof(g_simple_formats)/sizeof(g_simple_formats[0]))

class SimpleTextParser : public TextParser {
protected:
  PArray		m_pp; // paragraph list
  SimpleFormat		*m_sf;

  void	    GenericFileParse(CBufFile *fp,PArray& pp,DWORD mask,DWORD cmp);
  Paragraph GenericBufParse(CBufFile *fp,Para& p);
public:
  SimpleTextParser(Meter *m,CBufFile *fp,int format,int encoding,Bookmarks *bmk) :
      TextParser(m,fp,bmk), m_sf(&g_simple_formats[format])
  {
    m_format=format;
    m_encoding=encoding;
    if (m_encoding<0) {
      char    tmp[1024];
      DWORD   sp=m_fp->pos();
      int nb=m_fp->read(tmp,sizeof(tmp));
      m_encoding=Unicode::DetectCodePage(tmp,nb);
	  m_fp->seek(sp);
    }
    m_pp.SetSize(0,1024); // allocate in bigh chunks
    GenericFileParse(m_fp,m_pp,m_sf->mask,m_sf->cmp);
    if (bmk) {
      for (int i=0;i<Length()-1;++i)
	if ((i==0 || GetPLength(i-1)==0) && GetPLength(i+1)==0 &&
	    GetPLength(i)>0 && GetPLength(i)<90) {
	  Paragraph	  p(GetParagraph(i));
	  bmk->AddTocEnt(p.str,FilePos(i,0),0);
	}
    }
  }
  virtual int		Length() { return m_pp.GetSize(); } // in paragraphs
  virtual Paragraph	GetParagraph(int para) {
    if (para>=0 && para<m_pp.GetSize())
      return GenericBufParse(m_fp,m_pp[para]);
    return Paragraph();
  }
  virtual int		GetPLength(int para) {
    if (para<0 || para>=m_pp.GetSize())
      return 0;
    return m_pp[para].len;
  }

  // footnotes
  virtual Paragraph	GetNoteParagraph(int note,int para) { return Paragraph(); }
  virtual int		GetNoteLength(int note) { return 0; }
  virtual int		GetNotePLength(int note,int para) { return 0; }

  // bookmarks
  virtual bool		SaveBookmarks(Bookmarks& bm,CFile& fp) { return false; }
};

#define	RSPACE(x)   ((x)<=32)
#define	SPACE(x)    (RSPACE(x) || (x)==SHY)

static void Addpara(int enc,PArray& pp,Buffer<char>& b,int len,DWORD start) {
  // convert to unicode
  int		    wclen=Unicode::WCLength(enc,b,len);
  Buffer<wchar_t>   wb(wclen);
  Unicode::ToWC(enc,b,len,wb,wclen);
  // now count length
  int		    i,plen=0;
  // skip leading spaces
  for (i=0;i<wclen && SPACE(wb[i]);++i);
  // count length
  while (i<wclen) {
    // word
    while (i<wclen && !RSPACE(wb[i])) {
      if (wb[i]!=SHY)
	++plen;
      ++i;
    }
    // spaces
    while (i<wclen && SPACE(wb[i]))
      ++i;
    if (i<wclen) // this was not trailing space
      ++plen;
  }
  Para	p;
  p.len=plen;
  p.rlen=len;
  p.off=start;
  pp.Add(p);
}

void   SimpleTextParser::GenericFileParse(CBufFile *fp,PArray& pp,DWORD mask,DWORD cmp) {
  int		  ch;
  DWORD		  hist=0;
  Buffer<char>	  b(MAXPLEN);
  int		  rlen=0;
  DWORD		  start=fp->pos();
  for (;;) {
    if ((ch=fp->ch())==BEOF) {
      Addpara(m_encoding,pp,b,rlen,start);
      break;
    }
    hist=hist<<8|ch;
    if ((hist&0xffff)==0x0a0a || hist==0x0d0a0d0a || (hist&0xffff)==0x0d0d ||
	(hist&mask)==cmp || rlen>=MAXPLEN)
    {
      bool f=rlen>=MAXPLEN;
      ProgSetCur(fp->pos());
      Addpara(m_encoding,pp,b,rlen,start);
      rlen=0;
      start=m_fp->pos();
      if (f)
	b[rlen++]=ch;
    } else
      b[rlen++]=ch;
  }
}

// generic buffer parser for all simple formats
Paragraph  SimpleTextParser::GenericBufParse(CBufFile *fp,Para& p) {

  if (!p.len)
    return Paragraph();

  // read entire buffer
  Buffer<char>	  mbbuf(p.rlen);
  fp->seek(p.off);
  int		  nread=fp->read(mbbuf,p.rlen);
  ASSERT(nread==(int)p.rlen);
  // convert to unicode here
  int		  wclen=Unicode::WCLength(m_encoding,mbbuf,nread);
  Buffer<wchar_t> wcbuf(wclen);
  Unicode::ToWC(m_encoding,mbbuf,nread,wcbuf,wclen);
  // strip whitespace and soft hyphens
  Paragraph	  ret(p.len);
  wchar_t	  *bp=ret.str;
  Attr		  *cfp=ret.cflags;
  Attr		  fmt;
  DWORD		  count=0;
  int		  i;

  ret.cflags.Zero();
  fmt.wa=0;
  // skip leading spaces
  for (i=0;i<wclen && SPACE(wcbuf[i]);++i);
  // copy text
  while (i<wclen && count<p.len) {
    // copy word
    while (i<wclen && count<p.len && !RSPACE(wcbuf[i])) {
      if (wcbuf[i]!=SHY)
	bp[count++]=wcbuf[i];
      else { // handle hyphenation
	// XXX
      }
      ++i;
    }
    // skip spaces
    while (i<wclen && SPACE(wcbuf[i]))
      ++i;
    if (i<wclen && count<p.len) // not a trailing space
      bp[count++]=' ';
  }
  p.len=count; // update paragraph length
  ret.str.setsize(p.len);
  ret.len=p.len;
  return ret;
}

// XXX depends on the order of records in g_simple_formats
int		TextParser::DetectFormat(CBufFile *fp) {
  int		lines,ws,chars,check=_T('\n'),base=0;
  Buffer<BYTE>	buf(2048);
  int		nb;

  fp->seek(0);
  nb=fp->read(buf,2048);
  /* check if this is some sort of xml */
  if (nb>8 && (memcmp("<?xml",buf,5)==0 || memcmp("\xef\xbb\xbf<?xml",buf,8)==0))
    return NUM_SIMPLE_FORMATS;
  /* check if this is macintosh crap with their CR madness */
  for (chars=0;chars<nb;++chars) {
    if (buf[chars]=='\n')
      goto ok;
  }
  check='\r';
  base=2;
ok:
  /* we read first 50 lines and if more than 3 of them start with spaces,
  and there are no lines longer than 80 chars, then this a spaced format */
  int n=0;
  for (lines=ws=0;lines<50;++lines) {
    for (chars=0;;++chars) {
      if (n>=nb) {
	++lines;
	goto done;
      }
      int     ch=buf[n++];
      if (chars==0 && ch==_T(' '))
	++ws;
      if (ch==check)
	break;
    }
    if (chars>80) /* got a long line */
      return base;
  }
done:
  if (lines>10 && ws>3)
    return base+1;
  return base;
}

int		TextParser::GetNumFormats() {
  return NUM_SIMPLE_FORMATS+1;
}

const TCHAR	*TextParser::GetFormatName(int format) {
  if (format<0 || format>NUM_SIMPLE_FORMATS)
    return _T("Invalid format ID");
  if (format==NUM_SIMPLE_FORMATS)
    return _T("XML");
  return g_simple_formats[format].name;
}

TextParser	*TextParser::Create(Meter *m,CBufFile *fp,int format,int encoding,Bookmarks *bmk) {
  if (format<0)
    return NULL;
  if (format<NUM_SIMPLE_FORMATS) {
    fp->seek(0);
    return new SimpleTextParser(m,fp,format,encoding,bmk);
  }
  if (format==NUM_SIMPLE_FORMATS) {
    HANDLE    heap;

    heap=HeapCreate(HEAP_NO_SERIALIZE,1048576*4,0); // reserve up to 4 megs of ram
    if (!heap)
      return NULL;
    TRY {
      XMLParser *p=XMLParser::MakeParser(m,fp,bmk,heap);
      p->m_format=NUM_SIMPLE_FORMATS;
      if (p->ParseFile(encoding))
	return p;
      delete p;
    } CATCH_ALL(e) {
      HeapDestroy(heap);
      THROW_LAST();
    }
    END_CATCH_ALL
  }
  return NULL;
}

// hyphenation code by Mark Lipsman, modified my Mike

static BYTE   vlist[0x92]={
//0 1 2 3 4 5 6 7 8 9 a b c d e f
  0,1,0,0,1,0,1,1,0,0,0,0,0,0,1,0, // 0x400-0x40f
  1,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0, // 0x410-0x41f
  0,0,0,1,0,0,0,0,0,0,2,1,3,1,1,1, // 0x420-0x42f
  1,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0, // 0x430-0x43f
  0,0,0,1,0,0,0,0,0,0,2,1,3,1,1,1, // 0x440-0x44f
  0,1,0,0,1,0,1,1,0,0,0,0,0,0,1,0, // 0x450-0x45f
};

#define isLetter(ch)	((ch)>=0x0401 && (ch)<=0x0491)
#define isVowel(ch)	(vlist[(ch)-0x400]==1)
#define isHardSign(ch)	(vlist[(ch)-0x400]==2) 
#define isSoftSign(ch)	(vlist[(ch)-0x400]==3)
#define isConsonant(ch)	(vlist[(ch)-0x400]==0)

void  Paragraph::Hyphenate() {
  if (flags&hypdone)
    return;
  flags|=hypdone;

  DWORD		len=str.size();
  if (!len)
    return;
  const wchar_t	*s=str;
  Attr		*a=cflags;
  DWORD		start,end,i,j;

  for (start=0;start<len;) {
    // find start of word
    while (start<len && !isLetter(s[start]))
      ++start;
    // find end of word
    for (end=start+1;end<len && isLetter(s[end]);++end) ;
    // now look over word, placing hyphens
    if (end-start>3) // word must be long enough
      for (i=start;i<end-3;++i)
	if (isVowel(s[i]))
	  for (j=i+1;j<end;++j)
	    if (isVowel(s[j])) {
	      if (isConsonant(s[i+1]) && isConsonant(s[i+2]))
		++i;
	      else if (isConsonant(s[i+1]) && 
			(isHardSign(s[i+2]) || isSoftSign(s[i+2])))
		i+=2;
	      if (i-start>0)
		a[i+1].hyphen=true;
	      break;
	    }
    start=end;
  }
}