/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: ContentsDlg.cpp,v 1.24 2002/04/09 19:15:07 mike Exp $
 * 
 */

#include "resource.h"
#include "ContentsDlg.h"
#include "TextViewNG.h"
#include "config.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContentsDlg dialog


CContentsDlg::CContentsDlg(Bookmarks& toc,FilePos cur,int nump,CWnd* pParent /*=NULL*/) :
  CDialog(CContentsDlg::IDD, pParent), m_index(-1), m_toc(toc), m_cur(cur),
  m_ignore(false), m_editing(false),  m_nump(nump)
{
  //{{AFX_DATA_INIT(CContentsDlg)
  // NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}

void CContentsDlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CContentsDlg)
  // NOTE: the ClassWizard will add DDX and DDV calls here
  //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CContentsDlg, CDialog)
//{{AFX_MSG_MAP(CContentsDlg)
ON_NOTIFY(TVN_BEGINLABELEDIT, IDC_CONTENTS, OnBeginlabeledit)
ON_NOTIFY(TVN_ENDLABELEDIT, IDC_CONTENTS, OnEndlabeledit)
ON_WM_SIZE()
ON_COMMAND(ID_PP_EDIT, OnEdit)
ON_COMMAND(ID_PP_DELETE, OnDelete)
ON_NOTIFY(TVN_KEYDOWN, IDC_CONTENTS, OnKeydownContents)
ON_NOTIFY(TVN_GETDISPINFO, IDC_CONTENTS, OnGetdispinfoContents)
	ON_NOTIFY(NM_DBLCLK, IDC_CONTENTS, OnDblclkContents)
	//}}AFX_MSG_MAP
#ifdef GN_CONTEXTMENU
ON_NOTIFY(GN_CONTEXTMENU, IDC_CONTENTS, OnContextMenu)
#endif
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CContentsDlg message handlers

BOOL CContentsDlg::OnInitDialog() 
{
  CDialog::OnInitDialog();
#if POCKETPC
  ((CCeCommandBar *)m_pWndEmptyCB)->LoadToolBar(IDR_DIALOG);
#endif
  RECT	  r;
  GetClientRect(&r);
  CTreeCtrl  *tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
#ifdef TVS_FULLROWSELECT
  tree->ModifyStyle(0,TVS_FULLROWSELECT,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
#endif
  tree->MoveWindow(&r);
  tree->SetImageList(CTVApp::ImageList(),TVSIL_NORMAL);
  // insert items
  int	    curlevel=0;
  HTREEITEM curitem=TVI_ROOT;
  HTREEITEM lastitem=TVI_ROOT;
  HTREEITEM currentbp=NULL;
  int	    curpos=m_toc.BFind(m_cur,Bookmarks::SPREVCH);
  CPtrArray stack;
  for (int i=0;i<m_toc.GetSize();++i) {
    int	      lev=m_toc[i].level;
    if (lev<0)
      lev=curlevel;
    if (lev>curlevel) { // push
      stack.Add(curitem);
      curitem=lastitem;
      if (curitem!=TVI_ROOT)
	tree->SetItemImage(curitem,IM_CNODE,IM_CNODE);
    } else if (lev<curlevel) { // pop
      if (stack.GetSize()>0) { // can't really be false
	curitem=(HTREEITEM)stack[stack.GetSize()-1];
	stack.RemoveAt(stack.GetSize()-1);
      }
    }
    curlevel=lev;
    int	  img=(m_toc[i].flags&Bookmarks::BMK)?IM_BMK:IM_CLEAF;
    lastitem=tree->InsertItem(TVIF_IMAGE|TVIF_PARAM|TVIF_SELECTEDIMAGE|TVIF_TEXT,
      LPSTR_TEXTCALLBACK,img,img,0,0,i,curitem,TVI_LAST);
    if (i==curpos)
      currentbp=lastitem;
  }
  if (currentbp)
    tree->SelectItem(currentbp);
  return TRUE;
}

void CContentsDlg::OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
  TV_DISPINFO* pDispInfo = (TV_DISPINFO*)pNMHDR;
  *pResult = 1;
  if (pDispInfo->item.mask&TVIF_PARAM &&
    m_toc[pDispInfo->item.lParam].flags&Bookmarks::BMK)
  {
    m_editing=true;
    *pResult=0;
  }
}

void CContentsDlg::OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
  TV_DISPINFO* pDispInfo = (TV_DISPINFO*)pNMHDR;
  *pResult = 0;
  m_editing=false;
  CTreeCtrl   *tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
  if (!tree)
    return;
  LPARAM  idx=tree->GetItemData(pDispInfo->item.hItem);
  if (m_toc[idx].flags&Bookmarks::BMK && pDispInfo->item.pszText) {
    if (m_toc[idx].text!=pDispInfo->item.pszText) {
      m_toc.Change(idx,pDispInfo->item.pszText);
      // XXX m_toc[idx].flags|=TOCEnt::CHANGED;
    }
    *pResult=1;
  }
}

#ifdef GN_CONTEXTMENU
void CContentsDlg::OnContextMenu(NMHDR* pNMHDR, LRESULT* pResult) {
  *pResult=0;
  CTreeCtrl   *tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
  if (!tree)
    return;
  NMRGINFO	*info=(NMRGINFO*)pNMHDR;
  CPoint	pt(info->ptAction);
  tree->ScreenToClient(&pt);
  HTREEITEM	item=tree->HitTest(pt);
  if (item) {
    tree->SelectItem(item);
    int idx=tree->GetItemData(item);
    if (idx>=0 && idx<m_toc.GetSize()) {
      CMenu menu;
      menu.CreatePopupMenu();
      if (m_toc[idx].flags&Bookmarks::BMK) {
	menu.AppendMenu(MF_STRING,ID_PP_EDIT,_T("Edit"));
	menu.AppendMenu(MF_STRING,ID_PP_DELETE,_T("Delete"));
	menu.AppendMenu(MF_SEPARATOR,0);
      }
      CString tmp;
      tmp.Format(_T("At %d%%"),m_toc[idx].ref.para*100/(m_nump+1));
      menu.AppendMenu(MF_STRING|MF_GRAYED,ID_PP_INFO,tmp);
      UINT cmd=menu.TrackPopupMenu(TPM_LEFTALIGN,
	info->ptAction.x,info->ptAction.y,this);
    }
  }
}
#endif

void CContentsDlg::OnSize(UINT nType, int cx, int cy) 
{
  CDialog::OnSize(nType, cx, cy);
  CTreeCtrl	*tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
  if (tree) {
    RECT r;
    GetClientRect(&r);
    tree->MoveWindow(&r);
    tree->EnsureVisible(tree->GetSelectedItem());
  }
}

void CContentsDlg::OnEdit() {
  CTreeCtrl   *tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
  HTREEITEM	item=tree->GetSelectedItem();
  if (item) {
    int idx=tree->GetItemData(item);
    if (idx>=0 && idx<m_toc.GetSize() && m_toc[idx].flags&Bookmarks::BMK)
      tree->EditLabel(item);
  }
}

void CContentsDlg::OnDelete() 
{
  m_ignore=true;
  CTreeCtrl   *tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
  HTREEITEM   item=tree->GetSelectedItem();
  if (item) {
    int idx=tree->GetItemData(item);
    if (idx>=0 && idx<m_toc.GetSize() && m_toc[idx].flags&Bookmarks::BMK &&
      MessageBox(_T("Delete this bookmark?"),_T("Confirm"),MB_YESNO)==IDYES)
    {
      m_toc.Remove(idx); // XXX
      tree->DeleteItem(item);
    }
  }
}

void CContentsDlg::OnOK() {
  CTreeCtrl   *tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
  if (!tree)
    return;

  if (m_editing) {
    tree->SendMessage(TVM_ENDEDITLABELNOW,FALSE);
    return;
  }
  HTREEITEM item=tree->GetSelectedItem();
  if (item)
    m_index=tree->GetItemData(item);
  else // still allow OK in case we deleted _all_ bookmarks
    m_index=-1;
  EndDialog(IDOK);
}

void CContentsDlg::OnCancel() {
  CTreeCtrl   *tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
  if (!tree)
    return;

  if (m_editing) {
    tree->SendMessage(TVM_ENDEDITLABELNOW,TRUE);
    return;
  }
  m_toc.Rollback();
  EndDialog(IDCANCEL);
}

void CContentsDlg::OnKeydownContents(NMHDR* pNMHDR, LRESULT* pResult) {
  LV_KEYDOWN* vk = (LV_KEYDOWN*)pNMHDR;

  switch (vk->wVKey) {
  case VK_F2:
    OnEdit();
    break;
  case VK_DELETE:
    OnDelete();
    break;
  }
  *pResult = 0;
}

void CContentsDlg::OnGetdispinfoContents(NMHDR* pNMHDR, LRESULT* pResult) {
  TV_DISPINFO* tvi = (TV_DISPINFO*)pNMHDR;

  *pResult = 0;
  if (tvi->item.mask&TVIF_TEXT) {
    int	  idx=tvi->item.lParam;
    if (idx>=0 && idx<m_toc.GetSize()) {
      const CString	  *str=m_toc[idx].flags&Bookmarks::BMCHG ? m_toc[idx].tmp : &m_toc[idx].text;
      int	  nc=str->GetLength();
      if (nc>tvi->item.cchTextMax-1)
	nc=tvi->item.cchTextMax-1;
      memcpy(tvi->item.pszText,(const TCHAR *)*str,nc*sizeof(TCHAR));
      tvi->item.pszText[nc]=_T('\0');
      return;
    }
    tvi->item.pszText[0]=_T('\0');
  }
}

void CContentsDlg::OnDblclkContents(NMHDR* pNMHDR, LRESULT* pResult) {
  NMMOUSE   *nm=(NMMOUSE*)pNMHDR;

  *pResult = 0;

  CTreeCtrl   *tree=(CTreeCtrl*)GetDlgItem(IDC_CONTENTS);
  if (!tree)
    return;
  HTREEITEM	item=tree->GetSelectedItem();
  if (item) {
    int idx=tree->GetItemData(item);
    if (idx>=0 && idx<m_toc.GetSize()) {
      m_index=idx;
      EndDialog(IDOK);
    }
  }
}
