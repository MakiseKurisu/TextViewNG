/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: NoteDialog.cpp,v 1.2 2002/02/14 03:31:21 mike Exp $
 * 
 */

#include "resource.h"
#include "NoteDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNoteDialog dialog


CNoteDialog::CNoteDialog(CString *note,CWnd* pParent /*=NULL*/)
: CDialog(CNoteDialog::IDD, pParent), m_note(note)
{
  //{{AFX_DATA_INIT(CNoteDialog)
		// NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}


void CNoteDialog::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CNoteDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
  //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNoteDialog, CDialog)
//{{AFX_MSG_MAP(CNoteDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNoteDialog message handlers

BOOL CNoteDialog::OnInitDialog() 
{
  CDialog::OnInitDialog();
  SetDlgItemText(IDC_NOTE,*m_note);
  delete m_note;
  m_note=NULL;
  // resize the editor
  RECT rc,rword;
  GetClientRect(&rc);
  GetDlgItem(IDC_NOTE)->GetWindowRect(&rword);
  ScreenToClient(&rword);
  rword.bottom=rc.bottom;
  GetDlgItem(IDC_NOTE)->MoveWindow(&rword);
  GetDlgItem(IDC_NOTE)->SetFocus();
  SendDlgItemMessage(IDC_NOTE,EM_SETSEL);
  return FALSE;
}
