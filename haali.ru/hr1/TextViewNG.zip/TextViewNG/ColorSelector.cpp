/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: ColorSelector.cpp,v 1.6 2002/02/14 03:31:21 mike Exp $
 * 
 */

#include "resource.h"
#include "ColorSelector.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorSelector dialog


CColorSelector::CColorSelector(ColorItem *colors, CWnd* pParent /*=NULL*/)
: CDialog(CColorSelector::IDD, pParent), m_colors(colors), m_index(0)
{
  //{{AFX_DATA_INIT(CColorSelector)
  // NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}


void CColorSelector::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CColorSelector)
  // NOTE: the ClassWizard will add DDX and DDV calls here
  //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CColorSelector, CDialog)
//{{AFX_MSG_MAP(CColorSelector)
ON_WM_DRAWITEM()
ON_WM_HSCROLL()
ON_CBN_SELENDOK(IDC_COLORS, OnSelendokColors)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorSelector message handlers

void CColorSelector::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT ds)
{
  if (nIDCtl==IDC_SAMPLE) {
    SetBkColor(ds->hDC,m_colors[m_index].tempval);
    ExtTextOut(ds->hDC,ds->rcItem.left,ds->rcItem.top,ETO_OPAQUE|ETO_CLIPPED,
      &ds->rcItem,_T(""),0,NULL);
  } else
    CDialog::OnDrawItem(nIDCtl, ds);
}

void CColorSelector::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
  // Get the minimum and maximum scroll-bar positions.
  int minpos;
  int maxpos;
  pScrollBar->GetScrollRange(&minpos, &maxpos);
  maxpos = pScrollBar->GetScrollLimit();

  // Get the current position of scroll box.
  int curpos = pScrollBar->GetScrollPos();

  // Determine the new position of scroll box.
  switch (nSBCode)
  {
  case SB_LEFT:    // Scroll to far left.
    curpos = minpos;
    break;

  case SB_RIGHT:    // Scroll to far right.
    curpos = maxpos;
    break;

  case SB_ENDSCROLL:  // End scroll.
    break;

  case SB_LINELEFT:    // Scroll left.
    if (curpos > minpos)
      curpos--;
    break;

  case SB_LINERIGHT:  // Scroll right.
    if (curpos < maxpos)
      curpos++;
    break;

  case SB_PAGELEFT:   // Scroll one page left.
  {
    // Get the page size.
    SCROLLINFO  info;
    pScrollBar->GetScrollInfo(&info, SIF_ALL);

    if (curpos > minpos)
    curpos = max(minpos, curpos - (int) info.nPage);
  }
    break;

  case SB_PAGERIGHT:    // Scroll one page right.
  {
    // Get the page size.
    SCROLLINFO  info;
    pScrollBar->GetScrollInfo(&info, SIF_ALL);

    if (curpos < maxpos)
      curpos = min(maxpos, curpos + (int) info.nPage);
  }
    break;

  case SB_THUMBPOSITION: // Scroll to absolute position. nPos is the position
    curpos = nPos;      // of the scroll box at the end of the drag operation.
    break;

  case SB_THUMBTRACK:   // Drag scroll box to specified position. nPos is the
    curpos = nPos;     // position that the scroll box has been dragged to.
    break;
  }

  // Set the new position of the thumb (scroll box).
  pScrollBar->SetScrollPos(curpos);

  int	r=((CScrollBar*)GetDlgItem(IDC_RED))->GetScrollPos();
  int	g=((CScrollBar*)GetDlgItem(IDC_GREEN))->GetScrollPos();
  int	b=((CScrollBar*)GetDlgItem(IDC_BLUE))->GetScrollPos();
  if (m_colors[m_index].tempval!=RGB(r,g,b)) {
    SetColorsText();
    m_colors[m_index].tempval=RGB(r,g,b);
    GetDlgItem(IDC_SAMPLE)->Invalidate(FALSE);
  }
}

BOOL CColorSelector::OnInitDialog()
{
  CDialog::OnInitDialog();
  // init combo box
  CComboBox   *box=(CComboBox*)GetDlgItem(IDC_COLORS);
  if (box) {
    for (int i=0;m_colors[i].name;++i)
      box->AddString(m_colors[i].name);
    box->SetCurSel(0);
  }
  // init scrollbar ranges
  SCROLLINFO  si;
  si.cbSize=sizeof(si);
  si.fMask=SIF_ALL;
  si.nMin=0;
  si.nMax=255+31;
  si.nPage=32;
  // red
  si.nPos=si.nTrackPos=GetRValue(m_colors[m_index].tempval);
  ((CScrollBar*)GetDlgItem(IDC_RED))->SetScrollInfo(&si);
  // green
  si.nPos=si.nTrackPos=GetGValue(m_colors[m_index].tempval);
  ((CScrollBar*)GetDlgItem(IDC_GREEN))->SetScrollInfo(&si);
  // blue
  si.nPos=si.nTrackPos=GetBValue(m_colors[m_index].tempval);
  ((CScrollBar*)GetDlgItem(IDC_BLUE))->SetScrollInfo(&si);
  // set text
  SetColorsText();
  return TRUE;
}

bool	myChooseColors(ColorItem *colors,CWnd *parent) {
  CColorSelector    dlg(colors,parent);
  // fill in temporary values
  for (int i=0;colors[i].name;++i)
    colors[i].tempval=colors[i].value;
  if (dlg.DoModal()==IDOK) {
    bool changed=false;
    for (int j=0;colors[j].name;++j)
      if (colors[j].value!=colors[j].tempval) {
	colors[j].value=colors[j].tempval;
	colors[j].tempval=1;
	changed=true;
      }
    return changed;
  }
  return false;
}

void CColorSelector::SetColorsText() {
  SetDlgItemInt(IDC_SRED,((CScrollBar*)GetDlgItem(IDC_RED))->GetScrollPos());
  SetDlgItemInt(IDC_SGREEN,((CScrollBar*)GetDlgItem(IDC_GREEN))->GetScrollPos());
  SetDlgItemInt(IDC_SBLUE,((CScrollBar*)GetDlgItem(IDC_BLUE))->GetScrollPos());
}

void CColorSelector::OnSelendokColors() {
  int newidx=((CComboBox*)GetDlgItem(IDC_COLORS))->GetCurSel();
  if (newidx==LB_ERR || newidx==m_index)
    return;
  m_index=newidx;
  ((CScrollBar*)GetDlgItem(IDC_RED))->SetScrollPos(GetRValue(m_colors[m_index].tempval));
  ((CScrollBar*)GetDlgItem(IDC_GREEN))->SetScrollPos(GetGValue(m_colors[m_index].tempval));
  ((CScrollBar*)GetDlgItem(IDC_BLUE))->SetScrollPos(GetBValue(m_colors[m_index].tempval));
  SetColorsText();
  GetDlgItem(IDC_SAMPLE)->Invalidate(FALSE);
}
