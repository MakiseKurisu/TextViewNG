#ifndef FILEPOS_H
#define FILEPOS_H

struct FilePos {
  int	  para;
  int	  off;
  FilePos() : para(0), off(0) { }
  FilePos(int p,int o) : para(p), off(o) { }
  FilePos(const FilePos& p) : para(p.para), off(p.off) { }
  FilePos& operator=(const FilePos& p) { para=p.para; off=p.off; return *this; }
  bool operator==(int p) const { return para==p && off==0; }
  bool operator!=(int p) const { return !operator==(p); }
  bool operator==(const FilePos& p) const { return para==p.para && off==p.off; }
  bool operator!=(const FilePos& p) const { return !operator==(p); }
  bool operator<(const FilePos& p) const { return para<p.para || (para==p.para && off<p.off); }
  bool operator>(const FilePos& p) const { return !operator<(p) && !operator==(p); }
  bool operator<=(const FilePos& p) const { return operator<(p) || operator==(p); }
  bool operator>=(const FilePos& p) const { return !operator<(p); }
  FilePos operator+(int i) { return FilePos(para,off+i); }
};

#endif