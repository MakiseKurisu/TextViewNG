Dictionary file format:

   Offset Size  Field
   ------------------
Header:
   0      4     Signature 'DICT'
   4      4     LCID
   8      4     Total number of entries
   12     4     Code page
   16     4     Blocks table offset
   20     ?     Compressed blocks
   ?      ?     Blocks table
   ?      ?     Keys table
Blocks table:
   0      4     Total number of blocks
   4      16*n  Block records
Block record:
   0      4     Uncompressed size
   4      4     Compressed size
   8      4     Key length
   12     4     Number of entries in this block
Keys table:
   Keys for each block are written without gaps
