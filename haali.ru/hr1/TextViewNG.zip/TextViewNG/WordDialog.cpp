/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: WordDialog.cpp,v 1.20 2002/04/07 19:37:40 mike Exp $
 * 
 */

#include <afxext.h>

#include "resource.h"
#include "WordDialog.h"
#include "DictSetupDlg.h"
#include "TextViewNG.h"
#include "config.h"

#define	ID_FIRST_DICT	4000

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWordDialog dialog


CWordDialog::CWordDialog(const CString& word,CWnd* pParent /*=NULL*/)
: CDialog(CWordDialog::IDD, pParent), m_index(-1), m_lock(false), m_word(word),
  m_menu(NULL)
{
  //{{AFX_DATA_INIT(CWordDialog)
  // NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}

void CWordDialog::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CWordDialog)
  // NOTE: the ClassWizard will add DDX and DDV calls here
  //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWordDialog, CDialog)
//{{AFX_MSG_MAP(CWordDialog)
ON_EN_CHANGE(IDC_WORD, OnChangeWord)
ON_COMMAND(IDC_NEXTWORD,OnNextWord)
ON_COMMAND(IDC_PREVWORD,OnPrevWord)
ON_COMMAND(IDC_LOOKUP,OnLookup)
ON_COMMAND(ID_DICT_SETUP,OnConfigure)
ON_COMMAND_RANGE(ID_FIRST_DICT,ID_FIRST_DICT+CDictSetupDlg::MAXDICT-1,OnNewDict)
ON_UPDATE_COMMAND_UI_RANGE(ID_FIRST_DICT,ID_FIRST_DICT+CDictSetupDlg::MAXDICT-1,OnUpdateNewDict)
ON_COMMAND(IDC_DICT_MENU,OnDictMenu)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWordDialog message handlers

BOOL CWordDialog::OnInitDialog()
{
  CDialog::OnInitDialog();
  FetchDicts();
  OpenDict(m_word.GetLength()>0 ? -1 : m_defdict);
#if POCKETPC
  m_menu=((CCeCommandBar *)m_pWndEmptyCB)->InsertMenuBar(IDR_WORD);
#else
  m_menu=new CMenu;
  m_menu->CreatePopupMenu();
  m_menu->AppendMenu(MF_SEPARATOR);
  m_menu->AppendMenu(MF_STRING,ID_DICT_SETUP,_T("Configure..."));
#endif
  SetupMenu();
  // resize the editor
  RECT rc,rword,rw;
  GetClientRect(&rc);
  GetDlgItem(IDC_WORDDEF)->GetWindowRect(&rword);
  ScreenToClient(&rword);
  rword.bottom=rc.bottom;
  GetDlgItem(IDC_WORDDEF)->MoveWindow(&rword);
  GetDlgItem(IDC_WORD)->GetWindowRect(&rw);
  ScreenToClient(&rw);
  rw.bottom=rword.top;
#if !POCKETPC
  GetDlgItem(IDC_DICT_MENU)->GetWindowRect(&rc);
  ScreenToClient(&rc);
  rw.right=rc.left;
  GetDlgItem(IDC_DICT_MENU)->ShowWindow(SW_SHOW);
#endif
  GetDlgItem(IDC_WORD)->MoveWindow(&rw);
  SetDlgItemText(IDC_WORD,m_word);
  FillWord(false);
  return TRUE;
}

void CWordDialog::FillWord(bool changeword)
{
  if (!m_dict.get())
    return;
  m_lock=true;
  if (m_index<0) {
    int	    found;
    if (!m_dict->Find(m_word,m_index,found)) {
      if (changeword)
	SetDlgItemText(IDC_WORD,m_word);
      SetDlgItemText(IDC_WORDDEF,_T("Word not found"));
      m_lock=false;
      return;
    }
  }
  CString   def=m_dict->GetWord(m_index);
  int	    i;
  for (i=0;i<def.GetLength()-1;++i)
    if (def[i]==_T(' ') && def[i+1]==_T(' '))
      break;
  if (changeword) {
    if (i>0 && i<def.GetLength()-1)
      m_word=def.Left(i);
    else
      m_word=_T("Invalid entry");
  }
  if (changeword)
    SetDlgItemText(IDC_WORD,m_word);
  SetDlgItemText(IDC_WORDDEF,def);
  m_lock=false;
}

void CWordDialog::OnNextWord() {
  if (!m_dict.get())
    return;
  if (m_index<m_dict->NumWords()-1) {
    ++m_index;
    FillWord(true);
  }
}

void CWordDialog::OnPrevWord() {
  if (!m_dict.get())
    return;
  if (m_index>0) {
    --m_index;
    FillWord(true);
  }
}

void CWordDialog::OnLookup() {  
  if (!m_dict.get())
    return;
  int	  start,end;
  CEdit   *ed=(CEdit*)GetDlgItem(IDC_WORDDEF);
  if (ed) {
    ed->GetSel(start,end);
    if (start!=end) {
      CString	def;
      ed->GetWindowText(def);
      int idx,flag;
      if (m_dict->Find(def.Mid(start,end-start),idx,flag) && flag) {
	m_index=idx;
	FillWord(true);
      }
    }
  }
}

void CWordDialog::OnChangeWord() {
  if (m_lock || !m_dict.get())
    return;
  int idx,flag;
  GetDlgItemText(IDC_WORD,m_word);
  if (m_dict->Find(m_word,idx,flag) && flag) {
    m_index=idx;
    FillWord(false);
  } else {
    SetDlgItemText(IDC_WORDDEF,_T("Word not found"));
  }
}

void CWordDialog::FetchDicts() {
  m_av_dicts.RemoveAll();
  m_defdict=-1;
  // fetch dictionaries list
  CString   dlist=CTVApp::GetStr(_T("Dictionary"));
  for (int cur=0;cur<dlist.GetLength();) {
    int	  end=dlist.Find(_T('?'),cur);
    if (end<0)
      end=dlist.GetLength();
    if (dlist[cur]==_T('*')) {
      m_defdict=m_av_dicts.GetSize();;
      ++cur;
      if (cur>=end)
	continue;
    }
    m_av_dicts.Add(dlist.Mid(cur,end-cur));
    cur=end+1;
  }
  if (m_defdict<0 && m_av_dicts.GetSize()>0)
    m_defdict=0;
}

void  CWordDialog::OnNewDict(UINT cmd) {
  int idx=cmd-ID_FIRST_DICT;
  if (idx!=m_defdict) {
    OpenDict(idx);
    SetupMenu();
  }
}

void  CWordDialog::OnUpdateNewDict(CCmdUI *item) {
  item->Enable();
  item->SetCheck(item->m_nID-ID_FIRST_DICT==(UINT)m_defdict);
}

bool CWordDialog::OpenDict(int idx) {
  CString msg;
  if (m_av_dicts.GetSize()<=0) {
	  MessageBox(_T("Can't open dictionary: no dictionary file specified"),_T("Error"),MB_OK|MB_ICONERROR);
	  if (idx<0)
		  EndDialog(IDCANCEL);
	  return false;
  }
  IDict	  *d=IDict::Create(m_av_dicts[idx<0 ? m_defdict : idx],&msg);
  if (!d) {
    MessageBox(_T("Can't open dictionary: ")+msg,_T("Error"),MB_OK|MB_ICONERROR);
    if (idx<0)
      EndDialog(IDCANCEL);
    return false;
  }
  m_dict.reset(d);
  if (idx>=0 && idx!=m_defdict) {
    CString   dlist;
    for (int i=0;i<m_av_dicts.GetSize();++i) {
      if (i>0)
	dlist+=_T('?');
      if (i==idx)
	dlist+=_T('*');
      dlist+=m_av_dicts[i];
    }
    CTVApp::SetStr(_T("Dictionary"),dlist);
    m_defdict=idx;
  }
  return true;
}

void CWordDialog::SetupMenu() {
  if (!m_menu)
    return;
#if POCKETPC
  CMenu	*menu=m_menu->GetSubMenu(0);
  if (!menu)
    return;
#else
  CMenu *menu=m_menu;
#endif
  // remove current files
  int n=menu->GetMenuItemCount();
  int i;
  for (i=0;i<n-2;++i)
    menu->RemoveMenu(0,MF_BYPOSITION);
  // add new files
  for (i=0;i<m_av_dicts.GetSize();++i) {
    int slash=m_av_dicts[i].ReverseFind(_T('\\'));
    if (slash<0)
      slash=m_av_dicts[i].ReverseFind(_T('/'));
    menu->InsertMenu(i,MF_BYPOSITION|MF_STRING,ID_FIRST_DICT+i,
      m_av_dicts[i].Right(m_av_dicts[i].GetLength()-slash-1));
    if (i==m_defdict)
      menu->CheckMenuItem(i,MF_BYPOSITION|MF_CHECKED);
  }
}

void CWordDialog::OnConfigure() {
  CDictSetupDlg	  dlg;
  if (dlg.DoModal()==IDOK) {
    FetchDicts();
    OpenDict(m_defdict);
    SetupMenu();
  }
}

void CWordDialog::OnDictMenu() {
#if !POCKETPC
  RECT	  rc;
  GetDlgItem(IDC_DICT_MENU)->GetWindowRect(&rc);
  m_menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_TOPALIGN,rc.left,rc.bottom,this);
#endif
}