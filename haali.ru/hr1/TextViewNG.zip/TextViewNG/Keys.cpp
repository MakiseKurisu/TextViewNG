/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: Keys.cpp,v 1.6 2002/04/01 22:03:37 mike Exp $
 * 
 */

#include <afxwin.h>

#include "Keys.h"
#include "resource.h"
#include "config.h"

#define	MINHK 0xc0
#define	MAXHK 0xd0

// keys
static struct {
  const TCHAR   *name;
  UINT		cmd;
} g_actions[]={
  { _T("Line forward"),	    ID_LINE_DOWN  },
  { _T("Line backward"),    ID_LINE_UP	  },
  { _T("Page forward"),	    ID_PAGE_DOWN  },
  { _T("Page backward"),    ID_PAGE_UP	  },
  { _T("Start of file"),    ID_START_OF_FILE },
  { _T("End of file"),	    ID_END_OF_FILE },
  { _T("Toggle fullscreen"),ID_FULLSCREEN },
  { _T("Find"),		    ID_FIND	  },
  { _T("Find next"),	    ID_FINDNEXT	  },
  { _T("Contents"),	    ID_BOOKMARKS  },
  { _T("Back"),		    ID_BACK	  },
  { _T("Exit"),		    ID_APP_EXIT	  },
  { _T("Rotate"),	    ID_ROTATE	  },
  { _T("Next section/bookmark"), ID_NEXTCH },
  { _T("Previous section/bookmark"), ID_PREVCH },
  { _T("None"),		    0		  },
};
#define	NUMACTIONS    (sizeof(g_actions)/sizeof(g_actions[0]))

static struct {
  UINT	      vk;
  const TCHAR *name;
  UINT	      cmd;
} g_keys[]={
  { VK_LEFT,	_T("Left"),	ID_START_OF_FILE },
  { VK_UP,	_T("Up"),	ID_PAGE_UP },
  { VK_RIGHT,	_T("Right"),	ID_END_OF_FILE },
  { VK_DOWN,	_T("Down"),	ID_PAGE_DOWN },
  { VK_RETURN,	_T("Enter/Action"), ID_FULLSCREEN },
  { VK_SPACE,	_T("Space"),	ID_PAGE_DOWN },
  { VK_PRIOR,	_T("Page Up"),	ID_PAGE_UP },
  { VK_NEXT,	_T("PageDown"),	ID_PAGE_DOWN },
  { VK_HOME,	_T("Home"),	ID_START_OF_FILE },
  { VK_END,	_T("End"),	ID_END_OF_FILE },
};
#define	NUMKEYS	(sizeof(g_keys)/sizeof(g_keys[0]))

#define	MAXVK	256

BOOL	    (*g_UnregisterFunc1)(UINT one,UINT two);

static void GrabKey(HWND hWnd,UINT vk) {
  if (g_UnregisterFunc1)
    g_UnregisterFunc1(MOD_WIN,vk);
  RegisterHotKey(hWnd,vk,MOD_WIN,vk);
}

static void ReleaseKey(HWND hWnd,UINT vk) {
  UnregisterHotKey(hWnd,vk);
}

static const TCHAR  *GetKeyName(UINT vk) {
  for (int i=0;i<NUMKEYS;++i)
    if (g_keys[i].vk==vk)
      return g_keys[i].name;
  static TCHAR	  buf[16];
  _stprintf(buf,_T("K_%02X"),vk);
  return buf;
}

static int  GetActionId(UINT cmd) {
  for (int i=0;i<NUMACTIONS;++i)
    if (g_actions[i].cmd==cmd)
      return i;
  return NUMACTIONS-1;
}

static int	g_keymap[MAXVK];
static HWND	g_keyowner;

void Keys::InitKeys() {
  for (int i=0;i<MAXVK;++i)
    g_keymap[i]=-1;
  for (int j=0;j<NUMKEYS;++j)
    g_keymap[g_keys[j].vk]=g_keys[j].cmd;
  CString klist(AfxGetApp()->GetProfileString(_T("Keys"),_T("List")));
  int	beg=0,end;
  while (beg<klist.GetLength()) {
    for (end=beg;end<klist.GetLength() && klist[end]!=_T(',');++end);
    if (end>beg) {
      int   vk;
      if (_stscanf(klist.Mid(beg,end-beg),_T("%d"),&vk)==1) {
	int cmd=AfxGetApp()->GetProfileInt(_T("Keys"),klist.Mid(beg,end-beg),-1);
	if (vk>0 && vk<MAXVK)
	  g_keymap[vk]=cmd;
      }
    }
    beg=end;
    if (beg<klist.GetLength())
      ++beg;
  }
#ifdef _WIN32_WCE
  if (!g_UnregisterFunc1) {
    HMODULE hLib=GetModuleHandle(_T("coredll.dll"));
    if (hLib)
      g_UnregisterFunc1=(BOOL (*)(UINT,UINT))GetProcAddress(hLib,_T("UnregisterFunc1"));
  }
#endif
}

static void SaveKeys() {
  CString klist;
  for (int i=0;i<MAXVK;++i)
    if (g_keymap[i]>=0) {
      CString	tmp;
      tmp.Format(_T("%d"),i);
      if (klist.GetLength()>0)
	klist+=_T(',');
      klist+=tmp;
      AfxGetApp()->WriteProfileInt(_T("Keys"),tmp,g_keymap[i]);
    }
  AfxGetApp()->WriteProfileString(_T("Keys"),_T("List"),klist);
}

static void GrabAllKeys(HWND hWnd) {
  for (int i=MINHK;i<MAXHK;++i)
    if (g_keymap[i]>=0)
      GrabKey(hWnd,i);
}

static void ReleaseAllKeys(HWND hWnd) {
  for (int i=MINHK;i<MAXHK;++i)
    if (g_keymap[i]>=0)
      ReleaseKey(hWnd,i);
}

void Keys::SetWindow(HWND hWnd) {
  if (g_keyowner)
    ReleaseAllKeys(g_keyowner);
  g_keyowner=hWnd;
  if (g_keyowner)
    GrabAllKeys(g_keyowner);
  else {
#ifdef SPI_APPBUTTONCHANGE
  ::SendMessage(HWND_BROADCAST,WM_WININICHANGE,SPI_APPBUTTONCHANGE,0);
#endif
  }
}

bool  Keys::TranslateKey(UINT vk,UINT& cmd,int angle) {
  if (vk>=MAXVK || g_keymap[vk]<0)
    return false;
  cmd=g_keymap[vk];
  if (angle) {
    int	  idx;
    switch (vk) {
    case VK_LEFT:
      idx=0;
      break;
    case VK_UP:
      idx=1;
      break;
    case VK_RIGHT:
      idx=2;
      break;
    case VK_DOWN:
      idx=3;
      break;
    default:
      return true;
    }
    int delta;
    switch (angle) {
    case 900:
      delta=1;
      break;
    case 1800:
      delta=2;
      break;
    case 2700:
      delta=3;
      break;
    default:
      delta=0;
    }
    idx=(idx+delta)%4;
    switch (idx) {
    case 0:
      vk=VK_LEFT;
      break;
    case 1:
      vk=VK_UP;
      break;
    case 2:
      vk=VK_RIGHT;
      break;
    case 3:
      vk=VK_DOWN;
      break;
    }
    if (g_keymap[vk]<0)
      return false;
    cmd=g_keymap[vk];
  }
  return true;
}

class CKeysDlg : public CDialog
{
  // Construction
public:
  CKeysDlg(CWnd* pParent = NULL);   // standard constructor
  
  // Dialog Data
  //{{AFX_DATA(CKeysDlg)
  enum { IDD = IDD_KEYS };
  //}}AFX_DATA
  
  
  // Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CKeysDlg)
protected:
  virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
  //}}AFX_VIRTUAL
  
  // Implementation
protected:
  
  // Generated message map functions
  //{{AFX_MSG(CKeysDlg)
  virtual BOOL OnInitDialog();
  afx_msg void OnGrabkey();
  afx_msg void OnReleasekey();
  afx_msg void OnSelchangeKlist();
  afx_msg void OnSelchangeActions();
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};



CKeysDlg::CKeysDlg(CWnd* pParent /*=NULL*/)
: CDialog(CKeysDlg::IDD, pParent)
{
  //{{AFX_DATA_INIT(CKeysDlg)
  //}}AFX_DATA_INIT
}


void CKeysDlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CKeysDlg)
  //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CKeysDlg, CDialog)
//{{AFX_MSG_MAP(CKeysDlg)
ON_COMMAND(IDC_GRABK, OnGrabkey)
ON_COMMAND(IDC_RELK, OnReleasekey)
ON_LBN_SELCHANGE(IDC_KLIST, OnSelchangeKlist)
ON_CBN_SELCHANGE(IDC_ACTIONS, OnSelchangeActions)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CKeysDlg::OnInitDialog() 
{
  CDialog::OnInitDialog();
  // populate actions
  for (int i=0;i<NUMACTIONS;++i)
    SendDlgItemMessage(IDC_ACTIONS,CB_ADDSTRING,0,(LPARAM)g_actions[i].name);
  // populate keys
  int idx=0;
  int vkf=-1;
  for (int j=0;j<MAXVK;++j)
    if (g_keymap[j]>=0) {
      SendDlgItemMessage(IDC_KLIST,LB_ADDSTRING,0,(LPARAM)GetKeyName(j));
      SendDlgItemMessage(IDC_KLIST,LB_SETITEMDATA,idx,j);
      ++idx;
      if (vkf<0)
	vkf=j;
    }
  // setup selection
  if (vkf>=0)
    SendDlgItemMessage(IDC_ACTIONS,CB_SETCURSEL,GetActionId(g_keymap[vkf]));
  return TRUE;
}

class CKeyGrabDlg : public CDialog
{
  // Construction
public:
  CKeyGrabDlg(CWnd* pParent = NULL);   // standard constructor
  
  // Dialog Data
  //{{AFX_DATA(CKeyGrabDlg)
  enum { IDD = IDD_KEYGRAB };
  // NOTE: the ClassWizard will add data members here
  //}}AFX_DATA
  
  
  // Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CKeyGrabDlg)
protected:
  virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
  //}}AFX_VIRTUAL
  
  // Implementation
protected:
  
  // Generated message map functions
  //{{AFX_MSG(CKeyGrabDlg)
  virtual BOOL OnInitDialog();
  afx_msg void OnDestroy();
  //}}AFX_MSG
  afx_msg LRESULT OnHotkey(WPARAM,LPARAM);
  afx_msg void OnSettingChange(UINT,LPCTSTR);
  DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CKeyGrabDlg dialog


CKeyGrabDlg::CKeyGrabDlg(CWnd* pParent /*=NULL*/)
: CDialog(CKeyGrabDlg::IDD, pParent)
{
#if POCKETPC
  m_bFullScreen=false;
#endif
  //{{AFX_DATA_INIT(CKeyGrabDlg)
  // NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}


void CKeyGrabDlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CKeyGrabDlg)
  // NOTE: the ClassWizard will add DDX and DDV calls here
  //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CKeyGrabDlg, CDialog)
//{{AFX_MSG_MAP(CKeyGrabDlg)
ON_WM_DESTROY()
//}}AFX_MSG_MAP
ON_MESSAGE(WM_HOTKEY, OnHotkey)
#if POCKETPC
ON_WM_SETTINGCHANGE()
#endif
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeyGrabDlg message handlers

BOOL CKeyGrabDlg::OnInitDialog() {
  CDialog::OnInitDialog();
  // release all keys
  if (g_keyowner)
    ReleaseAllKeys(g_keyowner);
  // and grab all in range 0xc0-0xcf
  for (int i=MINHK;i<MAXHK;++i)
    GrabKey(m_hWnd,i);
  return TRUE;
}

void CKeyGrabDlg::OnDestroy() {
  // release keys
  for (int i=MINHK;i<MAXHK;++i)
    ReleaseKey(m_hWnd,i);
  // and regrab
  if (g_keyowner)
    GrabAllKeys(g_keyowner);
  CDialog::OnDestroy();
}

LRESULT CKeyGrabDlg::OnHotkey(WPARAM wp,LPARAM lp) {
  EndDialog(wp);
  return 0;
}

#if POCKETPC
void CKeyGrabDlg::OnSettingChange(UINT uFlags,LPCTSTR lpszSection) {
  CWnd::OnSettingChange(uFlags,lpszSection);
}
#endif

void Keys::SetupKeys(CWnd *parent) {
  CKeysDlg    dlg;
  if (dlg.DoModal()==IDOK)
    SaveKeys();
  else {
    HWND  owner=g_keyowner;
    Keys::SetWindow(0);
    Keys::InitKeys();
    Keys::SetWindow(owner);
  }
}

void CKeysDlg::OnSelchangeKlist() {
  int	idx=SendDlgItemMessage(IDC_KLIST,LB_GETCURSEL);
  if (idx==LB_ERR)
    return;
  int	vk=SendDlgItemMessage(IDC_KLIST,LB_GETITEMDATA,idx);
  if (vk==LB_ERR)
    return;
  SendDlgItemMessage(IDC_ACTIONS,CB_SETCURSEL,GetActionId(g_keymap[vk]));
}

void CKeysDlg::OnGrabkey() {
  int kc;
  {
    CKeyGrabDlg dlg;
    kc=dlg.DoModal();
  }
  if (kc>=MINHK && kc<MAXHK && g_keymap[kc]<0) {
    int	  n=SendDlgItemMessage(IDC_KLIST,LB_GETCOUNT);
    if (n==LB_ERR)
      return;
    g_keymap[kc]=0;
    SendDlgItemMessage(IDC_KLIST,LB_ADDSTRING,0,(LPARAM)GetKeyName(kc));
    SendDlgItemMessage(IDC_KLIST,LB_SETITEMDATA,n,kc);
    if (g_keyowner)
      GrabKey(g_keyowner,kc);
  }
}

void CKeysDlg::OnReleasekey() {
  int	n=SendDlgItemMessage(IDC_KLIST,LB_GETCURSEL);
  if (n==LB_ERR)
    return;
  int	vk=SendDlgItemMessage(IDC_KLIST,LB_GETITEMDATA,n);
  if (vk==LB_ERR)
    return;
  if (vk>=MINHK && vk<MAXHK) {
    g_keymap[vk]=-1;
    SendDlgItemMessage(IDC_KLIST,LB_DELETESTRING,n);
    if (g_keyowner) {
      ReleaseKey(g_keyowner,vk);
#ifdef SPI_APPBUTTONCHANGE
      ::SendMessage(HWND_BROADCAST,WM_WININICHANGE,SPI_APPBUTTONCHANGE,0);
#endif
    }
  }
}

void CKeysDlg::OnSelchangeActions() {
  int	n=SendDlgItemMessage(IDC_KLIST,LB_GETCURSEL);
  if (n==LB_ERR)
    return;
  int	vk=SendDlgItemMessage(IDC_KLIST,LB_GETITEMDATA,n);
  if (vk==LB_ERR)
    return;
  int	aid=SendDlgItemMessage(IDC_ACTIONS,CB_GETCURSEL);
  if (aid==CB_ERR)
    return;
  g_keymap[vk]=g_actions[aid].cmd;
}
