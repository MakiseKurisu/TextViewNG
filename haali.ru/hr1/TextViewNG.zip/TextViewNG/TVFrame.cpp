/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: TVFrame.cpp,v 1.52 2002/04/20 11:21:59 mike Exp $
 * 
 */

#include "TextViewNG.h"
#include "TVFrame.h"
#include "resource.h"
#include "FileOpenDialog.h"
#include "DummyView.h"
#include "XMLParser.h"
#include "WordDialog.h"
#include "Keys.h"
#include "config.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	RECENT_BASE 500
#define	RECENT_FILES  8

/////////////////////////////////////////////////////////////////////////////
// CTVFrame

IMPLEMENT_DYNAMIC(CTVFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CTVFrame, CFrameWnd)
//{{AFX_MSG_MAP(CTVFrame)
ON_WM_CREATE()
ON_WM_SETFOCUS()
ON_COMMAND(ID_FULLSCREEN, OnFullscreen)
ON_UPDATE_COMMAND_UI(ID_FULLSCREEN, OnUpdateFullscreen)
ON_WM_ACTIVATE()
ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
ON_COMMAND(ID_INIT, OnInitView)
ON_COMMAND_RANGE(RECENT_BASE,RECENT_BASE+20,OnRecentFile)
ON_UPDATE_COMMAND_UI_RANGE(RECENT_BASE,RECENT_BASE+20,OnUpdateRecentFile)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTVFrame construction/destruction

CTVFrame::CTVFrame() : m_fullscreen(false), m_in_fullscreen(0),
  m_realview(false)
{
  m_wndView=new DummyView;
  m_toptime.dwLowDateTime=m_toptime.dwHighDateTime=0;
}

CTVFrame::~CTVFrame() {
}

int CTVFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
  if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
    return -1;
  if (!m_wndView->Create(NULL, NULL, WS_VISIBLE, // XXX
    CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
  {
    TRACE0("Failed to create view window\n");
    return -1;
  }
#if POCKETPC
  m_wndCommandBar.m_bShowSharedNewButton = FALSE;
#endif

#ifdef _WIN32_WCE
  if(!m_wndCommandBar.Create(this) ||
     !m_wndCommandBar.InsertMenuBar(IDR_MAINFRAME) ||
#if !POCKETPC
     !m_wndCommandBar.InsertSeparator() ||
#endif
     !m_wndCommandBar.LoadToolBar(IDR_MAINFRAME) ||
     !m_wndCommandBar.AddAdornments())
  {
    TRACE0("Failed to create CommandBar\n");
    return -1;      // fail to create
  }

  m_wndCommandBar.SetBarStyle(m_wndCommandBar.GetBarStyle() |
    CBRS_SIZE_FIXED);
#endif

#ifdef _WIN32_WCE
  GetWindowRect(&m_normsize);
#endif

#if BE300
  HWND hSQWnd=::FindWindow(_T("SQ Tray"),NULL);
  m_fSQTray= hSQWnd && GetWindowLong(hSQWnd,GWL_STYLE)&WS_VISIBLE;
#endif

  m_recent.CreatePopupMenu();
  CMenu	  *all=GetMenu();
  if (all) {
    CMenu   *tools=all->GetSubMenu(0);
    if (tools)
      tools->InsertMenu(ID_FILE_OPEN,MF_BYCOMMAND|MF_POPUP,(UINT)m_recent.m_hMenu,_T("Recent Files"));
  }
  UpdateRecentFiles();
  return 0;
}

BOOL CTVFrame::PreCreateWindow(CREATESTRUCT& cs)
{
  if( !CFrameWnd::PreCreateWindow(cs) )
    return FALSE;

  cs.lpszClass = AfxRegisterWndClass(0);
  return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTVFrame diagnostics

#ifdef _DEBUG
void CTVFrame::AssertValid() const
{
  CFrameWnd::AssertValid();
}

void CTVFrame::Dump(CDumpContext& dc) const
{
  CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTVFrame message handlers
void CTVFrame::OnSetFocus(CWnd* pOldWnd) {
  // forward focus to the view window
  if (m_wndView.get() && m_wndView->m_hWnd)
    m_wndView->SetFocus();
}

BOOL CTVFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
  // let the view have first crack at the command
  if (m_wndView->OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
    return TRUE;

  // otherwise, do default handling
  return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CTVFrame::DoFullScreen(bool fs)
{
  if (m_in_fullscreen)
    return;
  m_in_fullscreen++;
  if (fs) {
#if POCKETPC
    SHFullScreen(m_hWnd,SHFS_HIDETASKBAR|SHFS_HIDESIPBUTTON);
#else
    HWND  hTaskBar=::FindWindow(_T("HHTaskBar"),NULL);
    if (hTaskBar)
      ::ShowWindow(hTaskBar,SW_HIDE);
#if BE300
    if (m_fSQTray) {
      hTaskBar=::FindWindow(_T("SQ Tray"),NULL);
      if (hTaskBar)
	::ShowWindow(hTaskBar,SW_HIDE);
    }
#endif
#endif
#ifdef _WIN32_WCE
    m_wndCommandBar.ShowWindow(SW_HIDE);
    ::SetWindowPos(m_hWnd,NULL,0,0,
      GetSystemMetrics(SM_CXSCREEN),
      GetSystemMetrics(SM_CYSCREEN),
      SWP_NOZORDER|SWP_NOACTIVATE);
#endif
  } else {
#if POCKETPC
    SHFullScreen(m_hWnd,SHFS_SHOWTASKBAR|SHFS_SHOWSIPBUTTON);
#else
    HWND  hTaskBar=::FindWindow(_T("HHTaskBar"),NULL);
    if (hTaskBar)
      ::ShowWindow(hTaskBar,SW_SHOW);
#if BE300
    if (m_fSQTray) {
      hTaskBar=::FindWindow(_T("SQ Tray"),NULL);
      if (hTaskBar)
	::ShowWindow(hTaskBar,SW_SHOW);
    }
#endif
#endif
#ifdef _WIN32_WCE
    m_wndCommandBar.ShowWindow(SW_SHOW);
    ::SetWindowPos(m_hWnd,NULL,
      m_normsize.left,m_normsize.top,
      m_normsize.right-m_normsize.left,m_normsize.bottom-m_normsize.top,
      SWP_NOZORDER|SWP_NOACTIVATE);
#endif
  }
  m_in_fullscreen--;
}

void CTVFrame::OnFullscreen()
{
  m_fullscreen=!m_fullscreen;
  DoFullScreen(m_fullscreen);
}

void CTVFrame::OnUpdateFullscreen(CCmdUI* pCmdUI)
{
  pCmdUI->SetCheck(m_fullscreen);
  pCmdUI->Enable();
}

void CTVFrame::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
  CFrameWnd::OnActivate(nState, pWndOther, bMinimized);
  if (nState==WA_ACTIVE || nState==WA_CLICKACTIVE) {
    DoFullScreen(m_fullscreen);
    // this hack is needed for CE 2.x and HPC 2k because I am too lazy to find out
    // what's wrong with focus setting
    if (m_wndView.get() && m_wndView->m_hWnd) { // always focus view when we are activated
      m_wndView->SetFocus();
      Keys::SetWindow(m_wndView->m_hWnd);
    }
  } else { // we should really remove fullscreen when the frame is deactivated
    // haha fun, this isnt called under emulation, so take care
    DoFullScreen(false);
    Keys::SetWindow(0);
  }
}

void CTVFrame::OnUpdateFileOpen(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTVFrame::OnFileOpen() {
  CString   ipath=CTVApp::GetStr(_T("OpenPath"));
  CString   sv=ipath;
  CString   str=GetFileName(&ipath,this);
  if (sv!=ipath)
    CTVApp::SetStr(_T("OpenPath"),ipath);
  if (str.GetLength()>0) { // selected some file
    TextFile	*tf=TextFile::Open(str);
    if (tf) {
      if (m_realview) {
	((CTView *)m_wndView.get())->SetFile(auto_ptr<TextFile>(tf));
	SetWindowText(FileName(str));
	UpdateRecentFiles();
      }
    } else {
      CString   msg;
      msg.Format(_T("Can't open file '%s'"),str);
      MessageBox(msg,_T("Error"),MB_ICONERROR|MB_OK);
    }
  }
}

bool  CTVFrame::InitView() {
  CString filename(AfxGetApp()->m_lpCmdLine);
  if (filename==_T("-d")) { // show dictionary
    CWordDialog	dlg(_T(""),this);
    dlg.DoModal();
    return false;
  }
  if (filename.GetLength()==0) // no filename provided, try to fetch most recent
    filename=Bookmarks::find_last_file();
  TextFile *tf;
  for (;;) { // repeat this until it works, or until the user chooses to exit
    if (filename.GetLength()==0) { // still no luck, open fs browser
      CString   ipath=CTVApp::GetStr(_T("OpenPath"));
      CString   sv(ipath);
      filename=GetFileName(&ipath,this);
      if (sv!=ipath)
	CTVApp::SetStr(_T("OpenPath"),ipath);
    } else if (filename.GetLength()>4 && filename.Right(4).CompareNoCase(_T(".zip"))==0) {
      CString	ipath=filename;
      CString	sv(ipath);
      filename=GetFileName(&ipath,this);
      if (sv!=ipath)
	CTVApp::SetStr(_T("OpenPath"),ipath);
    }
    if (filename.GetLength()==0) { // everything failed, barf at the user
      MessageBox(_T("No file name provided on the command line, and no recent files found."),
	_T("Error"),MB_ICONERROR|MB_OK);
      return false;
    }
    tf=TextFile::Open(filename);
    if (tf==NULL) {
      CString   msg;
      msg.Format(_T("Can't open file '%s'"),filename);
      MessageBox(msg,_T("Error"),MB_ICONERROR|MB_OK);
      filename.Empty();
    } else
      break;
  }
  // replace a dummy view with a real one
  HWND	  wnd=m_wndView->Detach();
  CTView  *tv=new CTView;
  tv->Attach(wnd);
  tv->Init();
  tv->SetFile(auto_ptr<TextFile>(tf));
  SetWindowText(FileName(filename));
  m_wndView.reset(tv);
  m_realview=true;
  UpdateRecentFiles();
  return true;
}

void CTVFrame::OnInitView() {
  if (!InitView())
    PostMessage(WM_COMMAND,ID_APP_EXIT);
}

void  CTVFrame::UpdateRecentFiles() {
  FILETIME	tm;
  m_recentlist.RemoveAll();
  Bookmarks::get_recent_files(m_recentlist,RECENT_FILES,tm);
  if (tm.dwLowDateTime!=m_toptime.dwLowDateTime || tm.dwHighDateTime!=m_toptime.dwHighDateTime) {
    m_toptime=tm;
    while (m_recent.RemoveMenu(0,MF_BYPOSITION)) ;
    for (int ii=0;ii<m_recentlist.GetSize();++ii)
      m_recent.AppendMenu(MF_STRING,RECENT_BASE+ii,FileName(m_recentlist[ii]));
    if (m_recentlist.GetSize()==0)
      m_recent.AppendMenu(MF_STRING|MF_GRAYED,1,_T("No Files"));
  }
}

void  CTVFrame::OnUpdateRecentFile(CCmdUI *pCmdUI) {
  pCmdUI->Enable();
}

void  CTVFrame::OnRecentFile(UINT cmd) {
  if (cmd-RECENT_BASE<(UINT)m_recentlist.GetSize()) {
    TextFile	*tf=TextFile::Open(m_recentlist[cmd-RECENT_BASE]);
    if (tf) {
      if (m_realview) {
	((CTView *)m_wndView.get())->SetFile(auto_ptr<TextFile>(tf));
	SetWindowText(FileName(m_recentlist[cmd-RECENT_BASE]));
	UpdateRecentFiles();
      }
    } else {
      CString   msg;
      msg.Format(_T("Can't open file '%s'"),m_recentlist[cmd-RECENT_BASE]);
      MessageBox(msg,_T("Error"),MB_ICONERROR|MB_OK);
    }
  }
}