/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: RFile.cpp,v 1.5 2002/04/09 19:55:19 mike Exp $
 * 
 */

#include "RFile.h"
#include "TextViewNG.h"

int RFile::BSZ=16384;
int RFile::BMASK=~16383;

void  RFile::InitBufSize() {
  int	rfbs=CTVApp::GetInt(_T("FileBufSize"),16384);
  if (rfbs<8192)
    rfbs=8192;
  if (rfbs>1048576)
    rfbs=1048576;
  int fbs=8192;
  while ((fbs<<1)<=rfbs)
    fbs<<=1;
  BSZ=fbs;
  BMASK=~(fbs-1);
}

CString	FileExceptionInfo(const CString& filename,const CFileException& ex) {
  CString ret;
  switch (ex.m_cause) {
  case CFileException::fileNotFound:
  case CFileException::badPath:
    ret.Format(_T("%s: File not found"),(const TCHAR *)filename);
    break;
  default:
    ret.Format(_T("%s: I/O Error"),(const TCHAR *)filename);
    break;
  }
  return ret;
}

CString	FileName(const CString& file) {
  return file.Right(file.GetLength()-max(file.ReverseFind(_T('/')),
    file.ReverseFind(_T('\\')))-1);
}