#ifndef CONFIG_H
#define CONFIG_H

#if (defined(_WIN32_WCE_PSPC) && _WIN32_WCE>=300)
#define POCKETPC 1
#endif

#if defined(_WIN32_WCE_PSPC) || BE300
#define PSPC 1
#else
#define HPC 1
#endif

// default font
#define	DEF_FACE	  _T("Tahoma")
#define	DEF_SIZE	  12
#define	DEF_BOLD	  1
#define	DEF_CLEARTYPE	  1
#define	DEF_FONTHACK	  0

// default sizes
#define	DEF_INDENT	  10
#define	DEF_MARGINS	  3
#define	DEF_BOTTOM_MARGIN 6
#define	DEF_JUSTIFY	  1
#define	DEF_ORIENTATION	  0
#define	DEF_HYPHENATE	  0
#define	DEF_COLUMNS	  1
#define DEF_SHOWPROGRESS  1

// default settings
#define	DEF_USEDICT	  1
#define	DEF_FONTCACHE	  6
#define	DEF_FBUF	  16384
#define	DEF_ROTB	  1
#define DEF_BOOKMARKS	  64
#define DEF_SAVETOFILES	  0

#define	DEF_SAVEINTERVAL  (300*1000)

#endif
