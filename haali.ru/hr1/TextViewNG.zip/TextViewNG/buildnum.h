#define BUILD_NUM 171 
#define BUILD_DATE _T("29.04.2002 04:11") 
