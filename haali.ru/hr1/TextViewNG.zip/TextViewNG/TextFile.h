/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: TextFile.h,v 1.22 2002/03/28 22:42:38 mike Exp $
 * 
 */

#if !defined(AFX_TEXTFILE_H__37F37F43_6FC5_4C70_AFBB_1187E125D777__INCLUDED_)
#define AFX_TEXTFILE_H__37F37F43_6FC5_4C70_AFBB_1187E125D777__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ptr.h"
#include "BufFile.h"
#include "TextParser.h"
#include "RFile.h"
#include "Bookmarks.h"

class TextFile
{
protected:
  TextFile(RFile *fp,CFile *savefp,const CString& name);
  void		  SetFormatImp(int format,Bookmarks *bmk);
public:
  ~TextFile() { }

  int		  Length() { return m_tp->Length(); }
  int		  ByteLength() { return m_fp->size(); }
  int		  GetPLength(int para);
  Paragraph	  GetParagraph(int para);
  int		  GetNoteLength(int note) { return m_tp->GetNoteLength(note); }
  Paragraph	  GetNoteParagraph(int note,int para) { return m_tp->GetNoteParagraph(note,para); }

  int		  GetEncoding() { return m_enc; }
  int		  GetFormat() { return m_format; }
  int		  GetRealEncoding() { return m_tp->GetEncoding(); }
  int		  GetRealFormat() { return m_tp->GetFormat(); }
  void		  SetEncoding(int enc);
  void		  SetFormat(int format) { SetFormatImp(format,NULL); }
  void		  Reparse();
  static const TCHAR *GetEncodingName(int enc);
  static const TCHAR *GetFormatName(int format);

  static TextFile *Open(const CString& filename);
  const CString&  Name() const { return m_name; }

  CString	  CompressionInfo() { return m_fp->CompressionInfo(); }

  bool		  Ok() { return m_fp.get() && m_tp.get(); }

  Bookmarks&	  bmk() { return m_bookmarks; }
  void		  SaveBookmarks(FilePos cur);
protected:
  auto_ptr<CBufFile>	m_fp;
  CFile			*m_savefp;
  auto_ptr<TextParser>  m_tp;
  int			m_enc;
  int			m_format;
  CString		m_name;
  Bookmarks		m_bookmarks;
};

#endif // !defined(AFX_TEXTFILE_H__37F37F43_6FC5_4C70_AFBB_1187E125D777__INCLUDED_)
