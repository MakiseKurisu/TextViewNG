/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: XMLParser.cpp,v 1.75 2002/04/23 20:52:29 mike Exp $
 * 
 */

#include "XMLParser.h"
#include "TextViewNG.h"
#include "expat.h"
#include "Unicode.h"

enum { CDATA=0x1000000, LEADSP=0x2000000, LOCAL=0x4000000 };
enum { MAX_CONTENTS_LEN=80 };

struct CFMT {
  Attr	  attr;
  int	  lindent;
  int	  rindent;
  BYTE	  align;
};

class XMLParserImp: public XMLParser {
public:
  XMLParserImp(Meter *m,CBufFile *fp,Bookmarks *bmk,HANDLE heap)
    : XMLParser(m,fp,bmk,heap), m_lasttocidx(-1) { }
  static void StartElement(void *udata,const wchar_t *name,const wchar_t **attr);
  static void EndElement(void *udata,const wchar_t *name);
  static void CharData(void *udata,const wchar_t *text,int len);
  static int UnknownEncoding(void *data,const wchar_t *name,XML_Encoding *info);
  static void ProcessingInstruction(void *data,const wchar_t *pi,const wchar_t *info);
  virtual bool ParseFile(int encoding);

  void			AddP(bool ex,FastArray<Frag>& l,FastArray<Link>& links,int len,CFMT& fmt);
  void			AddQ(bool ex);
  void			AddE(bool ex,const CString& name,CFMT& fmt,int level);
  void			AddF(bool ex,const CString& name,int level);
  void			AddT(bool ex,const CString& text,CFMT& fmt);
  void			SetLastTitle(const CString& str);
  void			AddToc(const CString& name,int pos,int level);

  int			m_lasttocidx;
};

const TCHAR   *XMLParser::ElemFmt::flag_names=_T("apnfestcdl");

XMLParser::XMLParser(Meter *m,CBufFile *fp,Bookmarks *bmk,HANDLE heap) :
  TextParser(m,fp,bmk), m_parser(NULL), m_heap(heap),
  m_pp(heap), m_pe(heap), m_frags(heap), m_efrags(heap), m_links(heap),
  m_pioff(-1)
{
}

XMLParser::~XMLParser() {
  // destroy parser, if any
  if (m_parser)
    XML_ParserFree((XML_Parser)m_parser);
  // destroy heap
  HeapDestroy(m_heap);
}

int	  XMLParser::Length() {
  return m_pp.GetSize();
}

#define	  SHY 0xAD

Paragraph XMLParser::GetParagraph(int para) {
  if (para<0 || para>=m_pp.GetSize() ||  m_pp[para].len==0)
    return Paragraph();
  return GetParagraphImp(para,m_pp,m_frags);
}

static int  RClamp(int v,int min,int max) {
  if (v<min)
    return min;
  if (v>max)
    return max;
  return v;
}

Paragraph XMLParser::GetParagraphImp(int idx,FastArray<PE>& pp,FastArray<Frag>& frags)
{
  // here we have to read the paragraphs from file
  int	      len=pp[idx].len,np=pp[idx].nfrags();
  int	      fragbase=pp[idx].idx();
  Paragraph   p(len);
  p.flags=(BYTE)pp[idx].flags;
  p.lindent=pp[idx].li();
  p.rindent=pp[idx].ri();
  wchar_t     *bp=p.str;
  wchar_t     *be=bp+len;
  wchar_t     *bs=bp;
  Attr	      *ap=p.cflags;
  for (int f=0;f<np && bp<be;++f) {
    Frag    *fp=&frags[f+fragbase];
    // add a space if needed
    if (fp->attr&LEADSP) {
      *bp++=_T(' ');
      (*ap++).wa=(WORD)fp->attr;
    }
    if (fp->attr&LOCAL) { // cached value
      const wchar_t   *wp=(const wchar_t *)m_ebuf+fp->pos;
      const wchar_t   *we=wp+fp->len;
      while (bp<be && wp<we) {
	*bp++=*wp++;
	(*ap++).wa=(WORD)fp->attr;
      }
    } else {
      Buffer<char>    buf(fp->len);
      m_fp->seek(fp->pos);
      if (m_fp->read(buf,fp->len)!=(int)fp->len) {
	ASSERT(0);
	break;
      }
      Buffer<wchar_t> wbuf(fp->len);
      char	    *cp=buf;
      int ul;
      if (fp->attr&CDATA)
	ul=XML_ConvertCharacterData((XML_Parser)m_parser,&cp,fp->len,wbuf,fp->len);
      else
	ul=XML_ParseCharacterData((XML_Parser)m_parser,&cp,fp->len,wbuf,fp->len);
      if (ul<0) // xml parser returned an error
	break;
      wchar_t	    *wp=wbuf,*we=wbuf+ul;
      // skip leading ws
      while (wp<we && (*wp<=32 || *wp==SHY))
	++wp;
      goto in;
      while (bp<be && wp<we) { // copy, compacting whitespace
	// add a space
	*bp++=_T(' ');
	(*ap++).wa=(WORD)fp->attr;
  in:
	// copy non-ws
	while (bp<be && wp<we && *wp>32)
	  if (*wp==SHY) {
	    if (bp>bs)
	      ap[-1].hyphen=true;
	    ++wp;
	  } else {
	    *bp++=*wp++;
	    (*ap++).wa=(WORD)fp->attr;
	  }
	// skip over spaces
	while (wp<we && (*wp<=32 || *wp==SHY))
	  ++wp;
      }
    }
  }
  p.str.setsize(bp-bs);
  // update paragraph length
  p.cflags.setsize(p.len=pp[idx].len=bp-bs);
  // copy links
  if (pp[idx].nlinks()>0) {
    int	nlinks=pp[idx].nlinks();
    DWORD off=pp[idx].lidx();
    Buffer<Paragraph::Link> links(nlinks);
    int	  dlink=0;
    for (int link=0;link<nlinks;++link) {
      links[dlink].off=m_links[off+link].off;
      links[dlink].len=m_links[off+link].count;
      if (m_links[off+link].ref<0) {
	if (m_links[off+link].ref<-1)
	  links[dlink++].target=m_links[off+link].ref+1;
      } else
	links[dlink++].target=off+link;
    }
    links.setsize(dlink);
    p.links=links;
  }
  return p;
}

int	  XMLParser::GetPLength(int para) {
  if (para<0 || para>=m_pp.GetSize())
    return 0;
  return m_pp[para].len;
}

// footnotes
Paragraph XMLParser::GetNoteParagraph(int note,int para) {
  if (note<0 || note>=m_links.GetSize() || para<0 || para>=(int)m_links[note].pcount)
    return Paragraph();
  return GetParagraphImp(para+m_links[note].ref,m_pe,m_efrags);
}

int XMLParser::GetNoteLength(int note) {
  if (note<0 || note>=m_links.GetSize())
    return 0;
  return m_links[note].pcount;
}

int XMLParser::GetNotePLength(int note,int para) {
  if (note<0 || note>=m_links.GetSize() || para<0 || para>=(int)m_links[note].pcount)
    return 0;
  return m_pe[para+m_links[note].ref].len;
}

void	  XMLParserImp::AddQ(bool ex) {
  PE	pe;
  pe.Zero();
  if (ex)
    m_pe.Add(pe);
  else
    m_pp.Add(pe);
}

void	  XMLParserImp::AddT(bool ex,const CString& text,CFMT& fmt) {
  PE	pe;
  Frag	f;
  f.attr=fmt.attr.wa|LOCAL;
  f.pos=m_ebuf.GetLength();
  f.len=text.GetLength();
  m_ebuf+=text;
  pe.setidx_nf(m_frags.GetSize(),1);
  pe.len=text.GetLength();
  pe.flags=fmt.align;
  pe.linkidx_nl=0;
  pe.setindent(RClamp(fmt.lindent,0,500),RClamp(fmt.rindent,0,500));
  if (ex) {
    m_efrags.Add(f);
    m_pe.Add(pe);
  } else {
    m_frags.Add(f);
    m_pp.Add(pe);
  }
}

void	  XMLParserImp::AddToc(const CString& name,int pos,int level) {
  if (m_bmk)
    m_lasttocidx=m_bmk->AddTocEnt(name,FilePos(pos,0),level);
}

void	  XMLParserImp::AddE(bool ex,const CString& name,CFMT& fmt,int level) {
  if (!ex && name.GetLength()>0)
    AddToc(name,m_pp.GetSize(),level);
  AddT(ex,name,fmt);
}

void	  XMLParserImp::AddF(bool ex,const CString& name,int level) {
  if (!ex && name.GetLength()>0)
    AddToc(name,m_pp.GetSize(),level);
}

void	  XMLParserImp::AddP(bool ex,FastArray<Frag>& ff,FastArray<Link>& links,int len,CFMT& fmt) {
  if (ff.GetSize()==0 || len==0)
    AddQ(ex);
  else {
    FastArray<Frag>&	frags=ex ? m_efrags : m_frags;
    FastArray<PE>&	pp=ex ? m_pe : m_pp;
    PE	pe;
    pe.setidx_nf(frags.GetSize(),ff.GetSize());
    if (!ex)
      pe.setidx_nl(m_links.GetSize(),links.GetSize());
    else
      pe.linkidx_nl=0;
    int n;
    for (n=0;n<ff.GetSize() && n<PE::MAXFRAGS;++n)
      frags.Add(ff[n]);
    if (!ex) {
      for (n=0;n<links.GetSize() && n<PE::MAXFRAGS;++n)
	m_links.Add(links[n]);
    }
    pe.len=len;
    pe.flags=fmt.align;
    pe.setindent(RClamp(fmt.lindent,0,500),RClamp(fmt.rindent,0,500));
    pp.Add(pe);
  }
}

void	XMLParserImp::SetLastTitle(const CString& s) {
  if (m_lasttocidx>=0 && m_bmk)
    m_bmk->ChangeTocEnt(m_lasttocidx,s);
}

struct UData { // user data for expat
  enum { MAX_NEST=32 };
  FastArray<XMLParser::Frag>		*save_frags;
  int					save_len;
  DWORD					save_attr;
  int					save_acch_lev;
  FastArray<XMLParser::Frag>		*frags;
  int					len; // current len
  DWORD					attr;
  FastArray<XMLParser::Link>		*links;
  DWORD					nstart;
  CFMT					cfmt;
  CFMT					attr_stack[MAX_NEST];
  int					attr_stack_ptr;
  XMLParserImp				*pp;
  XML_Parser				xp;
  int					acch_lev;
  bool					want_p,was_section,in_note;
  int					enable;
  int					skipping;
  int					section_nest;
  int					lstart,ldest;
  int					lasttocidx;
  CString				dstr;
  CString				*buf;
  CString				nname;
  CMap<int,int,int,int>			idmap;
  void PushA() {
    if (attr_stack_ptr<MAX_NEST)
      attr_stack[attr_stack_ptr++]=cfmt;
  }
  void PopA() {
    if (attr_stack_ptr>0)
      cfmt=attr_stack[--attr_stack_ptr];
  }
  DWORD Att() { return attr|cfmt.attr.wa; }
  void Collect(int unicode_len,const wchar_t *text,int size);
  UData() : idmap(512) { }
};

static void   *my_malloc(void *priv,size_t size) {
  return HeapAlloc((HANDLE)priv,HEAP_NO_SERIALIZE,size);
}

static void   *my_realloc(void *priv,void *ptr,size_t size) {
  return HeapReAlloc((HANDLE)priv,HEAP_NO_SERIALIZE,ptr,size);
}

static void   my_free(void *priv,void *ptr) {
  HeapFree((HANDLE)priv,HEAP_NO_SERIALIZE,ptr);
}

#define LOWER(c) (((c)>='A' && (c)<='Z') ? (c)+0x20 : (c))
static bool EQ(const wchar_t *s1,const wchar_t *s2) {
  while (*s1 && *s2) {
    if (LOWER(*s1)!=LOWER(*s2))
      return false;
    ++s1; ++s2;
  }
  if (*s1 || *s2)
    return false;
  return true;
}

static CString	normalize_space(const TCHAR *s,int len=-1) {
  if (len<0)
    len=_tcslen(s);
  CString ret;
  TCHAR	  *p=ret.GetBuffer(len);
  TCHAR	  *ps=p;
  const TCHAR	*e=s+len;
  while (s<e && *s<=32)
      ++s;
  goto in;
  while (s<e) {
    while (s<e && *s<=32)
      ++s;
    if (s<e)
      *p++=_T(' ');
in:
    while (s<e && *s>32)
      *p++=*s++;
  }
  ret.ReleaseBuffer(p-ps);
  return ret;
}

static inline CString	normalize_space(const CString& s) {
  return normalize_space((const TCHAR *)s,s.GetLength());
}

static int    normalized_length(const wchar_t *s,int len=-1) {
  if (len<0)
    len=wcslen(s);
  const wchar_t *e=s+len;
  int	      nl=0;
  while (s<e && *s<=32)
    ++s;
  goto in;
  while (s<e) {
    while (s<e && *s<=32)
      ++s;
    if (s<e)
      ++nl;
in:
    while (s<e && *s>32)
      ++nl,++s;
  }
  return nl;
}

void UData::Collect(int unicode_len,const wchar_t *text,int size) {
  if (dstr.GetLength()>=MAX_CONTENTS_LEN)
    return;
  int	to_copy=dstr.GetLength()+unicode_len;
  if (to_copy>MAX_CONTENTS_LEN)
    to_copy=MAX_CONTENTS_LEN;
  to_copy-=dstr.GetLength();
  if (dstr.GetLength())
    dstr+=_T(" ");
  dstr+=normalize_space(text,size).Left(to_copy);
}

static XMLParser::FmtArray	g_eformat;
static bool			g_style_type;

// element names hash
#define	EHASH_SIZE  37
static struct HE {
  HE		*next;
  wchar_t	*key;
  int		id;
}		    *g_names_hash[EHASH_SIZE];

static DWORD	hash(const wchar_t *key) {
  DWORD	  hv=0;
  while (*key)
    hv=hv*33+*key++;
  return hv+(hv>>5);
}

static HE	*hash_lookup(const wchar_t *key) {
  DWORD	  idx=hash(key)%EHASH_SIZE;
  HE	  *p;
  for (p=g_names_hash[idx];p;p=p->next)
    if (wcscmp(key,p->key)==0)
      return p;
  return NULL;
}

static HE	*hash_insert(const wchar_t *key,int len) {
  wchar_t	  *nk=new wchar_t[len+1];
  memcpy(nk,key,len*sizeof(wchar_t));
  nk[len]='\0';
  DWORD	  idx=hash(nk)%EHASH_SIZE;
  HE	  *p;
  for (p=g_names_hash[idx];p;p=p->next)
    if (wcscmp(nk,p->key)==0) {
      delete nk;
      return p;
    }
  p=new HE;
  p->id=0;
  p->key=nk;
  p->next=g_names_hash[idx];
  g_names_hash[idx]=p;
  return p;
}

static HE	*hash_insert(const char *key,int len) {
  wchar_t		*tmp=new wchar_t[len];
  for (int ii=0;ii<len;++ii)
    tmp[ii]=(unsigned char)key[ii]; // XXX
  HE  *ret=hash_insert(tmp,len);
  delete[] tmp;
  return ret;
}

static void hash_deleteall() {
  for (int i=0;i<EHASH_SIZE;++i) {
    HE	  *p,*q;
    for (p=g_names_hash[i];p;p=q) {
      q=p->next;
      delete[] p->key;
      delete p;
    }
    g_names_hash[i]=NULL;
  }
}

static struct CleanupHash {
  ~CleanupHash() { hash_deleteall(); }
} g_cleanup;

static XMLParser::ElemFmt    *LookupElem(const wchar_t *name) {
  HE	*h=hash_lookup(name);
  if (h)
    return &g_eformat[h->id];
  return &g_eformat[0]; // default
}

static void ApplyFmt(struct UData *ud,XMLParser::ElemFmt *e,int nest=0) {
  ud->PushA();
  if (e->fsz!=XMLParser::ElemFmt::NOCHG)
    ud->cfmt.attr.fsize=nest ? max(e->fsz-nest,1) : e->fsz;
  if (e->bold!=XMLParser::ElemFmt::NOCHG)
    ud->cfmt.attr.bold=e->bold;
  if (e->italic!=XMLParser::ElemFmt::NOCHG)
    ud->cfmt.attr.italic=e->italic;
  if (e->color!=XMLParser::ElemFmt::NOCHG)
    ud->cfmt.attr.color=e->color;
  if (e->align!=XMLParser::ElemFmt::NOCHG)
    ud->cfmt.align=e->align;
  if (e->lindent!=XMLParser::ElemFmt::NOCHG) {
    if (e->lindent<0)
      ud->cfmt.lindent-=e->lindent;
    else
      ud->cfmt.lindent=e->lindent;
  }
  if (e->rindent!=XMLParser::ElemFmt::NOCHG) {
    if (e->rindent<0)
      ud->cfmt.rindent-=e->rindent;
    else
      ud->cfmt.rindent=e->rindent;
  }
}

#define udp ((UData*)udata)

void XMLParserImp::StartElement(void *udata,const wchar_t *name,const wchar_t **attr) {
  if (udp->skipping) {
    udp->skipping++;
    return;
  }
  if (name[0]=='F' && !wcscmp(name,L"FictionBook"))
    LoadStyles(false);
  else if (name[0]=='C' && !wcscmp(name,L"ClearTXTeBook"))
    LoadStyles(true);
  ElemFmt	*elem=LookupElem(name);
  if (elem->flags&XMLParser::ElemFmt::NOTE && udp->in_note) {
    udp->skipping++;
    return;
  }
  if (elem->flags&XMLParser::ElemFmt::ENABLE)
    ++udp->enable;
  if (!(elem->flags&XMLParser::ElemFmt::TITLE)) {
    if (udp->was_section) {
      ElemFmt	*fmt=LookupElem(L"title"); // XXX
      ApplyFmt(udp,fmt,udp->section_nest);
      udp->pp->AddT(udp->in_note,udp->dstr,udp->cfmt);
      udp->pp->AddQ(udp->in_note);
      udp->PopA();
      udp->was_section=false;
      udp->dstr.Empty();
    }
  }
  if (elem->flags&XMLParser::ElemFmt::ATITLE) { // snag title attribute
    udp->want_p=false;
    while (*attr && !EQ(*attr,L"title"))
      attr+=2;
    if (*attr) { // this attribute must be present
      udp->dstr=normalize_space(attr[1]);
      udp->pp->AddF(udp->in_note,udp->dstr,udp->section_nest);
      udp->want_p=(bool)(udp->dstr==_T("* * *"));
    } else
      udp->dstr.Empty();
    udp->was_section=true;
    udp->section_nest++;
  }
  if (elem->flags&XMLParser::ElemFmt::ELINE) {
    if (udp->acch_lev && udp->len>0) {
      udp->pp->AddP(udp->in_note,*udp->frags,*udp->links,udp->len,udp->cfmt);
      udp->frags->RemoveAll();
      udp->links->RemoveAll();
      udp->len=0;
    }
    udp->pp->AddQ(udp->in_note);
  }
  if (udp->enable && elem->flags&XMLParser::ElemFmt::PARA &&
    !(elem->flags&XMLParser::ElemFmt::NOTE)) { // start a new paragraph
    if (udp->acch_lev && udp->len>0) {
      udp->pp->AddP(udp->in_note,*udp->frags,*udp->links,udp->len,udp->cfmt);
      udp->frags->RemoveAll();
      udp->links->RemoveAll();
      udp->len=0;
    }
    udp->attr&=~LEADSP;
    udp->acch_lev++;
  }
  if (elem->flags&XMLParser::ElemFmt::FMT) { // apply formatting
      ApplyFmt(udp,elem);
  }
  if (elem->flags&XMLParser::ElemFmt::TITLE) {
    udp->dstr.Empty();
    udp->was_section=udp->want_p=false;
  }
  if (elem->flags&XMLParser::ElemFmt::LINKDEST) { // link destination
    for (const wchar_t **p=attr;*p;p+=2)
      if (wcscmp(*p,L"id")==0) {
	int id=_wtoi(p[1]);
	if (id)
	  udp->idmap.SetAt(id,udp->pp->m_pp.GetSize());
	break;
      }
  }
  if (elem->flags&XMLParser::ElemFmt::LINK) { // link
    for (const wchar_t **p=attr;*p;p+=2)
      if (wcscmp(*p,L"ref")==0) {
	int id=_wtoi(p[1]);
	if (id) {
	  udp->lstart=udp->len;
	  udp->ldest=id;
	} else
	  udp->ldest=-1;
      }
  }
  if (elem->flags&XMLParser::ElemFmt::NOTE) { // note, goes to extra space
    // remember note name
    while (*attr) {
      if (wcscmp(*attr,L"name")==0 || wcscmp(*attr,L"NAME")==0) {
	++attr;
	udp->nname=_T('<')+normalize_space(*attr)+_T('>');
	break;
      }
      attr+=2;
    }
    udp->nstart=udp->pp->m_pe.GetSize();
    // save current context
    udp->save_frags=udp->frags;
    udp->save_len=udp->len;
    udp->save_attr=udp->attr;
    udp->save_acch_lev=udp->acch_lev;
    // initialize new context
    udp->frags=new FastArray<XMLParser::Frag>(udp->pp->m_heap,true);
    udp->len=0;
    udp->attr=0;
    udp->acch_lev=0;
    udp->in_note=true;
    if (elem->flags&XMLParser::ElemFmt::PARA) {
      udp->attr&=~LEADSP;
      udp->acch_lev++;
    }
  }
}

void XMLParserImp::EndElement(void *udata,const wchar_t *name) {
  udp->pp->ProgSetCur(XML_GetCurrentByteIndex(udp->xp));
  if (udp->skipping) {
    udp->skipping--;
    return;
  }
  ElemFmt   *elem=LookupElem(name);
  if (elem->flags&XMLParser::ElemFmt::NOTE) { //
    if (elem->flags&XMLParser::ElemFmt::PARA)
      udp->pp->AddP(udp->in_note,*udp->frags,*udp->links,udp->len,udp->cfmt);
    // restore old context
    delete udp->frags;
    udp->frags=udp->save_frags;
    udp->len=udp->save_len;
    udp->attr=udp->save_attr;
    udp->acch_lev=udp->save_acch_lev;
    udp->in_note=false;
    // and add a reference to our note
    if (udp->acch_lev) {
      XMLParser::ElemFmt  *le=LookupElem(L">link");
      if (le)
	ApplyFmt(udp,le);
      XMLParser::Frag    f;
      XMLParser::Link	  l;
      if (udp->attr&LEADSP)
	udp->len++;
      f.attr=udp->Att()|LOCAL;
      f.pos=udp->buf->GetLength();
      l.off=udp->len;
      l.count=f.len=udp->nname.GetLength();
      udp->len+=udp->nname.GetLength();
      l.ref=udp->nstart;
      l.pcount=udp->pp->m_pe.GetSize()-udp->nstart;
      *(udp->buf)+=udp->nname;
      udp->nname.Empty();
      udp->frags->Add(f);
      udp->links->Add(l);
      if (le)
	udp->PopA();
      udp->attr&=~LEADSP;
    }
  } else if (udp->enable && elem->flags&XMLParser::ElemFmt::PARA) { // end a paragraph
    udp->pp->AddP(udp->in_note,*udp->frags,*udp->links,udp->len,udp->cfmt);
    udp->frags->RemoveAll();
    if (!udp->in_note) // only touch links when in top-level P
      udp->links->RemoveAll();
    udp->len=0;
    udp->attr&=~LEADSP;
    if (udp->want_p) {
      udp->dstr.TrimRight(_T(",.-;: "));
#ifdef UNICODE
      udp->dstr+=_T("\x2026\"");
#endif
      udp->pp->SetLastTitle(_T('\"')+udp->dstr);
      udp->want_p=false;
      udp->dstr.Empty();
    }
    udp->acch_lev--;
  }
  if (elem->flags&XMLParser::ElemFmt::FMT) { // apply formatting
      udp->PopA();
  }
  if (elem->flags&XMLParser::ElemFmt::LINK) { // link
    if (udp->ldest>0) {
      XMLParser::Link   l;
      l.off=udp->lstart;
      l.count=udp->len-udp->lstart;
      l.ref=-udp->ldest;
      l.pcount=0;
      udp->links->Add(l);
    }
  }
  if (elem->flags&XMLParser::ElemFmt::ATITLE) { // snag title attribute
    if (udp->was_section) {
      ElemFmt	*fmt=LookupElem(L"title"); // XXX
      ApplyFmt(udp,fmt,udp->section_nest);
      udp->pp->AddT(udp->in_note,udp->dstr,udp->cfmt);
      udp->pp->AddQ(udp->in_note);
      udp->PopA();
      udp->was_section=false;
      udp->dstr.Empty();
    }
    udp->section_nest--;
    udp->want_p=udp->was_section=false;
  }
  if (elem->flags&XMLParser::ElemFmt::SPACE) { // add spaces after this element
    udp->attr|=LEADSP;
  }
  if (elem->flags&XMLParser::ElemFmt::TITLE) {
    udp->pp->AddQ(udp->in_note);
  }
  if (elem->flags&XMLParser::ElemFmt::ENABLE)
    --udp->enable;
}

void XMLParserImp::CharData(void *udata,const wchar_t *text,int len) {
  if (udp->skipping)
    return;
  if (udp->acch_lev && len) {
    int l=normalized_length(text,len);
    if (!l) { // whitespace frag, modify previous or completely ignore
      if (udp->frags->GetSize())
	udp->attr|=LEADSP;
      return;
    }
    if (*text<=32 && udp->frags->GetSize())
      udp->attr|=LEADSP;
    udp->len+=l;
    if (udp->attr&LEADSP)
      udp->len++;
    XMLParser::Frag    f;
    f.attr=udp->Att();
    if (l<5 || XML_IsExpanding(udp->xp)) { // cache short fragments
      f.attr|=LOCAL;
      f.pos=udp->buf->GetLength();
      f.len=l;
      *(udp->buf)+=normalize_space(text,len);
    } else {
      f.len=XML_GetCurrentByteCount(udp->xp);
      f.pos=XML_GetCurrentByteIndex(udp->xp);
    }
    udp->frags->Add(f);
    if (text[len-1]<=32)
      udp->attr|=LEADSP;
    else
      udp->attr&=~LEADSP;
    if (udp->want_p)
      udp->Collect(l,text,len);
  }
}

static void StartCData(void *udata) {
  udp->attr|=CDATA;
}

static void EndCData(void *udata) {
  udp->attr&=~CDATA;
}

int XMLParserImp::UnknownEncoding(void *data,const wchar_t *name,XML_Encoding *info) {
  int	cp=Unicode::FindCodePage(Unicode::ToCS(name,wcslen(name)));
  const wchar_t	*tab=NULL;
  if (cp>=0)
    tab=Unicode::GetTable(cp);
  if (!tab)
    return 0;
  info->data=NULL;
  info->convert=NULL;
  info->release=NULL;
  for (int i=0;i<256;++i)
    info->map[i]=tab[i];
  ((UData*)data)->pp->m_encoding=cp;
  return 1;
}

void XMLParserImp::ProcessingInstruction(void *udata,const wchar_t *pi,const wchar_t *info) {
  if (!wcscmp(pi,L"HaaliReaderSettings")) { // file position
    if (udp->pp->m_pioff<0)
      udp->pp->m_pioff=XML_GetCurrentByteIndex(udp->xp);
    FilePos   fp;
    if (udp->pp->m_bmk && swscanf(info,L"%d %d",&fp.para,&fp.off)==2)
      udp->pp->m_bmk->SetStartPos(fp);
  } else if (!wcscmp(pi,L"HaaliReaderBookmark")) {
    if (udp->pp->m_pioff<0)
      udp->pp->m_pioff=XML_GetCurrentByteIndex(udp->xp);
    if (!udp->pp->m_bmk)
      return;
    FilePos fp;
    const wchar_t    *cp=info;
    while (*cp && *cp>='0' && *cp<='9') {
      fp.para*=10;
      fp.para+=*cp-'0';
      ++cp;
    }
    if (cp==info)
      return;
    for (info=cp;*cp && *cp<=32;++cp) ;
    if (cp==info)
      return;
    for (info=cp;*cp && *cp>='0' && *cp<='9';++cp) {
      fp.off*=10;
      fp.off+=*cp-'0';
    }
    if (cp==info)
      return;
    for (info=cp;*cp && *cp<=32;++cp) ;
    if (cp==info || !*cp)
      return;
    udp->pp->m_bmk->Add(Bookmarks::unescape(cp),fp);
  }
}
#undef udp

bool	  XMLParserImp::ParseFile(int encoding) {
  XML_Memory_Handling_Suite  xmm={ my_malloc, my_realloc, my_free };
  UData	    ud;
  const TCHAR *enc;
  int	    ln;
  if (encoding>=0) {
    enc=Unicode::GetCodePageName(encoding);
    if (!enc)
      encoding=-1;
  }
  xmm.priv=(void*)m_heap;
  if (!(ud.xp=XML_ParserCreate_MM(encoding<0 ? NULL : enc,&xmm,L"|")))
    return false;
  LoadStyles(!g_style_type);
  XML_SetElementHandler(ud.xp,XMLParserImp::StartElement,XMLParserImp::EndElement);
  XML_SetCharacterDataHandler(ud.xp,XMLParserImp::CharData);
  XML_SetCdataSectionHandler(ud.xp,StartCData,EndCData);
  XML_SetUnknownEncodingHandler(ud.xp,XMLParserImp::UnknownEncoding,&ud);
  XML_SetUserData(ud.xp,&ud);
  XML_SetProcessingInstructionHandler(ud.xp,XMLParserImp::ProcessingInstruction);
  ud.want_p=ud.was_section=false;
  ud.acch_lev=ud.len=ud.attr=0;
  ud.pp=this;
  ud.buf=&m_ebuf;
  ud.cfmt.attr.wa=0;
  ud.cfmt.align=0;
  ud.cfmt.lindent=ud.cfmt.rindent=0;
  ud.attr_stack_ptr=0;
  ud.in_note=false;
  ud.skipping=ud.section_nest=0;
  ud.frags=new FastArray<Frag>(m_heap,true);
  ud.links=new FastArray<Link>(m_heap,true);
  ud.enable=0;
  m_encoding=-1;
  // now suck in the file
  m_fp->seek(0);
  for (;;) {
    void    *buf=(char*)XML_GetBuffer(ud.xp,RFile::BSZ);
    if (!buf) {
      CTVApp::Barf(_T("XML parser: Out of memory"));
      goto fail;
    }
    int	    nr=m_fp->read(buf,RFile::BSZ);
    if (!XML_ParseBuffer(ud.xp,nr,nr<RFile::BSZ)) {
      CTVApp::Barf(_T("XML parse error: %s at line %d, column %d"),
	XML_ErrorString(XML_GetErrorCode(ud.xp)),
	XML_GetCurrentLineNumber(ud.xp),XML_GetCurrentColumnNumber(ud.xp)+1);
      goto fail;
    }
    if (nr<RFile::BSZ)
      break;
  }
  // fixup links
  for (ln=0;ln<m_links.GetSize();++ln) {
    if (m_links[ln].ref<0) {
      int   pn;
      if (ud.idmap.Lookup(-m_links[ln].ref,pn))
	m_links[ln].ref=-pn-1;
      else
	m_links[ln].ref=-1;
    }
  }
  m_parser=ud.xp;
  delete ud.frags;
  delete ud.links;
  if (m_pioff<0)
    m_pioff=m_fp->pos();
  return true;
fail:
  delete ud.frags;
  delete ud.links;
  m_ebuf.Empty();
  XML_ParserFree(ud.xp);
  return false;
}

XMLParser *XMLParser::MakeParser(Meter *m,CBufFile *fp,Bookmarks *bmk,HANDLE heap) {
  return new XMLParserImp(m,fp,bmk,heap);
}

void XMLParser::SaveStyles() {
  for (int i=0;i<g_eformat.GetSize();++i)
    if (g_eformat[i].name.GetLength() && g_eformat[i].name[0]!=_T('*')) {
      CString	str;
      str.Format(_T("%d,%d,%d,%d,%d,%d,%d"),
	g_eformat[i].fsz,
	g_eformat[i].bold,
	g_eformat[i].italic,
	g_eformat[i].color,
	g_eformat[i].align,
	g_eformat[i].lindent,
	g_eformat[i].rindent);
      AfxGetApp()->WriteProfileString(_T("Styles"),g_eformat[i].name,str);
    }
}

static void SkipTillSpace(const char *& f,const char *& p,const char *e) {
  f=p;
  while (p<e && *p!=' ' && *p!='\t')
    ++p;
}

static void SkipSpace(const char *& p,const char *e) {
  while (p<e && (*p==' ' || *p=='\t'))
    ++p;
}

static void Clamp(int& v,int min,int max) {
  if (v<min)
    v=min;
  else if (v>max)
    v=max;
}

static int  GetInt(const char *p,const char *e,int min,int max,int def=XMLParser::ElemFmt::NOCHG) {
  int rv=0;
  bool sign=false;

  // skip leading space
  while (p<e && (*p==' ' || *p=='\t'))
    ++p;
  // check for *
  if (p<e && *p=='*')
    return def;
  // get an optional sign
  if (p<e && (*p=='-' || *p=='+')) {
    if (*p=='-')
      sign=true;
    ++p;
  }
  // read digits
  while (p<e && (*p>='0' && *p<='9'))
    rv=rv*10+(BYTE)(*p++-'0');
  if (sign)
    rv=-rv;
  Clamp(rv,min,max);
  return rv;
}

static int  GetFlag(const char *p,const char *e) {
  if (p<e)
    switch (*p) {
    case '+':
      return 1;
    case '-':
      return 0;
    }
  return XMLParser::ElemFmt::NOCHG;
}

static void ParseXMLSettings(const char *fmt,DWORD sz) {
  const char  *p=fmt;
  const char  *e=fmt+sz;
  const char  *le;
  const char  *field;

  while (p<e) {
    for (le=p;le<e && *le!='\r' && *le!='\n';++le) ;
    // process line here
    if (p!=le && *p!='#' && *p!=' ' && *p!='\t') {
      XMLParser::ElemFmt	fe;
      // name
      SkipTillSpace(field,p,le);
      TCHAR *buf=fe.name.GetBuffer(p-field);
      TCHAR *q=buf;
      while (field<p) {
	*q++=*field=='_' ? _T(' ') : *field;
	++field;
      }
      fe.name.ReleaseBuffer(q-buf);
      SkipSpace(p,e);
      // size
      SkipTillSpace(field,p,le);
      fe.fsz=GetInt(field,p,-100,100);
      SkipSpace(p,le);
      // bold
      SkipTillSpace(field,p,le);
      fe.bold=GetFlag(field,p);
      SkipSpace(p,le);
      // italic
      SkipTillSpace(field,p,le);
      fe.italic=GetFlag(field,p);
      SkipSpace(p,le);
      // color
      SkipTillSpace(field,p,le);
      fe.color=GetInt(field,p,0,7);
      SkipSpace(p,le);
      // align
      SkipTillSpace(field,p,le);
      if (field<p) {
	switch (*field) {
	case 'R':
	  fe.align=Paragraph::right;
	  break;
	case 'C':
	  fe.align=Paragraph::center;
	  break;
	case 'J':
	  fe.align=Paragraph::justify;
	  break;
	default:
	  fe.align=XMLParser::ElemFmt::NOCHG;
	  break;
	}
      } else
	fe.align=XMLParser::ElemFmt::NOCHG;
      SkipSpace(p,le);
      // left indent
      SkipTillSpace(field,p,le);
      fe.lindent=GetInt(field,p,-100,100);
      SkipSpace(p,le);
      // right indent
      SkipTillSpace(field,p,le);
      fe.rindent=GetInt(field,p,-100,100);
      SkipSpace(p,le);
      // action
      SkipTillSpace(field,p,le);
      fe.flags=0;
      while (field<p) {
	const TCHAR *fp=XMLParser::ElemFmt::flag_names;
	for (int flags=1;*fp;flags<<=1,++fp)
	  if (tolower(*fp)==tolower(*field)) {
	    fe.flags|=flags;
	    break;
	  }
	++field;
      }
      SkipSpace(p,le);
      // elements
      SkipTillSpace(field,p,le);
      const char  *ee;
      while (field<p) {
	for (ee=field;ee<p && *ee!=',';++ee) ;
	if (ee!=field && *field!='*') {
	  HE *he=hash_insert(field,ee-field);
	  he->id=g_eformat.GetSize();
	}
	field=ee;
	if (field<p && *field==',')
	  ++field;
      }
      // ok, insert it now
      g_eformat.Add(fe);
    }
    // skip end of line
    for (p=le;p<e && (*p=='\r' || *p=='\n');++p) ;
  }
}

void XMLParser::SetStyle(bool old_setup) {
  g_style_type=!old_setup;
}

void XMLParser::LoadStyles(bool old_setup) {
  ElemFmt ef;
  // delete all elements
  g_eformat.RemoveAll();
  hash_deleteall();
  // always initialize a default element
  ef.align=XMLParser::ElemFmt::NOCHG;
  ef.bold=XMLParser::ElemFmt::NOCHG;
  ef.color=XMLParser::ElemFmt::NOCHG;
  ef.flags=0;
  ef.fsz=XMLParser::ElemFmt::NOCHG;
  ef.italic=XMLParser::ElemFmt::NOCHG;
  ef.lindent=XMLParser::ElemFmt::NOCHG;
  ef.rindent=XMLParser::ElemFmt::NOCHG;
  g_eformat.Add(ef);
  // read parser settings from a resource
  HMODULE hMod=AfxGetResourceHandle();
  HRSRC	  hRes=FindResource(hMod,!old_setup ? _T("xml_elements") :
		_T("xml_elements.old"),RT_RCDATA);
  if (hRes) {
    DWORD   rsize=SizeofResource(hMod,hRes);
    HGLOBAL hGlob=LoadResource(hMod,hRes);
    if (hGlob) {
      void  *res=LockResource(hGlob);
      if (res) {
	ParseXMLSettings((const char *)res,rsize);
	UnlockResource(hGlob);
      }
      FreeResource(hGlob);
    }
  }
  // adjust formatting from registry
  for (int fnum=0;fnum<g_eformat.GetSize();++fnum)
    if (g_eformat[fnum].name.GetLength()>0 && g_eformat[fnum].name[0]!=_T('*')) {
      CString	str=AfxGetApp()->GetProfileString(_T("Styles"),g_eformat[fnum].name);
      int	f,b,i,c,a,li,ri;
      if (_stscanf(str,_T("%d,%d,%d,%d,%d,%d,%d"),&f,&b,&i,&c,&a,&li,&ri)==7) {
	g_eformat[fnum].fsz=f;
	g_eformat[fnum].bold=b;
	g_eformat[fnum].italic=i;
	g_eformat[fnum].color=c;
	g_eformat[fnum].align=a;
	g_eformat[fnum].lindent=li;
	g_eformat[fnum].rindent=ri;
      }
    }
}

XMLParser::FmtArray&  XMLParser::GetXMLStyles() {
  return g_eformat;
}

bool XMLParser::SaveBookmarks(Bookmarks& bmk,CFile& fp) {
  if (m_pioff<0)
    fp.SeekToEnd();
  else
    fp.Seek(m_pioff,CFile::begin);
  char	    tmp[4096];
  int	    n,j;
  n=_snprintf(tmp,sizeof(tmp),"<?HaaliReaderSettings %d %d?>\n",bmk.StartPos().para,
    bmk.StartPos().off);
  if (n<0 || n>=sizeof(tmp))
    return false;
  fp.Write(tmp,n);
  for (int i=0;i<bmk.GetSize();++i) {
    if (!(bmk[i].flags&Bookmarks::BMK))
      continue;
    CString text=Bookmarks::escape(bmk[i].text);
    n=_snprintf(tmp,sizeof(tmp),"<?HaaliReaderBookmark %d %d ",bmk[i].ref.para,
      bmk[i].ref.off);
    if (n<0 || n>=sizeof(tmp))
      continue;
    fp.Write(tmp,n);
    for (n=j=0;j<text.GetLength();++j) {
      if (n>=sizeof(tmp)) {
	fp.Write(tmp,n);
	n=0;
      }
      tmp[n++]=(char)text[j];
    }
    if (n)
      fp.Write(tmp,n);
    fp.Write("?>\n",3);
  }
  SetEndOfFile((HANDLE)fp.m_hFile);
  return true;
}
