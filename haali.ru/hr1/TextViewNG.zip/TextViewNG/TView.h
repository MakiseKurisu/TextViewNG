/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: TView.h,v 1.46 2002/04/29 00:06:34 mike Exp $
 * 
 */

#if !defined(AFX_TVIEW_H__BF90ABF1_7A00_4E3D_8E68_A4B0C27E2A62__INCLUDED_)
#define AFX_TVIEW_H__BF90ABF1_7A00_4E3D_8E68_A4B0C27E2A62__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxwin.h>
#include "ptr.h"
#include "TextFile.h"
#include "TextFormatter.h"
#include "Dictionary.h"
#include "FDC.h"

/////////////////////////////////////////////////////////////////////////////
// CTView window

#define	DEF_OLDDTD	  1

class CTView : public CWnd
{
  // Construction
public:
  CTView();
  void SetFile(auto_ptr<TextFile> tfile);

  // Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CTView)
protected:
  virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
  //}}AFX_VIRTUAL

  // Implementation
public:
  virtual ~CTView();
  void	  Init();

  // Generated message map functions
protected:
  enum {
    mLine=1,
    mPage=2,
    mFile=3,

    mFwd=0,
    mBack=1
  };
  int		  m_fontsize;
  bool		  m_bold;
  bool		  m_cleartype;
  CString	  m_fontface;
  int		  m_indent;
  int		  m_margin_width;
  auto_ptr<TextFormatter> m_formatter;
  auto_ptr<TextFile> m_textfile;
  bool		  m_justify;
  CList<FilePos,FilePos&> m_pstack;
  int		  m_width;
  int		  m_height;
  int		  m_rwidth;
  int		  m_rheight;
  FilePos	  m_matchpos;
  Buffer<wchar_t> m_searchstr;
  bool		  m_hyphenate;
  int		  m_bottom_margin;
  int		  m_columns;
  RECT		  m_cli;
  int		  m_angle;
  CPoint	  m_mouse_start,m_mouse_last,m_mouse_end;
  bool		  m_trackmouse;
  bool		  m_usedict;
  bool		  m_rotbuttons;
  bool		  m_dmove;
  bool		  m_showprogress;
  UINT		  m_timer;
  int		  m_userinp1,m_userinp2;
  int		  m_inpmode;

  void		  SetFont(const CString& face,bool bold,int size,bool cleartype);
  void		  PaintColumn(CFDC& dc,RECT& rc,RECT& cli,int& startline,int page);
  void		  SaveFont();
  void		  Move(int dir,int amount);
  void		  PushPos();
  void		  MoveAbs(FilePos pos);
  void		  MovePercent(int p);
  void		  DoFind();
  void		  CalcSizes();
  void		  ShowTOC();
  void		  ShowNote(int note);
  void		  HandleMouseDown(CPoint point);
  void		  TrackMouse();

  void		  TDrawText(HDC dc,int x,int y,const RECT& cli,
    const RECT& r,const wchar_t *p,int lp,const int *dx,int flags=ETO_OPAQUE);
  void		  TDrawLine(HDC dc,RECT& cli,RECT& rc);
  void		  ComplexLine(CFDC& dc,const RECT& cli,RECT& line,
    int x,const Line& l);
  void		  Transform(RECT& r,const RECT& cli);
  void		  Transform(POINT& pt,const RECT& cli);
  void		  RevTransform(POINT& pt,const RECT& cli);
  bool		  LookupAddr(const POINT& pt,FilePos& p);
  void		  CalcSelection(FilePos& p,int& len,int& pl);
  bool		  GetSelText(CString& str);
  void		  SaveInfo();

  //{{AFX_MSG(CTView)
  afx_msg void OnPaint();
  afx_msg void OnSize(UINT nType, int cx, int cy);
  afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
  afx_msg BOOL OnEraseBkgnd(CDC* pDC);
  afx_msg void OnAppAbout();
  afx_msg void OnUpdateOptions(CCmdUI* pCmdUI);
  afx_msg void OnOptions();
  afx_msg void OnUpdateFileformat(CCmdUI* pCmdUI);
  afx_msg void OnFileformat();
  afx_msg void OnUpdateBack(CCmdUI* pCmdUI);
  afx_msg void OnBack();
  afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
  afx_msg void OnDictSetup();
  afx_msg void OnUpdateDictSetup(CCmdUI* pCmdUI);
  afx_msg void OnUpdateFind(CCmdUI* pCmdUI);
  afx_msg void OnFind();
  afx_msg void OnFindnext();
  afx_msg void OnUpdateFindnext(CCmdUI* pCmdUI);
  afx_msg void OnUpdateColors(CCmdUI* pCmdUI);
  afx_msg void OnColors();
  afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
  afx_msg void OnAddBmk();
  afx_msg void OnUpdateAddBmk(CCmdUI* pCmdUI);
  afx_msg void OnBookmarks();
  afx_msg void OnUpdateBookmarks(CCmdUI* pCmdUI);
  afx_msg void OnLineUp();
  afx_msg void OnLineDown();
  afx_msg void OnPageUp();
  afx_msg void OnPageDown();
  afx_msg void OnStartFile();
  afx_msg void OnEndFile();
  afx_msg void OnKeys();
  afx_msg void OnUpdateKeys(CCmdUI* pCmdUI);
  afx_msg void OnDestroy();
  afx_msg void OnStyles();
  afx_msg void OnUpdateStyles(CCmdUI* pCmdUI);
  afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
  afx_msg void OnMouseMove(UINT nFlags, CPoint point);
  afx_msg void OnMiscopt();
  afx_msg void OnUpdateMiscopt(CCmdUI* pCmdUI);
  afx_msg void OnEditCopy();
  afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
  afx_msg void OnRotate();
  afx_msg void OnTimer(UINT nIDEvent);
  afx_msg void OnUpdateGoto(CCmdUI* pCmdUI);
  afx_msg void OnGoto();
  afx_msg void OnNextSection();
  afx_msg void OnPrevSection();
  afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
  //}}AFX_MSG
  afx_msg LRESULT OnHotkey(WPARAM,LPARAM);
  DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TVIEW_H__BF90ABF1_7A00_4E3D_8E68_A4B0C27E2A62__INCLUDED_)
