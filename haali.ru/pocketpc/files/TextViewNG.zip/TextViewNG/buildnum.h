#define BUILD_NUM 264 
#define BUILD_DATE _T("02.04.2007 06:10") 
