/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: Dictionary.cpp,v 1.18 2002/04/06 22:18:02 mike Exp $
 * 
 */

#include "Dictionary.h"
#include "ptr.h"
#include "zlib.h"
#include "Unicode.h"
#include "RFile.h"

#include <afxtempl.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

class Dict : public IDict
{
public:
  Dict(CFile *fp);
  ~Dict() { delete m_fp; }

  int	  NumWords() { return m_numwords; }
  CString GetWord(int index);
  bool	  Find(const CString& word,int& index,int& found);
  bool	  Valid() { return m_ok; }
protected:
  struct Block {
    Buffer<char>  key;	    /* key */
    int		wordidx;    /* first word index */
    int		numwords;   /* number of words in this block */
    int		size;	    /* uncompressed block size */
    int		csize;	    /* compressed size */
    int		off;	    /* offset in the file */
  };

  CFile			*m_fp;
  DWORD			m_numblk;
  DWORD			m_numwords;
  int			m_curblk;
  CPtrArray		m_windex; // words in current block
  CPtrArray		m_kindex; // keys
  Buffer<char>		m_buffer;
  CArray<Block,Block&>	m_blocks;
  bool			m_ok;
  LCID			m_lcid;
  UINT			m_ms_codepage;
  int			m_codepage;

  bool	      GetBlk(int num);
  const char  *GetWordImp(int index);
  bool	      OpenOld();
  bool	      OpenNew();
};

static DWORD    getdword(CFile *fp) {
  BYTE	  b[4];
  int	  rd=fp->Read(b,4);
  if (rd!=4)
    return 0;
  return ((DWORD)b[3]<<24)|((DWORD)b[2]<<16)|((DWORD)b[1])<<8|b[0];
}

bool Dict::OpenNew() {
  if ((m_lcid=getdword(m_fp))==0)
    return false;
  if (!IsValidLocale(m_lcid,LCID_INSTALLED))
    m_lcid=GetUserDefaultLCID();
  if ((m_numwords=getdword(m_fp))==0)
    return false;
  if ((m_ms_codepage=getdword(m_fp))==0)
    return false;
  if ((m_codepage=Unicode::GetIntCodePage(m_ms_codepage))<0)
    m_codepage=Unicode::DefaultCodePage();
  DWORD	btab=getdword(m_fp);
  if (btab==0)
    return false;
  m_fp->Seek(btab,CFile::begin);
  if ((m_numblk=getdword(m_fp))==0 || m_numblk>m_numwords)
    return false;
  DWORD idx,i,off,maxblock;
  for (i=idx=maxblock=0,off=20;i<(int)m_numblk;++i) {
    Block   blk;
    int	    keylen;
    if ((blk.size=getdword(m_fp))==0)
      return false;
    if ((blk.csize=getdword(m_fp))==0)
      return false;
    if ((keylen=getdword(m_fp))==0)
      return false;
    if ((blk.numwords=getdword(m_fp))==0)
      return false;
    blk.wordidx=idx;
    blk.off=off;
    idx+=blk.numwords;
    off+=blk.csize;
    blk.key=Buffer<char>(keylen);
    m_blocks.Add(blk);
    if (blk.size>(int)maxblock)
      maxblock=blk.size;
  }
  if (idx!=m_numwords)
    return false;
  for (i=0;i<(int)m_numblk;++i)
    if ((m_fp->Read(m_blocks[i].key,m_blocks[i].key.size()))!=(DWORD)m_blocks[i].key.size())
      return false;
  m_buffer=Buffer<char>(maxblock);
  return true;
}

Dict::Dict(CFile *fp) :
  m_ok(false), m_numwords(0), m_numblk(0), m_curblk(-1), m_fp(fp)
{
  if (!OpenNew())
      goto fail;
  m_ok=true;
  return;
fail:
  m_fp->Abort();
  m_buffer=Buffer<char>();
  m_blocks.RemoveAll();
}

bool  Dict::GetBlk(int num) {
  if (num<0 || num>=(int)m_numblk)
    return false;
  if (m_curblk==num)
    return true;
  m_curblk=-1;
  m_fp->Seek(m_blocks[num].off,CFile::begin);
  if (m_blocks[num].size==m_blocks[num].csize) { // uncompressed
    if (m_blocks[num].size!=(int)m_fp->Read(m_buffer,m_blocks[num].size))
      return false;
  } else {
    Buffer<unsigned char>    in(m_blocks[num].csize);
    if (m_blocks[num].csize!=(int)m_fp->Read(in,m_blocks[num].csize))
      return false;
    uLongf  len=m_blocks[num].size;
    int ret=uncompress((unsigned char *)(char *)m_buffer,&len,
      in,m_blocks[num].csize);
    if (ret!=Z_OK || (int)len!=m_blocks[num].size)
      return false;
  }
  char	  *p=m_buffer;
  char	  *e=p+m_blocks[num].size;
  int	  i;
  m_windex.SetSize(m_blocks[num].numwords);
  m_kindex.SetSize(m_blocks[num].numwords);
  for (i=0;i<m_blocks[num].numwords && p<e;++i) {
    m_kindex[i]=p;
    while (p<e && *p)
      ++p;
    if (p<e)
      ++p;
    m_windex[i]=p;
    while (p<e && *p)
      ++p;
    if (p<e)
      ++p;
  }
  if (i!=m_blocks[num].numwords)
    return false;
  m_curblk=num;
  return true;
}

CString Dict::GetWord(int index) {
  const char  *word=GetWordImp(index);
  if (!word)
    return CString();
  CString   tmp(Unicode::ToCS(m_codepage,word,strlen(word)));
  // count newlines
  int	      nl_count=0,wclen=tmp.GetLength();
  for (int i=0;i<wclen;++i)
    if (tmp[i]=='\n')
      ++nl_count;
  CString	  ret;
  TCHAR	  *bp=ret.GetBuffer(wclen+nl_count);
  TCHAR	  *be=bp+wclen+nl_count;
  const TCHAR	*p=tmp;
  while (bp<be) {
    if (*p=='\n') {
      *bp++='\r';
      if (bp>=be)
	break;
    }
    *bp++=*p++;
  }
  ret.ReleaseBuffer(wclen+nl_count);
  return ret;
}

const char *Dict::GetWordImp(int index) {
  if (index<0 || index>=(int)m_numwords)
    return NULL;
  int	low=0;
  int	high=m_numblk-1;
  int	mid;
  for (int ni=0;;++ni) {
    if (ni>(int)m_numblk) // prevent loops on unsorted invalid data
      return NULL;
    if (low>high)
      return NULL;
    mid=(low+high)>>1;
    if (index<m_blocks[mid].wordidx)
      high=mid-1;
    else if (index>=m_blocks[mid].wordidx+m_blocks[mid].numwords)
      low=mid+1;
    else
      break;
  }
  if (!GetBlk(mid))
    return NULL;
  return (const char *)m_windex[index-m_blocks[mid].wordidx];
}

static int    compare_buf_str(Buffer<char>& b1,const char *b2,int l2=-1) {
  if (l2<0)
    l2=strlen(b2);
  int	res=memcmp(b1,b2,min(b1.size(),l2));
  if (res==0)
    res=b1.size()<l2 ? -1 : b1.size()>l2 ? 1 : 0;
  return res;
}

static int    compare_buf_str_len(Buffer<char>& b1,const char *b2,int l2=-1) {
  if (l2<0)
    l2=strlen(b2);
  if (l2>b1.size())
    l2=b1.size();
  const char *p=b1;
  while (l2-->0 && *p++==*b2++) ;
  return p-b1;
}

static inline int    compare_bufs(Buffer<char>& b1,Buffer<char>& b2) {
  return compare_buf_str(b1,b2,b2.size());
}

bool	Dict::Find(const CString& word,int& index,int& found) {
  int	sortkeylen=LCMapString(m_lcid,LCMAP_SORTKEY|NORM_IGNORECASE,
			    word,word.GetLength(),NULL,0);
  if (sortkeylen<=1)
    return false;
  Buffer<char>	  sortkey(sortkeylen);
  LCMapString(m_lcid,LCMAP_SORTKEY|NORM_IGNORECASE,word,word.GetLength(),
	      (LPTSTR)(char*)sortkey,sortkeylen);
  sortkey.setsize(sortkeylen-1);
  int	  low=0;
  int	  high=m_numblk-1;
  int	  mid;
  for (int ni=0;;++ni) {
    if (ni>(int)m_numblk) // prevent loops on unsorted data
      return false;
    if (low>high) {
      if (low==0) {
	index=found=0;
	return true;
      }
      return false;
    }
    mid=(low+high)>>1;
    int cmp=compare_bufs(sortkey,m_blocks[mid].key);
    if (cmp<0)
      high=mid-1;
    else {
      if (mid==(int)m_numblk-1) // last block, stop search
	break;
      cmp=compare_bufs(sortkey,m_blocks[mid+1].key);
      if (cmp<0) // found it
	break;
      low=mid+1;
    }
  }
  int	blk=mid;
  if (!GetBlk(blk))
    return false;
  low=0;
  high=m_blocks[blk].numwords-1;
  for (int nj=0;;++nj) {
    if (nj>m_blocks[blk].numwords) // prevent loops on invalid data
      return false;
    if (low>high) { // no such word in this block
      int   idx=m_blocks[blk].wordidx+high;
      if (idx<0)
	idx=0;
      if (idx<(int)m_numwords-1) {
	if (!GetWordImp(idx))
	  return false;
	int cur=idx-m_blocks[m_curblk].wordidx;
	int l1=compare_buf_str_len(sortkey,(const char *)m_kindex[cur]);
	if (++cur>=m_blocks[m_curblk].numwords) {
	  if (!GetWordImp(idx+1))
	    return false;
	  cur=0;
	}
	if (compare_buf_str_len(sortkey,(const char *)m_kindex[cur])>l1)
	  ++idx;
      }
      index=idx;
      found=2;
      return true;
    }
    mid=(low+high)>>1;
    int cmp=compare_buf_str(sortkey,(const char *)m_kindex[mid]);
    if (cmp<0)
      high=mid-1;
    else if (cmp>0)
      low=mid+1;
    else { // found
      index=m_blocks[blk].wordidx+mid;
      found=1;
      return true;
    }
  }
}

static class SimpleDictInit: public IDict::DictInit {
  static IDict *create_simple_dict(CFile *fp) { return new Dict(fp); }
public:
  SimpleDictInit() : DictInit("DICt",create_simple_dict) { }
} g_dict_init;

// create a proper dictionary
IDict *IDict::Create(const CString& filename,CString *errmsg) {
  CFileException  ex;
  CFile		  *fp=new CFile;

  if (!fp->Open(filename,CFile::modeRead|CFile::shareDenyWrite,&ex)) {
    if (errmsg)
      *errmsg=FileExceptionInfo(filename,ex);
    delete fp;
    return NULL;
  }

  BYTE	  sig[SIGSIZE];
  if (fp->Read(sig,SIGSIZE)!=SIGSIZE) {
    if (errmsg)
      errmsg->Format(_T("%s: Ivalid dictionary file"),(const TCHAR*)filename);
    delete fp;
    return NULL;
  }
  IDict *d=NULL;
  for (DictInit	*di=DictInit::m_head;di;di=di->m_next)
    if (memcmp(sig,di->m_sig,SIGSIZE)==0) {
      d=di->m_create(fp);
      break;
    }
  if (d && d->Valid())
    return d;
  if (!d)
    delete fp;
  else
    delete d;
  if (errmsg)
    errmsg->Format(_T("%s: Ivalid dictionary file"),(const TCHAR*)filename);
  return NULL;
}

IDict::DictInit	  *IDict::DictInit::m_head;

IDict::DictInit::DictInit(const char *sig,IDict *(*create)(CFile *)) {
  m_next=m_head;
  m_create=create;
  strncpy(m_sig,sig,sizeof(m_sig));
  m_head=this;
}
