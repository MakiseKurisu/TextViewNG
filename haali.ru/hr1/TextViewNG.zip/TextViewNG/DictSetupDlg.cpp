/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: DictSetupDlg.cpp,v 1.2 2002/03/21 20:09:00 mike Exp $
 * 
 */

#include "resource.h"
#include "DictSetupDlg.h"
#include "TextViewNG.h"
#include "FileOpenDialog.h"
#include "Dictionary.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDictSetupDlg dialog


CDictSetupDlg::CDictSetupDlg(CWnd* pParent /*=NULL*/)
: CDialog(CDictSetupDlg::IDD, pParent)
{
  //{{AFX_DATA_INIT(CDictSetupDlg)
		// NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}


void CDictSetupDlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CDictSetupDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
  //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDictSetupDlg, CDialog)
//{{AFX_MSG_MAP(CDictSetupDlg)
ON_COMMAND(IDC_ADD_DICT,OnAddDict)
ON_COMMAND(IDC_REMOVE_DICT,OnRemoveDict)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDictSetupDlg message handlers

BOOL CDictSetupDlg::OnInitDialog() 
{
  CDialog::OnInitDialog();

  // fetch dictionaries list
  CString   dlist=CTVApp::GetStr(_T("Dictionary"));
  for (int cur=0;cur<dlist.GetLength();) {
    int	  end=dlist.Find(_T('?'),cur);
    int	  def=0;
    if (end<0)
      end=dlist.GetLength();
    if (dlist[cur]==_T('*')) {
      def=1;
      ++cur;
      if (cur>=end)
	continue;
    }
    int	  index=SendDlgItemMessage(IDC_DICTLIST,LB_ADDSTRING,0,
		  (LPARAM)(LPCTSTR)dlist.Mid(cur,end-cur));
    if (index==LB_ERR)
      break;
    SendDlgItemMessage(IDC_DICTLIST,LB_SETITEMDATA,index,def);
    cur=end+1;
  }

  return TRUE;
}

void  CDictSetupDlg::OnAddDict() {
  if (SendDlgItemMessage(IDC_DICTLIST,LB_GETCOUNT)>=MAXDICT)
    return;
  CString   path=GetFileName(NULL,this);
  if (path.GetLength()>0) {
    CString msg;
    IDict *d=IDict::Create(path,&msg);
    if (!d)
      MessageBox(_T("Can't open dictionary: ")+msg,_T("Error"),MB_ICONERROR|MB_OK);
    else {
      SendDlgItemMessage(IDC_DICTLIST,LB_ADDSTRING,0,(LPARAM)(LPCTSTR)path);
      delete d;
    }
  }
}

void  CDictSetupDlg::OnRemoveDict() {
  int	index=SendDlgItemMessage(IDC_DICTLIST,LB_GETCURSEL);
  if (index!=LB_ERR)
    SendDlgItemMessage(IDC_DICTLIST,LB_DELETESTRING,index);
}

void CDictSetupDlg::OnOK() {
  CString   dlist;
  int	    sel=SendDlgItemMessage(IDC_DICTLIST,LB_GETCURSEL);
  int	    count=SendDlgItemMessage(IDC_DICTLIST,LB_GETCOUNT);
  for (int i=0;i<count;++i) {
    if (i>0)
      dlist+=_T('?');
    if (i==sel || (sel==LB_ERR &&
      SendDlgItemMessage(IDC_DICTLIST,LB_GETITEMDATA,i)))
      dlist+=_T('*');
    int	  curlen=dlist.GetLength();
    int	  addlen=SendDlgItemMessage(IDC_DICTLIST,LB_GETTEXTLEN,i);
    TCHAR *cp=dlist.GetBuffer(curlen+addlen);
    SendDlgItemMessage(IDC_DICTLIST,LB_GETTEXT,i,(LPARAM)(cp+curlen));
    dlist.ReleaseBuffer(curlen+addlen);
  }
  CTVApp::SetStr(_T("Dictionary"),dlist);
  CDialog::OnOK();
}
