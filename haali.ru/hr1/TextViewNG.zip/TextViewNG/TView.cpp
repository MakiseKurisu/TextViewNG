/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: TView.cpp,v 1.110 2002/04/29 00:06:34 mike Exp $
 * 
 */

#include "TextViewNG.h"
#include "TVFrame.h"
#include "TView.h"
#include "Colors.h"
#include "OptionsDialog.h"
#include "FileFormatDialog.h"
#include "WordDialog.h"
#include "FileOpenDialog.h"
#include "InputBox.h"
#include "ColorSelector.h"
#include "ContentsDlg.h"
#include "StylesDlg.h"
#include "NoteDialog.h"
#include "MiscOptDlg.h"
#include "DictSetupDlg.h"
#include "Keys.h"
#include "config.h"
#include "Unicode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	DO_CLIP		  0
#define	PROGRESS_H	  6
#define	PROGRESS_M	  3
#define	PROGRESS_A	  11
#define	PROGRESS_C	  10

#ifdef _WIN32_WCE
// can overflow, so take care
static inline int MulDiv(int x,int y,int z) {
  __int64 m=(__int64)x*y;
  return (int)(m/z);
}
#endif

// colors
ColorItem    g_colors[]={
  { _T("Text"), RGB(0,0,0) },
  { _T("Highlight 1") , RGB(0,0,192) },
  { _T("Highlight 2"), RGB(129,0,0) },
  { _T("Highlight 3"), RGB(192,0,192) },
  { _T("Highlight 4"), RGB(0,112,0) },
  { _T("Highlight 5"), RGB(0,112,112) },
  { _T("Highlight 6"), RGB(0,192,0) },
  { _T("Highlight 7"), RGB(128,128,128) },
  { _T("Background"), RGB(255,255,255) },
  { _T("Highlighted Background"), RGB(16,192,255) },
  { _T("Gauge"), RGB(150,150,150) },
  { _T("Section Tick"), RGB(0,0,0) },
  { _T("Bookmark Tick"), RGB(255,0,0) },
  { NULL }
};


/////////////////////////////////////////////////////////////////////////////
// CTView

CTView::CTView()
{
  // read in colors
  for (int i=0;g_colors[i].name;++i)
    g_colors[i].value=AfxGetApp()->GetProfileInt(_T("Colors"),
      g_colors[i].name,g_colors[i].value);
  // read other params
  CFDC::SetCacheSize(CTVApp::GetInt(_T("FontCacheSize"),6));
  m_indent=CTVApp::GetInt(_T("Indent"),DEF_INDENT);
  m_angle=CTVApp::GetInt(_T("Orientation"),DEF_ORIENTATION);
  m_margin_width=CTVApp::GetInt(_T("Margins"),DEF_MARGINS);
  m_justify=CTVApp::GetInt(_T("Justify"),DEF_JUSTIFY)!=0;
  m_hyphenate=CTVApp::GetInt(_T("Hyphenate"),DEF_HYPHENATE)!=0;
  m_bottom_margin=CTVApp::GetInt(_T("BottomMargin"),DEF_BOTTOM_MARGIN);
  m_columns=CTVApp::GetInt(_T("Columns"),DEF_COLUMNS);
  m_usedict=CTVApp::GetInt(_T("UseDictionary"),DEF_USEDICT)!=0;
  m_rotbuttons=CTVApp::GetInt(_T("RotateButtons"),DEF_ROTB)!=0;
  m_showprogress=CTVApp::GetInt(_T("ShowProgress"),DEF_SHOWPROGRESS)!=0;
  if (m_columns<1 || m_columns>4)
    m_columns=1;
  SetFont(CTVApp::GetStr(_T("FontFace"),DEF_FACE),
    CTVApp::GetInt(_T("FontBold"),DEF_BOLD)!=0,
    CTVApp::GetInt(_T("FontSize"),DEF_SIZE),
    CTVApp::GetInt(_T("FontCleartype"),DEF_CLEARTYPE)!=0);
  m_trackmouse=false;
  m_mouse_start.x=m_mouse_start.y=m_mouse_end.x=m_mouse_end.y=0;
  m_userinp1=m_userinp2=m_inpmode=0;
}

CTView::~CTView() {
  SaveInfo();
  Bookmarks::CleanupRegistry(CTVApp::GetInt(_T("NumBookmarks"),DEF_BOOKMARKS));
  KillTimer(m_timer);
}

void  CTView::SaveInfo() {
  if (m_textfile.get() && m_formatter.get())
    m_textfile->SaveBookmarks(m_formatter->Top());
}

void  CTView::Init() {
  GetClientRect(&m_cli);
  CalcSizes();
  Keys::SetWindow(m_hWnd);
  m_timer=SetTimer(1,DEF_SAVEINTERVAL,0);
}

void  CTView::SetFile(auto_ptr<TextFile> tfile) {
  if (!tfile.get())
    return;
  SaveInfo();
  m_textfile=tfile;
  m_formatter=new TextFormatter(m_textfile.get());
  m_formatter->SetJustified(m_justify);
  m_formatter->SetHyphenate(m_hyphenate);
  m_formatter->SetTop(m_textfile->bmk().StartPos());
  m_matchpos=m_formatter->Eof();
  SaveInfo();
  // and format the page
  CalcSizes();
  Invalidate(FALSE);
}

BEGIN_MESSAGE_MAP(CTView,CWnd )
//{{AFX_MSG_MAP(CTView)
ON_WM_PAINT()
ON_WM_SIZE()
ON_WM_KEYDOWN()
ON_WM_ERASEBKGND()
ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
ON_UPDATE_COMMAND_UI(ID_DISP_OPTIONS, OnUpdateOptions)
ON_COMMAND(ID_DISP_OPTIONS, OnOptions)
ON_UPDATE_COMMAND_UI(ID_FILEFORMAT, OnUpdateFileformat)
ON_COMMAND(ID_FILEFORMAT, OnFileformat)
ON_UPDATE_COMMAND_UI(ID_BACK, OnUpdateBack)
ON_COMMAND(ID_BACK, OnBack)
ON_WM_LBUTTONDOWN()
ON_COMMAND(ID_DICT_SETUP, OnDictSetup)
ON_UPDATE_COMMAND_UI(ID_DICT_SETUP, OnUpdateDictSetup)
ON_UPDATE_COMMAND_UI(ID_FIND, OnUpdateFind)
ON_COMMAND(ID_FIND, OnFind)
ON_COMMAND(ID_FINDNEXT, OnFindnext)
ON_UPDATE_COMMAND_UI(ID_FINDNEXT, OnUpdateFindnext)
ON_UPDATE_COMMAND_UI(ID_COLORS, OnUpdateColors)
ON_COMMAND(ID_COLORS, OnColors)
ON_WM_LBUTTONDBLCLK()
ON_COMMAND(ID_ADD_BMK, OnAddBmk)
ON_UPDATE_COMMAND_UI(ID_ADD_BMK, OnUpdateAddBmk)
ON_COMMAND(ID_BOOKMARKS, OnBookmarks)
ON_UPDATE_COMMAND_UI(ID_BOOKMARKS, OnUpdateBookmarks)
ON_COMMAND(ID_LINE_UP, OnLineUp)
ON_COMMAND(ID_LINE_DOWN, OnLineDown)
ON_COMMAND(ID_PAGE_UP, OnPageUp)
ON_COMMAND(ID_PAGE_DOWN, OnPageDown)
ON_COMMAND(ID_START_OF_FILE, OnStartFile)
ON_COMMAND(ID_END_OF_FILE, OnEndFile)
ON_COMMAND(ID_KEYS, OnKeys)
ON_UPDATE_COMMAND_UI(ID_KEYS, OnUpdateKeys)
ON_WM_DESTROY()
ON_COMMAND(ID_STYLES, OnStyles)
ON_UPDATE_COMMAND_UI(ID_STYLES, OnUpdateStyles)
ON_WM_LBUTTONUP()
ON_WM_MOUSEMOVE()
ON_COMMAND(ID_MISCOPT, OnMiscopt)
ON_UPDATE_COMMAND_UI(ID_MISCOPT, OnUpdateMiscopt)
ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
ON_COMMAND(ID_ROTATE,OnRotate)
ON_WM_TIMER()
ON_UPDATE_COMMAND_UI(ID_GOTO, OnUpdateGoto)
ON_COMMAND(ID_GOTO, OnGoto)
ON_COMMAND(ID_DO_FIND, DoFind)
ON_WM_CHAR()
ON_COMMAND(ID_NEXTCH,OnNextSection)
ON_COMMAND(ID_PREVCH,OnPrevSection)
//}}AFX_MSG_MAP
ON_MESSAGE(WM_HOTKEY, OnHotkey)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTView message handlers
BOOL CTView::PreCreateWindow(CREATESTRUCT& cs)
{
  if (!CWnd::PreCreateWindow(cs))
    return FALSE;

  cs.style &= ~WS_BORDER;
  cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS,
    NULL, NULL, NULL);

  return TRUE;
}

void CTView::OnPaint()
{
  PAINTSTRUCT ps;
  {
    CFDC	    fdc(m_hWnd,&ps);
    RECT	    col;
    int	    ll=0;
    col.left=col.top=0;
    col.right=m_width;
    col.bottom=m_rheight;
    for (int column=0;column<m_columns;++column) {
      PaintColumn(fdc,col,m_cli,ll,column);
      col.left+=m_width;
      col.right+=m_width;
    }
    if (m_showprogress) {
      // clear area
      col.left=0; col.top=m_rheight-PROGRESS_H;
      col.right=m_rwidth; col.bottom=m_rheight;
      fdc.SetBkColor(C_BG);
      TDrawText(fdc.DC(),col.left,col.top,m_cli,col,NULL,0,NULL);
      // draw position bar
      int	  top=m_formatter->Eof().para;
      int	  bw=m_rwidth-2*PROGRESS_M-2*PROGRESS_A;
      int	  pos=top ? MulDiv(bw,m_formatter->Bottom().para,top) : bw;
      col.left=PROGRESS_M+PROGRESS_A; col.top=m_rheight-PROGRESS_H+1;
      col.right=col.left+pos; col.bottom=col.top+3;
      fdc.SetBkColor(C_GAUGE);
      TDrawText(fdc.DC(),col.left,col.top,m_cli,col,NULL,0,NULL);
      // draw a thin black line
      col.left=PROGRESS_M; col.top=col.bottom=m_rheight-PROGRESS_H+2;
      col.right=m_rwidth-PROGRESS_M;
      fdc.SetColor(C_TOCL0); // XXX
      TDrawLine(fdc.DC(),m_cli,col);
      // draw arrows
      col.top=m_rheight-PROGRESS_H+1;
      col.bottom=col.top+3;
      col.left=col.right=PROGRESS_M+1;
      TDrawLine(fdc.DC(),m_cli,col);
      col.left=col.right=PROGRESS_M+4;
      TDrawLine(fdc.DC(),m_cli,col);
      col.left=col.right=m_rwidth-PROGRESS_M-5;
      TDrawLine(fdc.DC(),m_cli,col);
      col.left=col.right=m_rwidth-PROGRESS_M-2;
      TDrawLine(fdc.DC(),m_cli,col);
      col.top=m_rheight-PROGRESS_H;
      col.bottom=col.top+5;
      col.left=col.right=PROGRESS_M+2;
      TDrawLine(fdc.DC(),m_cli,col);
      col.left=col.right=PROGRESS_M+5;
      TDrawLine(fdc.DC(),m_cli,col);
      col.left=col.right=m_rwidth-PROGRESS_M-6;
      TDrawLine(fdc.DC(),m_cli,col);
      col.left=col.right=m_rwidth-PROGRESS_M-3;
      TDrawLine(fdc.DC(),m_cli,col);
      // draw chapter ticks
      if (top) {
	Bookmarks& bm=m_textfile->bmk();
	bool  doall=bm.GetSize()<m_rwidth/2;
	bool  doch=bm.NumTopMarks()<m_rwidth/2;
	bool  dobm=bm.NumBookmarks()<m_rwidth/2;
	if (doch||dobm||doall) {
	  for (int ii=0;ii<bm.GetSize();++ii) {
	    COLORREF	  color=C_TOCL0;
	    col.top=m_rheight-PROGRESS_H;
	    col.bottom=col.top+5;
	    if (bm[ii].flags&Bookmarks::BMK) {
	      if (!dobm)
		continue;
	      color=C_TOCBM;
	    } else if (bm[ii].level>0) {
	      if (!doall)
		continue;
    	      col.top=m_rheight-PROGRESS_H+1;
	      col.bottom=col.top+3;
	    } else if (!doch)
		continue;
	    col.left=col.right=PROGRESS_M+PROGRESS_A+MulDiv(bw,bm[ii].ref.para,top);
	    fdc.SetColor(color);
	    TDrawLine(fdc.DC(),m_cli,col);
	  }
	}
      }
    }
  }
}

void CTView::OnSize(UINT nType, int cx, int cy) {
  CWnd::OnSize(nType, cx, cy);
  if (cx==0 || cy==0) // don't bother with invalid sizes
    return;
  GetClientRect(&m_cli);
  CalcSizes();
}

void CTView::PaintColumn(CFDC &dc,RECT& col,RECT& cli,int& startline,int page)
{
  RECT	  line;
  int	  fh,fa;
  dc.SetTextColor(C_NORM);
  dc.SetBkColor(C_BG);
  line.top=col.top;
  int i,pl=m_formatter->PageLength(page);
  for (i=0;i<pl;++i) {
    line.left=col.left;
    line.right=col.right;
    int	  x=m_margin_width;
    const Line&	l=m_formatter->GetLine(i+startline);
    line.bottom=line.top+l.height;
    x+=l.ispace;
    if (l.flags&Line::defstyle) {
      dc.SelectFont(0,0);
      dc.GetFontSize(fh,fa);
      TDrawText(dc.DC(),x+line.left,line.top+l.base-fa,cli,line,l.str,l.str.size(),l.dx);
    } else {
      ComplexLine(dc,cli,line,x,l);
    }
    line.top=line.bottom;
  }
  line.left=col.left;
  line.right=col.right;
  line.bottom=col.bottom;
  TDrawText(dc.DC(),line.left,line.top,cli,line,NULL,0,NULL);
  startline+=i;
}

void  CTView::ComplexLine(CFDC& dc,const RECT& cli,RECT& line,
			  int x,const Line& l)
{
  int		  flags=ETO_OPAQUE;
  int		  len=l.str.size();
  int		  off=0;
  int		  fh,fa;
  int		  x0=line.left;
  int		  width=line.right-line.left;
  // check if the backgound is the same
  for (int i=0;i<len;++i)
    if (l.attr[i].hibg)
      goto normal_draw;
  // all bg is normal, so we clear the entire line and use transparent mode
  dc.SetBkColor(C_BG);
  TDrawText(dc.DC(),line.left,line.top,cli,line,NULL,0,NULL);
  flags=0;
normal_draw:
  while (len>0) {
    line.right=x0+x;
    COLORREF  bg=C_BG;
    Attr      attr=l.attr[off];
    int	      run=0;
    while (run<len && attr.wa==l.attr[off+run].wa) {
      line.right+=l.dx[off+run];
      ++run;
    }
    if (run==len && !attr.hibg) // fill till the end
      line.right=x0+width;
    dc.SelectFont(attr.fsize,attr.fontattr());
    dc.GetFontSize(fh,fa);
    if (attr.hibg && line.left && line.left==x0) {
      line.right=x0+x;
      run=0;
      attr.wa=0;
    } else
      dc.SetTextColor(C_TCOLOR(attr.color));
    dc.SetBkColor(attr.hibg ? C_HBG : C_BG);
    TDrawText(dc.DC(),x0+x,line.top+l.base-fa,cli,line,l.str+off,run,l.dx+off,flags);
    len-=run;
    off+=run;
    line.left=line.right;
    x=line.left-x0;
  }
  if (x<width && flags) { // fill right part
    line.right=x0+width;
    dc.SetBkColor(C_BG);
    TDrawText(dc.DC(),line.left,line.top,cli,line,NULL,0,NULL);
  }
  dc.SetTextColor(C_NORM);
  dc.SetBkColor(C_BG);
}

void CTView::TDrawText(HDC dc,int x,int y,const RECT& cli,const RECT& r,
		      const wchar_t *p,int lp,const int *dx,int flags)
{
  RECT	  tmp=r;
  POINT	  pt;
  pt.x=x;
  pt.y=y;
  Transform(tmp,cli);
  Transform(pt,cli);
  ExtTextOutW(dc,pt.x,pt.y,flags,&tmp,p,lp,dx);
}

void  CTView::TDrawLine(HDC dc,RECT& cli,RECT& rc) {
  POINT	pt[2];
  pt[0].x=rc.left; pt[0].y=rc.top;
  pt[1].x=rc.right; pt[1].y=rc.bottom;
  Transform(pt[0],cli);
  Transform(pt[1],cli);
  Polyline(dc,pt,2);
}

void CTView::SetFont(const CString &face, bool bold, int size, bool cleartype)
{
  CFDC::SetDefaultFont(face,size,bold,cleartype,m_angle);
  m_bold=bold;
  m_cleartype=cleartype;
  m_fontface=face;
  m_fontsize=size;
}

void CTView::CalcSizes()
{
  if (m_angle==900 || m_angle==2700) {
    m_rheight=m_cli.right-m_cli.left;
    m_rwidth=m_cli.bottom-m_cli.top;
  } else {
    m_rheight=m_cli.bottom-m_cli.top;
    m_rwidth=m_cli.right-m_cli.left;
  }
  m_width=m_rwidth;
  m_height=m_rheight;
  if (m_showprogress)
    m_height-=m_bottom_margin;
  m_width/=m_columns;
  if (m_formatter.get()) {
    m_formatter->SetIndent(m_indent);
    m_formatter->SetSize(m_width-2*m_margin_width,m_height,m_columns);
    CFDC	fdc(m_hWnd);
    m_formatter->Reformat(fdc);
  }
}

void CTView::SaveFont()
{
  CTVApp::SetStr(_T("FontFace"),m_fontface);
  CTVApp::SetInt(_T("FontSize"),m_fontsize);
  CTVApp::SetInt(_T("FontBold"),m_bold);
  CTVApp::SetInt(_T("FontCleartype"),m_cleartype);
}

void CTView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
  UINT	cmd;
  if (Keys::TranslateKey(nChar,cmd,m_rotbuttons ? m_angle : 0)) {
    CTVApp::QueueCmd(cmd);
    return;
  }
  CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CTView::OnLineUp() { Move(mBack,mLine); }
void CTView::OnLineDown() { Move(mFwd,mLine); }
void CTView::OnPageUp() { Move(mBack,mPage); }
void CTView::OnPageDown() { Move(mFwd,mPage); }
void CTView::OnStartFile() { Move(mBack,mFile); }
void CTView::OnEndFile() { Move(mFwd,mFile); }

void CTView::Move(int dir, int amount)
{
  if (dir==mBack) {
    if (m_formatter->AtTop())
      return;
  } else {
    if (m_formatter->AtEof())
      return;
  }
  Line	    l;
  CFDC	    fdc(m_hWnd);
  if (dir==mBack)
    switch (amount) {
    case mLine:
      m_formatter->FormatBack(fdc,m_formatter->GetLine(
	m_formatter->Length()-1).pos,m_formatter->Top());
      break;
    case mFile:
      PushPos();
      m_formatter->FormatFwd(fdc,FilePos(0,0));
      break;
    default:
    case mPage:
      m_formatter->FormatBack(fdc,m_formatter->Top(),FilePos());
      break;
    }
  else
    switch (amount) {
    case mLine:
      m_formatter->FormatFwd(fdc,m_formatter->GetLine(1).pos);
      break;
    case mFile:
      PushPos();
      m_formatter->FormatBack(fdc,m_formatter->Eof(),FilePos());
      break;
    default:
    case mPage:
      m_formatter->FormatFwd(fdc,m_formatter->Bottom());
      break;
    }
  Invalidate(FALSE);
}

BOOL CTView::OnEraseBkgnd(CDC* pDC)
{
  return FALSE; // we'll erase it in OnPaint
}

class CAboutDialog: public CDialog {
public:
  CAboutDialog(UINT id,CWnd *parent=NULL) : CDialog(id,parent) { }
  virtual BOOL	OnInitDialog();
  CString	m_info;
};

#include "buildnum.h"

#if PSPC
#define	ABOUT_FORMAT1	_T("%s\n\n%d byte(s), %d paragraph(s)\nFormat: %s\nEncoding: %s\nCompression: %s\nPosition: %d:%d")
#define	ABOUT_FORMAT2	_T("Haali Reader v1.0\nBuild %d, %s\nCopyright (C) 2001\nMike E. Matsnev\nhttp://haali.cs.msu.ru/pocketpc/")
#else
#define	ABOUT_FORMAT1	_T("%s\n%d byte(s), %d paragraph(s)\nFormat: %s; Encoding: %s; Compression: %s\nPosition: %d:%d")
#define ABOUT_FORMAT2	_T("Haali Reader v1.0 Build %d, %s\nCopyright (C) 2001,2002 Mike E. Matsnev\nhttp://haali.cs.msu.ru/pocketpc/")
#endif

BOOL CAboutDialog::OnInitDialog() {
  CString ver;
  ver.Format(ABOUT_FORMAT2,BUILD_NUM,BUILD_DATE);
  SetDlgItemText(IDC_ABOUTVER,ver);
  SetDlgItemText(IDC_ABOUTINFO,m_info);
  return CDialog::OnInitDialog();
}

void CTView::OnAppAbout()
{
  CAboutDialog	  dlg(IDD_ABOUTBOX,this);
  CString	  fmt,enc;
  FilePos	  p=m_formatter->Top();

  if (m_textfile->GetFormat()<0) { // auto
    fmt.Format(_T("Auto, detected: %s"),
      m_textfile->GetFormatName(m_textfile->GetRealFormat()));
  } else { // set by user
    fmt=m_textfile->GetFormatName(m_textfile->GetFormat());
  }
  if (m_textfile->GetEncoding()<0) { // auto
    enc.Format(_T("Auto, detected: %s"),
      m_textfile->GetEncodingName(m_textfile->GetRealEncoding()));
  } else {
    enc=m_textfile->GetEncodingName(m_textfile->GetEncoding());
  }
  dlg.m_info.Format(ABOUT_FORMAT1,
    (LPCTSTR)m_textfile->Name(),m_textfile->ByteLength(),
    m_textfile->Length(),(LPCTSTR)fmt,(LPCTSTR)enc,
    (LPCTSTR)m_textfile->CompressionInfo(),
    p.para,p.off);
  dlg.DoModal();
}

void CTView::OnUpdateOptions(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnOptions()
{
  COptionsDialog    opt;

  opt.m_bold=m_bold;
  opt.m_cleartype=m_cleartype;
  opt.m_justify=m_justify;
  opt.m_margins=m_margin_width;
  opt.m_size=m_fontsize;
  opt.m_face=m_fontface;
  opt.m_hyphenate=m_hyphenate;
  opt.m_bot_margin=m_bottom_margin;
  opt.m_angle=m_angle/900;
  opt.m_columns=m_columns-1;
  opt.m_showprogress=m_showprogress;

  if (opt.DoModal()==IDOK) { // try to apply settings
    bool    update=false;
    if (m_fontface!=opt.m_face || m_fontsize!=opt.m_size ||
	m_bold!=(opt.m_bold!=0) || m_cleartype!=(opt.m_cleartype!=0) ||
	m_angle!=opt.m_angle*900) {
      if (m_angle!=opt.m_angle*900) {
	m_angle=opt.m_angle*900;
	CTVApp::SetInt(_T("Orientation"),m_angle);
      }
      SetFont(opt.m_face,opt.m_bold!=0,opt.m_size,opt.m_cleartype!=0);
      SaveFont();
      update=true;
    }
    if (m_margin_width!=opt.m_margins) {
      m_margin_width=opt.m_margins;
      CTVApp::SetInt(_T("Margins"),m_margin_width);
      update=true;
    }
    if (m_bottom_margin!=opt.m_bot_margin) {
      m_bottom_margin=opt.m_bot_margin;
      CTVApp::SetInt(_T("BottomMargin"),m_bottom_margin);
      update=true;
    }
    if (m_justify!=(opt.m_justify!=0)) {
      m_justify=opt.m_justify!=0;
      m_formatter->SetJustified(m_justify);
      CTVApp::SetInt(_T("Justify"),m_justify);
      update=true;
    }
    if (m_hyphenate!=(opt.m_hyphenate!=0)) {
      m_hyphenate=opt.m_hyphenate!=0;
      m_formatter->SetHyphenate(m_hyphenate);
      CTVApp::SetInt(_T("Hyphenate"),m_hyphenate);
      update=true;
    }
    if (m_showprogress!=(opt.m_showprogress!=0)) {
      m_showprogress=opt.m_showprogress!=0;
      CTVApp::SetInt(_T("ShowProgress"),m_showprogress);
      update=true;
    }
    if (m_columns!=opt.m_columns+1) {
      m_columns=opt.m_columns+1;
      CTVApp::SetInt(_T("Columns"),m_columns);
      update=true;
    }
    if (update) {
      CalcSizes();
      Invalidate(FALSE);
    }
  }
}

void CTView::OnUpdateFileformat(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnFileformat()
{
  CFileFormatDialog fmt;

  fmt.m_format=m_textfile->GetFormat()+1;
  fmt.m_encoding=m_textfile->GetEncoding()+1;

  if (fmt.DoModal()==IDOK) {
    bool update=false;
    if (fmt.m_format-1 != m_textfile->GetFormat()) {
      PushPos();
      m_textfile->SetFormat(fmt.m_format-1);
      m_formatter->SetTop(FilePos(0,0));
      update=true;
    }
    if (fmt.m_encoding-1 != m_textfile->GetEncoding()) {
      m_textfile->SetEncoding(fmt.m_encoding-1);
      update=true;
    }
    if (update) {
      CFDC	  fdc(m_hWnd);
      m_formatter->Reformat(fdc);
      Invalidate(FALSE);
      m_matchpos=m_formatter->Eof();
    }
  }
}

void  CTView::PushPos() {
  m_pstack.AddTail(m_formatter->Top());
  if (m_pstack.GetCount()>100)
    m_pstack.RemoveHead();
}

void CTView::OnUpdateBack(CCmdUI* pCmdUI) {
  pCmdUI->Enable(!m_pstack.IsEmpty());
}

void CTView::OnBack() {
  if (!m_pstack.IsEmpty())
    MoveAbs(m_pstack.RemoveTail());
}

void  CTView::OnNextSection() {
  Bookmarks&	bm=m_textfile->bmk();
  FilePos	cur=m_formatter->Bottom();
  if (cur<m_formatter->Eof()) {
    int   index=bm.BFind(cur,Bookmarks::SNEXTANY);
    if (index<bm.GetSize()) {
      if (cur==bm[index].ref && index<bm.GetSize())
	++index;
      if (cur<bm[index].ref) {
	PushPos();
	MoveAbs(bm[index].ref);
      }
    }
  }
}

void  CTView::OnPrevSection() {
  Bookmarks&	bm=m_textfile->bmk();
  FilePos	cur=m_formatter->Top();
  if (cur>FilePos()) {
    int   index=bm.BFind(cur,Bookmarks::SPREVANY);
    if (index<bm.GetSize()) {
      if (cur==bm[index].ref && index>0)
	--index;
      if (bm[index].ref<cur) {
	PushPos();
	MoveAbs(bm[index].ref);
      }
    }
  }
}

void CTView::HandleMouseDown(CPoint point) {
  POINT	    pt;
  FilePos   pos;

  pt.x=point.x;
  pt.y=point.y;
  // transform point into virtual coords
  RevTransform(pt,m_cli);
  if (pt.y>=m_rheight-PROGRESS_C && pt.y<m_rheight) {
    if (pt.x<PROGRESS_M+PROGRESS_A) { // prev section
      OnPrevSection();
    } else if (pt.x>=m_rwidth-PROGRESS_M-PROGRESS_A) { // next section
      OnNextSection();
    } else { // move absolute
      PushPos();
      MoveAbs(FilePos(MulDiv(m_textfile->Length(),pt.x-PROGRESS_M-PROGRESS_A,
	m_rwidth-2*PROGRESS_M-2*PROGRESS_A),0));
    }
  } else if (LookupAddr(pt,pos)) {
    Paragraph p(m_textfile->GetParagraph(pos.para));
    // check links first
    for (int link=0;link<p.links.size();++link)
      if (p.links[link].off<=(DWORD)pos.off && p.links[link].off+p.links[link].len>(DWORD)pos.off) {
	// found a link, display footnote
	if (p.links[link].target<0) {
	  PushPos();
	  MoveAbs(FilePos(-p.links[link].target,0));
	} else
	  ShowNote(p.links[link].target);
	return;
      }
    if (m_usedict) {
      // lookup a word in the dictionary then
      int start,end;
      for (start=pos.off+1;start>0 && (iswalpha(p.str[start-1]) ||
		   p.str[start-1]==L'\'' ||
		   p.str[start-1]==L'-');--start) ;
      for (end=pos.off+1;end<p.str.size() && (iswalpha(p.str[end]) ||
		  p.str[end]==L'\'' || p.str[end]==L'-');++end) ;
      if (start!=end) {
	CWordDialog   dlg(Unicode::ToCS(p.str+start,end-start),this);
	dlg.DoModal();
      }
    }
  }
}

void CTView::OnLButtonDblClk(UINT nFlags, CPoint point) {
  POINT	    pt;
  FilePos   pos;

  pt.x=point.x;
  pt.y=point.y;
  RevTransform(pt,m_cli);

  if (pt.y<m_rheight-PROGRESS_H)
    CTVApp::QueueCmd(ID_FULLSCREEN);
}

void CTView::MoveAbs(FilePos pos) {
  CFDC		fdc(m_hWnd);
  m_formatter->FormatFwd(fdc,pos);
  Invalidate(FALSE);
}

void CTView::OnDictSetup() {
  CDictSetupDlg	  dlg;
  dlg.DoModal();
}

void CTView::OnUpdateDictSetup(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnUpdateFind(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnFind() {
  CString   tmp;
  if (GetUserInput(_T("Find what:"),_T("Find"),tmp,this)) {
    if (tmp.GetLength()>0) {
      m_matchpos=FilePos();
      m_searchstr=Unicode::ToWCbuf(tmp);
      CTVApp::QueueCmd(ID_DO_FIND);
    }
  }
}

void CTView::OnFindnext() {
  if (m_searchstr.size()>0 &&
      m_matchpos+m_searchstr.size()<m_formatter->Eof()) {
    m_matchpos.off+=m_searchstr.size();
    DoFind();
  }
}

void CTView::OnUpdateFindnext(CCmdUI* pCmdUI) {
  pCmdUI->Enable(m_searchstr.size()>0 &&
    m_matchpos+m_searchstr.size()<m_formatter->Eof());
}

static Buffer<int>  kmptable(const Buffer<wchar_t>& s) {
  Buffer<int>	b(s.size()+1);

  if (s.size()>0) {
    int		i,j;

    i=0;
    j=b[0]=-1;
    while (i<s.size()) {
      while (j>-1 && s[i]!=s[j])
	j=b[j];
      ++i;
      ++j;
      if (i<s.size() && j<s.size() && s[i]==s[j])
	b[i]=b[j];
      else
	b[i]=j;
    }
  }
  return b;
}

static int	  kmpfind(const wchar_t *s,int len,int off,const wchar_t *pat,
			  int patlen,int *tab)
{
  int	  i=0,j=off;
  while (j<len) {
    while (i>-1 && pat[i]!=s[j])
      i=tab[i];
    ++i;
    ++j;
    if (i>=patlen)
      return j-i;
  }
  return -1;
}

void CTView::DoFind() {
  if (m_matchpos.para<m_textfile->Length()) {
    CWaitCursor wait;
    Buffer<int>	tab(kmptable(m_searchstr));
    while (m_matchpos.para<m_textfile->Length()) {
      Paragraph	      para(m_textfile->GetParagraph(m_matchpos.para));
      // XXX para.str.MakeLower();
      int	      pp=kmpfind(para.str,para.str.size(),
	m_matchpos.off,m_searchstr,m_searchstr.size(),tab);
      if (pp>=0) {
	m_matchpos.off=pp;
	if (m_matchpos<m_formatter->Top() || m_matchpos>=m_formatter->Bottom()) {
	  PushPos();
	  MoveAbs(FilePos(m_matchpos.para,0));
	  while (m_formatter->Bottom().para==m_matchpos.para &&
	    m_formatter->Bottom().off<=m_matchpos.off)
	    Move(mFwd,mPage);
	}
	m_formatter->SetHighlight(m_matchpos,m_searchstr.size());
	Invalidate();
	return;
      }
      ++m_matchpos.para;
      m_matchpos.off=0;
    }
  }
  // didnt find anything
  m_formatter->SetHighlight(FilePos(),0);
  Invalidate(); // in case the previous match was visible
  MessageBeep(MB_OK);
}

void CTView::OnUpdateColors(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnColors() {
  if (myChooseColors(g_colors,this)) {
    for (int i=0;g_colors[i].name;++i)
      if (g_colors[i].tempval)
	AfxGetApp()->WriteProfileInt(_T("Colors"),g_colors[i].name,
	  g_colors[i].value);
    Invalidate(FALSE);
  }
}

void CTView::ShowTOC() {
  if (m_textfile->bmk().GetSize()>0) {
    CContentsDlg    dlg(m_textfile->bmk(),m_formatter->Top(),m_formatter->Eof().para,this);
    if (dlg.DoModal()==IDOK) {
      dlg.m_index=m_textfile->bmk().Commit(dlg.m_index);
      if (dlg.m_index>=0) {
	PushPos();
	MoveAbs(m_textfile->bmk()[dlg.m_index].ref);
      }
    }
  }
}

void CTView::OnAddBmk() {
  CString   bm;
  GetSelText(bm);
  if (GetUserInput(_T("Bookmark text:"),_T("Add bookmark"),bm,this))
    m_textfile->bmk().Add(bm,m_formatter->Top());
}

void CTView::OnUpdateAddBmk(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnBookmarks() {
  ShowTOC();
}

void CTView::OnUpdateBookmarks(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnKeys() {
  Keys::SetupKeys(this);
}

void CTView::OnUpdateKeys(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnDestroy() 
{
  Keys::SetWindow(0);	
  CWnd::OnDestroy();
}

LRESULT CTView::OnHotkey(WPARAM wp,LPARAM lp) {
  UINT	cmd;
  if (Keys::TranslateKey(wp,cmd))
    CTVApp::QueueCmd(cmd);
  return 0;
}

void CTView::OnStyles() {
  CStylesDlg	dlg(this);

  if (dlg.DoModal()==IDOK) {
    if (dlg.SaveChanges()) {
      XMLParser::SaveStyles();
      m_textfile->Reparse();
      CFDC	  fdc(m_hWnd);
      m_formatter->Reformat(fdc);
      Invalidate(FALSE);
    }
  }
}

void CTView::OnUpdateStyles(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void  CTView::Transform(RECT& r,const RECT& cli) {
  int	x1=r.left;
  int	y1=r.top;
  int	x2=r.right;
  int	y2=r.bottom;
  switch (m_angle) {
  case 2700:
    r.left=cli.right-y2;
    r.top=x1;
    r.right=cli.right-y1;
    r.bottom=x2;
    break;
  case 1800:
    r.left=cli.right-x2;
    r.top=cli.bottom-y2;
    r.right=cli.right-x1;
    r.bottom=cli.bottom-y1;
    break;
  case 900:
    r.left=y1;
    r.top=cli.bottom-x2;
    r.right=y2;
    r.bottom=cli.bottom-x1;
    break;
  }
}

void  CTView::Transform(POINT& pt,const RECT& cli) {
  int	x=pt.x;
  int	y=pt.y;
  switch (m_angle) {
  case 2700:
    pt.x=cli.right-y;
    pt.y=x;
    break;
  case 1800:
    pt.x=cli.right-x;
    pt.y=cli.bottom-y;
    break;
  case 900:
    pt.x=y;
    pt.y=cli.bottom-x;
    break;
  }
}

void CTView::RevTransform(POINT& pt,const RECT& cli) {
  int	x=pt.x;
  int	y=pt.y;
  switch (m_angle) {
  case 2700:
    pt.x=y;
    pt.y=cli.right-x;
    break;
  case 1800:
    pt.x=cli.right-x;
    pt.y=cli.bottom-y;
    break;
  case 900:
    pt.x=cli.bottom-y;
    pt.y=x;
    break;
  }
}

bool CTView::LookupAddr(const POINT& vp,FilePos& p) {
  int	  column=vp.x/m_width;
  if (column<0 || column>=m_columns) {
    if (column<0)
      p=m_formatter->Top();
    else
      p=m_formatter->Bottom();
    return false;
  }
  int	  off=0;
  for (int col=0;col<column;++col)
    off+=m_formatter->PageLength(col);
  int	  line=0;
  int	  cury=0;
  if (vp.y<0) {
    if (m_formatter->PageLength(column)>0)
      p=m_formatter->GetLine(off).pos;
    else
      p=m_formatter->Bottom();
    return false;
  }
  for (;line<m_formatter->PageLength(column);++line) {
    const Line&	l=m_formatter->GetLine(off+line);
    if (vp.y>=cury && vp.y<cury+l.height) { // found line
      int x=vp.x-m_width*column-l.ispace-m_margin_width;
      int curx=0;
      int sym=0;
      if (x<0) {
	p=l.pos;
	return false;
      }
      for (;sym<l.real_len;++sym) {
	if (x>=curx && x<curx+l.dx[sym]) { // found character
	  p=l.pos;
	  p.off+=sym;
	  return true;
	}
	curx+=l.dx[sym];
      }
      p=l.pos;
      p.off+=sym;
      return false;
    }
    cury+=l.height;
  }
  if (m_formatter->PageLength(column)>0) {
    const Line& l=m_formatter->GetLine(off+m_formatter->PageLength(column)-1);
    p=l.pos;
    p.off+=l.real_len;
  } else
    p=m_formatter->Bottom();
  return false;
}

void  CTView::ShowNote(int note) {
  CString *tmp=new CString;
  for (int np=0;np<m_textfile->GetNoteLength(note);++np) {
    Paragraph p(m_textfile->GetNoteParagraph(note,np));
    if (p.str.size()>1 || (p.str.size()==1 && p.str[0]!=_T(' '))) {
      *tmp+=_T("   ");
      *tmp+=Unicode::ToCS(p.str);
    }
    *tmp+=_T("\r\n");
  }
  CNoteDialog dlg(tmp);
  dlg.DoModal();
}

void CTView::OnLButtonDown(UINT nFlags, CPoint point)
{
  m_mouse_start=m_mouse_last=m_mouse_end=point;
  m_trackmouse=true;
  m_dmove=false;
  SetCapture();
  TrackMouse();
}

void CTView::OnLButtonUp(UINT nFlags, CPoint point) {
  if (m_trackmouse) {
    m_mouse_end=point;
    TrackMouse();
    m_trackmouse=false;
    ReleaseCapture();
    int len,pl;
    FilePos start;
    CalcSelection(start,len,pl);
    if (!m_dmove && !len) // position didnt change
      HandleMouseDown(point);
  }
}

void CTView::OnMouseMove(UINT nFlags, CPoint point) {
  if (m_trackmouse) {
    m_mouse_end=point;
    TrackMouse();
    m_mouse_last=point;
  }
}

void CTView::TrackMouse() {
  FilePos start;
  int len,pl;
  CalcSelection(start,len,pl);
  if (m_formatter->SetHighlight(start,len))
    Invalidate(FALSE);
  if (abs(m_mouse_end.x-m_mouse_start.x)>4 || abs(m_mouse_end.y-m_mouse_start.y)>4)
    m_dmove=true;
}

void CTView::OnMiscopt() {
  CMiscOptDlg dlg;

  dlg.m_allowmulti=CTVApp::GetInt(_T("AllowOnlyOneInstance"),1)==0;
  dlg.m_usedict=m_usedict;
  dlg.m_rotb=m_rotbuttons;
  dlg.m_fcsize=CTVApp::GetInt(_T("FontCacheSize"),DEF_FONTCACHE);
  dlg.m_fbsize=CTVApp::GetInt(_T("FileBufSize"),DEF_FBUF)>>10;
  dlg.m_savetofiles=CTVApp::GetInt(_T("SaveToFiles"),DEF_SAVETOFILES)!=0;
  dlg.m_lastfiles=CTVApp::GetInt(_T("NumBookmarks"),DEF_BOOKMARKS);
  if (dlg.DoModal()==IDOK) {
    if ((dlg.m_usedict!=0)!=m_usedict) {
      m_usedict=dlg.m_usedict!=0;
      CTVApp::SetInt(_T("UseDictionary"),m_usedict);
    }
    if (dlg.m_allowmulti!=(CTVApp::GetInt(_T("AllowOnlyOneInstance"),1)==0))
      CTVApp::SetInt(_T("AllowOnlyOneInstance"),!dlg.m_allowmulti);
    if ((dlg.m_rotb!=0)!=m_rotbuttons) {
      m_rotbuttons=dlg.m_rotb!=0;
      CTVApp::SetInt(_T("RotateButtons"),m_rotbuttons);
    }
    if (dlg.m_fcsize<2)
      dlg.m_fcsize=2;
    if (dlg.m_fcsize>32)
      dlg.m_fcsize=32;
    if (dlg.m_fcsize!=CTVApp::GetInt(_T("FontCacheSize"),DEF_FONTCACHE)) {
      CTVApp::SetInt(_T("FontCacheSize"),dlg.m_fcsize);
      CFDC::SetCacheSize(dlg.m_fcsize);
    }
    if (dlg.m_fbsize<8)
      dlg.m_fbsize=8;
    if (dlg.m_fbsize>1024)
      dlg.m_fbsize=1024;
    dlg.m_fbsize<<=10;
    int	  fbs=8192;
    while ((fbs<<1)<=dlg.m_fbsize)
      fbs<<=1;
    if (fbs!=CTVApp::GetInt(_T("FileBufSize"),DEF_FBUF))
      CTVApp::SetInt(_T("FileBufSize"),fbs);
    if ((dlg.m_savetofiles!=0)!=(CTVApp::GetInt(_T("SaveToFiles"),DEF_SAVETOFILES)!=0))
      CTVApp::SetInt(_T("SaveToFiles"),dlg.m_savetofiles!=0);
    if (dlg.m_lastfiles!=CTVApp::GetInt(_T("NumBookmarks"),DEF_BOOKMARKS))
      CTVApp::SetInt(_T("NumBookmarks"),dlg.m_lastfiles);
  }
}

void CTView::OnUpdateMiscopt(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnEditCopy() {
  // wastes memory, but easy to implement
  CString str;
  if (GetSelText(str)) {
    TCHAR   *result=(TCHAR*)LocalAlloc(0,sizeof(TCHAR)*(str.GetLength()+1));
    if (!result)
      return;
    memcpy(result,(const TCHAR *)str,sizeof(TCHAR)*(str.GetLength()+1));
    if (OpenClipboard()) {
      if (EmptyClipboard())
	if (::SetClipboardData(CF_UNICODETEXT,result)) { // XXX MB/WC can mismatch
	  CloseClipboard();
	  return;
	}
      CloseClipboard();
    }
    LocalFree(result);
  }
}

void CTView::OnUpdateEditCopy(CCmdUI* pCmdUI) {
  FilePos p;
  int	  l,pl;
  CalcSelection(p,l,pl);
  pCmdUI->Enable(l>0);
}

void CTView::CalcSelection(FilePos& p,int& len,int& pl) {
  FilePos   start,end;
  POINT	    a,b;
  a=m_mouse_start; b=m_mouse_end;
  RevTransform(a,m_cli); RevTransform(b,m_cli);
  LookupAddr(a,start);
  LookupAddr(b,end);
  int	    dist=m_formatter->Distance(start,end,pl);
  if (dist<0) {
    p=end;
    len=-dist;
  } else {
    p=start;
    len=dist;
  }
}

void CTView::OnRotate() {
  m_angle+=900;
  if (m_angle>2700)
    m_angle=0;
  CTVApp::SetInt(_T("Orientation"),m_angle);
  CFDC::SetDefaultFont(m_fontface,m_fontsize,m_bold,m_cleartype,m_angle);
  CalcSizes();
  Invalidate(FALSE);
}

bool  CTView::GetSelText(CString& str) {
  FilePos   start;
  int	    len,pl;
  CalcSelection(start,len,pl);
  if (len>0) {
    wchar_t   *result;
#ifdef UNICODE
    result=str.GetBuffer(len+2*pl);
#else
    Buffer<wchar_t>   tmp(len+2*pl);
    result=tmp;
#endif
    wchar_t   *bp=result;
    Paragraph pp(m_textfile->GetParagraph(start.para));
    int	  ll=pp.str.size()-start.off;
    if (ll>len)
      ll=len;
    memcpy(bp,pp.str+start.off,ll*sizeof(wchar_t));
    bp+=ll;
    len-=ll;
    start.off=0;
    ++start.para;
    while (len>0) {
      *bp++=L'\r'; *bp++=L'\n';
      pp=m_textfile->GetParagraph(start.para);
      ll=len;
      if (ll>pp.str.size())
	ll=pp.str.size();
      memcpy(bp,pp.str,ll*sizeof(wchar_t));
      bp+=ll;
      ++start.para;
      len-=ll;
    }
#ifdef UNICODE
    str.ReleaseBuffer(bp-result);
#else
    str=Unicode::ToCS(tmp);
#endif
    return true;
  }
  return false;
}

void CTView::OnTimer(UINT nIDEvent) {
  if (nIDEvent==1)
    SaveInfo();
  CWnd ::OnTimer(nIDEvent);
}

void CTView::OnUpdateGoto(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CTView::OnGoto() {
  CString   s;
  if (GetUserInput(_T("Position"),_T("Position"),s,this)) {
    FilePos p;
    if (s.GetLength()>0 && s[s.GetLength()-1]==_T('%')) {
      int   perc=0;
      if (_stscanf(s,_T("%d"),&perc)>0)
	MovePercent(perc);
    } else if (_stscanf(s,_T("%d:%d"),&p.para,&p.off)>0 && p.para>=0 && p<m_formatter->Eof()) {
      m_formatter->AdjustPos(p);
      PushPos();
      MoveAbs(p);
    }
  }
}

void  CTView::MovePercent(int p) {
  if (p>=0 && p<=100) {
    FilePos   pp;
    pp.para=p*m_formatter->Eof().para/100;
    PushPos();
    MoveAbs(pp);
  }
}

void CTView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) {
  if (nChar>=_T('0') && nChar<=_T('9')) {
    if (m_inpmode==2)
      m_userinp2=m_userinp2*10+nChar-_T('0');
    else {
      m_userinp1=m_userinp1*10+nChar-_T('0');
      m_inpmode=1;
    }
  } else if (nChar==_T(':') || nChar==_T(';')) {
    m_inpmode=2;
  } else if (nChar==_T('=')) {
    if (m_inpmode) {
      FilePos p(m_userinp1,m_userinp2);
      m_formatter->AdjustPos(p);
      PushPos();
      MoveAbs(p);
      m_userinp1=m_userinp2=m_inpmode=0;
    }
  } else if (nChar==_T('p') || nChar==_T('P')) {
    if (m_inpmode) {
      MovePercent(m_userinp1);
      m_userinp1=m_userinp2=m_inpmode=0;
    }
  }
  CWnd ::OnChar(nChar, nRepCnt, nFlags);
}
