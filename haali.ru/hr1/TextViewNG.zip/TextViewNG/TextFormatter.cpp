/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: TextFormatter.cpp,v 1.47 2002/04/06 22:18:02 mike Exp $
 * 
 */

#include "TextFormatter.h"
#include "TextViewNG.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#ifndef MAXINT
#define	MAXINT	0x7fffffff
#endif

#define	FBIG_ADD	  4
#define FSMALL_ADD	  -1

TextFormatter::TextFormatter(TextFile *tf) :
    m_tf(tf),
    m_width(1),
    m_indent(10),
    m_height(1),
    m_pages(1),
    m_justified(false),
    m_hyphenate(false),
    m_hllen(0)
{
  m_junk.flags=Line::first|Line::last;
}

void  TextFormatter::GetTextExtent(CFDC& dc,Paragraph& line,int off,
				   int width,int& nch,int *dx,int& lh,int& lb)
{
  const wchar_t	  *sp=line.str;
  Attr	  *att=line.cflags+off;
  int	  len=nch-off;
  int	  xoff=0;
  sp+=off;
  nch=0;
  while (len>0 && width>0) {
    int	  i;
    Attr  curatt=att[0];
    for (i=1;i<len && att[i].fontflags==curatt.fontflags;++i);
    SIZE  sz;
    int	  n=0;
    dc.SelectFont(curatt.fsize,curatt.fontattr(),true);
    int	  fh,fa;
    dc.GetFontSize(fh,fa);
    if (lh<fh) {
      lh=fh;
      lb=fa;
    }
    dc.GetTextExtent(sp,i,width,n,dx,sz);
    if (n==0)
      break;
    for (int j=0;j<n;++j)
      dx[j]+=xoff;
    nch+=n;
    if (i==len)
      break;
    xoff+=sz.cx;
    width-=sz.cx;
    dx+=n;
    sp+=n;
    att+=n;
    len-=n;
  }
}

void	CopyAttr(Attr *dest,const Attr *src,DWORD len) {
  while (len--)
    (*dest++=*src++).hyphen=false;
}

static void AdjustIndent(int& width,int& indent,int li,int ri,int lpx) {
  int pli=lpx*li/25;
  int pri=lpx*ri/25;
  if (width-pli<50)
    pli=width-50;
  width-=pli;
  indent+=pli;
  width-=pri;
  if (width<50)
    width=50;
}

// the formatter's core, wraps the line and justifies it if needed
int	    TextFormatter::WrapLine(CFDC& dc,Paragraph& pp,
				    FilePos& pos,LineArray& la,int maxh)
{
  if (maxh<=0)
    return 0;
  if (pp.len==0 || (pp.len==1 && pp.str[0]==_T(' '))) {
    dc.SelectFont(0,0);
    int	  fh,fa;
    dc.GetFontSize(fh,fa);
    if (fh>maxh)
      return -1;
    Line    l;
    l.pos=pos;
    l.flags=Line::first|Line::last|Line::defstyle;
    l.height=fh;
    l.base=fa;
    la.Add(l);
    pos.off=pp.len;
    return l.height;
  }
  if (m_hyphenate)
    pp.Hyphenate();
  const wchar_t	    *str=pp.str;
  int		    len=pp.len;
  Buffer<int>	    dx(len+1);
  int		    hwidth=4; // XXX
  int		    toth=0;
  while (toth<maxh && pos.off<len) {
    // 1. get text size
    int	      nch=len;
    int	      curwidth=m_width;
    int	      ispace=0;
    if (pos.off==0 && (pp.flags&(Paragraph::center|Paragraph::right))==0) {
      curwidth-=m_indent;
      ispace+=m_indent;
    }
    AdjustIndent(curwidth,ispace,pp.lindent,pp.rindent,dc.GetLPX());
    dx[0]=0;
    int	lh=1,lbase=1;
    GetTextExtent(dc,pp,pos.off,curwidth,nch,dx+1,lh,lbase);
    if (toth+lh>maxh)
      return -1;
    if (nch==0)
      nch=1;
    // 2. do word wrap
    bool  addhyp=false;
    if (nch+pos.off<pp.str.size()) {
      int   i;
      for (i=nch;i>0 && str[pos.off+i]!=_T(' ');--i)
	if (m_hyphenate && pp.cflags[pos.off+i].hyphen &&
	    dx[i]+hwidth<=curwidth) {
	  addhyp=true;
	  break;
	}
      if (i>0)
	nch=i;
      else
	addhyp=false;
    }
    // insert it into line list
    if (pos.off==0 && nch==pp.str.size()) { // got full line
      Line    l(str,len,false);
      l.pos=pos;
      l.flags=Line::first|Line::last;
      l.ispace=ispace;
      l.height=lh;
      l.base=lbase;
      if (dx[nch]<curwidth) {
	if (pp.flags&Paragraph::center)
	  l.ispace+=(curwidth-dx[nch])/2;
	else if (pp.flags&Paragraph::right)
	  l.ispace+=curwidth-dx[nch];
      }
      CopyAttr(l.attr,pp.cflags,len);
      for (int j=0;j<len;++j)
	l.dx[j]=dx[j+1]-dx[j];
      la.Add(l);
      pos.off=len;
    } else {
      Line    l(str+pos.off,nch,addhyp);
      if (addhyp)
	l.str[nch]=_T('-');
      l.pos=pos;
      l.ispace=ispace;
      l.height=lh;
      l.base=lbase;
      l.flags=0;
      if (pos.off==0)
	l.flags|=Line::first;
      if (pos.off+nch==pp.str.size())
	l.flags|=Line::last;
      for (int j=0;j<nch;++j)
	l.dx[j]=dx[j+1]-dx[j];
      if (addhyp)
	l.dx[nch]=hwidth;
      // 3. justify/center text if needed
      if (dx[nch]<curwidth) {
	if (addhyp)
	  curwidth-=hwidth;
	if (pp.flags&Paragraph::center) {
	  l.ispace+=(curwidth-dx[nch])/2;
	} else if (pp.flags&Paragraph::right) {
	  l.ispace+=curwidth-dx[nch];
	} else if ((m_justified || pp.flags&Paragraph::justify) &&
		    !(l.flags&Line::last))
	{
	  // count spaces in string
	  int   nspc=0,i;
	  for (i=0;i<nch;++i)
	    if (_T(' ')==str[pos.off+i])
	      ++nspc;
	  // and distribute extra width to them
	  if (nspc>0) {
	    int   addw=(curwidth-dx[nch])/nspc;
	    int   extraddw=curwidth-dx[nch]-addw*nspc;
	    for (i=0;i<nch;++i) {
	      if (str[pos.off+i]==_T(' ')) {
		l.dx[i]+=addw;
		if (extraddw) {
		  ++l.dx[i];
		  --extraddw;
		}
	      }
	    }
	  }
	}
      }
      CopyAttr(l.attr,pp.cflags+pos.off,nch);
      if (addhyp)
	l.attr[nch]=l.attr[nch-1];
      la.Add(l);
      pos.off+=nch;
      while (pos.off<len && str[pos.off]==_T(' '))
	++pos.off;
    }
    toth+=lh;
  }
  return toth;
}

bool	    TextFormatter::FormatFwd(CFDC& dc,FilePos start) {
  if (start.para>=m_tf->Length())
    return false; // at eof
  m_lines.RemoveAll();
  m_top=start;
  for (int page=0;page<m_pages;++page) {
    int h=0;
    int beg=m_lines.GetSize();
    while (h<m_height && start.para<m_tf->Length()) {
      Paragraph   para(m_tf->GetParagraph(start.para));
      int lh=WrapLine(dc,para,start,m_lines,m_height-h);
      if (lh<0)
	break;
      AdjustPos(start);
      h+=lh;
    }
    m_pagelen.SetAtGrow(page,m_lines.GetSize()-beg);
  }
  m_bot=start;
  Highlight();
  return true;
}

bool	    TextFormatter::FormatBack(CFDC& dc,FilePos start,FilePos prev_top) {
  AdjustPos(start,true);
  if (start.para==0 && start.off==0)
    return false; // at the top
  m_lines.RemoveAll();
  m_bot=start;
  for (int page=m_pages-1;page>=0;--page) {
    LineArray   tmp;
    FilePos     pos=start;
    int	      h=0;
    // while there are still paragrahs before
    while (h<m_height && (pos.para>0 || pos.off>0)) {
      // format entire paragraph
      LineArray cp;
      Paragraph   para(m_tf->GetParagraph(pos.para));
      if (pos.off<para.len) // double check args
	para.len=pos.off;
      else
	pos.off=para.len;
      WrapLine(dc,para,FilePos(pos.para,0),cp,32768);
      // insert the formatted paragraph at start of list
      tmp.InsertAt(0,&cp);
      for (int i=0;i<cp.GetSize();++i)
	h+=cp[i].height;
      pos.off=0;
      AdjustPos(pos,true);
    }
    // delete extra lines
    int j;
    // remove top lines
    for (h=0,j=tmp.GetUpperBound();j>=0 && h+tmp[j].height<=m_height;--j)
      h+=tmp[j].height;
    if (j<tmp.GetUpperBound()) {
      if (j>=0 && prev_top!=0 && tmp[j+1].pos>=prev_top) {
	--j;
	tmp.RemoveAt(0,j+1);
	// now remove bottom lines
	for (h=j=0;j<tmp.GetSize() && h+tmp[j].height<=m_height;++j)
	  h+=tmp[j].height;
	if (j<tmp.GetSize())
	  tmp.RemoveAt(j,tmp.GetSize()-j);
      } else
	tmp.RemoveAt(0,j+1);
    }
    // save lines
    m_lines.InsertAt(0,&tmp);
    m_pagelen.SetAtGrow(page,tmp.GetSize());
    start=m_lines[0].pos;
    if (start.para==0 && start.off==0) // we reached the top of file
      return FormatFwd(dc,FilePos(0,0));
  }
  // save positions
  m_top=m_lines[0].pos;
  Highlight();
  return true;
}

void	    TextFormatter::AdjustPos(FilePos& p,bool back) {
  if (back) {
    if (p.para>0) {
      if (p.para>=m_tf->Length()) {
	if (m_tf->Length()>0) {
	  p.para=m_tf->Length()-1;
	  p.off=m_tf->GetPLength(p.para);
	}
      } else {
	if (p.off==0) {
	  --p.para;
	  p.off=m_tf->GetPLength(p.para);
	}
      }
    }
  } else {
    if (p.para>=0 && p.para<m_tf->Length() && p.off>=m_tf->GetPLength(p.para)) {
      p.off=0;
      p.para++;
    }
  }
}

void	    TextFormatter::SetSize(int width,int height,int pages) {
  if (width<=m_indent)
    width=m_indent+1;
  if (height<1)
    height=1;
  if (pages<1)
    pages=1;
  m_width=width; m_height=height; m_pages=pages;
}

bool TextFormatter::AtTop()
{
  FilePos   p(m_top);
  AdjustPos(p,true);
  return p.off==0 && p.para==0;
}

bool TextFormatter::AtEof()
{
  FilePos   p(m_bot);
  AdjustPos(p);
  return p.para>=m_tf->Length();
}

static bool  intersect(int a,int la,int b,int lb,int& i,int& li) {
  if (a>=b && a<b+lb) {
    i=a-b;
    if (la>b+lb-a)
      li=b+lb-a;
    else
      li=la;
    return true;
  }
  if (b>=a && b<a+la) {
    i=0;
    if (lb>a+la-b)
      li=a+la-b;
    else
      li=lb;
    return true;
  }
  return false;
}

void TextFormatter::Highlight() {
  if (!m_hllen)
    return;

  FilePos   hls(m_hlstart);
  int	    hll=m_hllen;
  for (int i=0;i<m_lines.GetSize();++i)
    if (hls.para==m_lines[i].pos.para) {
      int beg,len;
      if (hls.off-m_lines[i].pos.off<m_lines[i].real_len &&
	intersect(hls.off,hll,m_lines[i].pos.off,m_lines[i].str.size(),beg,len))
      {
	int top=beg+len;
	while (beg<top)
	  m_lines[i].attr[beg++].hibg=true;
	m_lines[i].flags&=~Line::defstyle;
      } else
	m_lines[i].CheckStyle();
      // advance our pointer
      if (i<m_lines.GetSize()-1 && m_lines[i+1].pos.para>hls.para &&
	    hls.off+hll>m_tf->GetPLength(hls.para))
      {
	hll-=m_tf->GetPLength(hls.para)-hls.off;
	++hls.para;
	hls.off=0;
      }
    } else
      m_lines[i].CheckStyle();
}

bool TextFormatter::SetHighlight(FilePos pos,int len) {
  if (m_hllen==len && (!len || pos==m_hlstart)) // avoid extra work
    return false;
  // remove highlighting
  for (int i=0;i<m_lines.GetSize();++i) {
    for (int j=0;j<m_lines[i].attr.size();++j)
      m_lines[i].attr[j].hibg=false;
  }
  m_hlstart=pos;
  m_hllen=len;
  Highlight();
  return true;
}

void  Line::CheckStyle() {
  Attr	*p=attr;
  Attr	*e=p+attr.size();
  while (p<e)
    if ((*p++).wa) {
      flags&=~defstyle;
      return;
    }
  flags|=defstyle;
}

int TextFormatter::Distance(const FilePos& a,const FilePos& b,int& pl)
{
  pl=0;
  FilePos start(a), end(b);
  bool	  sign=false;
  if (a>b) {
    start=b;
    end=a;
    sign=true;
  }
  // check bounds
  if (start.para<0)
    start.para=0;
  if (start.para>m_tf->Length())
    start=Eof();
  if (start.off<0)
    start.off=0;
  if (start.off>m_tf->GetPLength(start.para))
    start.off=m_tf->GetPLength(start.para);
  if (end.para<0)
    end.para=0;
  if (end.para>m_tf->Length())
    end=Eof();
  if (end.off<0)
    end.off=0;
  if (end.off>m_tf->GetPLength(end.para))
    end.off=m_tf->GetPLength(end.para);
  // calc distance now
  int	dist;
  if (start.para==end.para) {
    dist=end.off-start.off;
    pl=1;
  } else {
    dist=m_tf->GetPLength(start.para)-start.off;
    ++start.para;
    ++pl;
    while (start.para<end.para) {
      dist+=m_tf->GetPLength(start.para);
      ++start.para;
      ++pl;
    }
    dist+=end.off;
  }
  return sign ? -dist : dist;
}