/*
 * Copyright (c) 2001,2002 Mike Matsnev.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Absolutely no warranty of function or purpose is made by the author
 *    Mike Matsnev.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * $Id: TextParser.h,v 1.29 2002/04/06 21:59:10 mike Exp $
 * 
 */

#if !defined(AFX_TEXTPARSER_H__2F6237F5_E47E_45B8_9597_CB0AAAA1413C__INCLUDED_)
#define AFX_TEXTPARSER_H__2F6237F5_E47E_45B8_9597_CB0AAAA1413C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BufFile.h"
#include "ptr.h"
#include "Bookmarks.h"

// unified attributes
struct Attr { // XXX assumes little endian byteorder and M$ extensions
  // bit fields
  union {
    struct {
      signed char   fsize:6;  // font size
      unsigned char bold:1;   // bold flag
      unsigned char italic:1; // italic flag
      unsigned char underline:1; // underline flag
      unsigned char color:3;  // color index
      unsigned char hibg:1;   // highlight background

      unsigned char hyphen:1; // can break word here
      
      unsigned char spare:2;  // spare bits
    };
    BYTE	  fontflags;
    WORD	  wa;
  };
  BYTE	fontattr() { return (wa>>6)&0x7; } // XXX
  enum {
    BOLD = 1,
    ITALIC = 2,
    UNDERLINE = 4
  };
};

struct Paragraph {
  Buffer<wchar_t> str;
  Buffer<Attr>	cflags;
  int		len;
  BYTE		flags;
  int		lindent,rindent;
  struct Link { // notes only for now
    DWORD     off; // offset into str
    DWORD     len; // number of chars
    int	      target; // target footnote or paragraph
  };
  Buffer<Link>	links;
  enum {
    right=1,
    center=2,
    justify=4,
    hypdone=128
  };
  Paragraph() : len(0), flags(0), lindent(0), rindent(0) { }
  Paragraph(int l) : str(l), cflags(l), len(l), flags(0), lindent(0), rindent(0) { }
  Paragraph(const Paragraph& p) : str(p.str), cflags(p.cflags), len(p.len),
    flags(p.flags), lindent(p.lindent), rindent(p.rindent), links(p.links) { }
  Paragraph& operator=(const Paragraph& p) {
    str=p.str;
    cflags=p.cflags;
    len=p.len;
    flags=p.flags;
    links=p.links;
    lindent=p.lindent;
    rindent=p.rindent;
    return *this;
  }
  void Hyphenate();
};

class TextParser
{
public:
  class Meter {
  public:
    virtual ~Meter() { }
    virtual void  SetMax(DWORD max) = 0;
    virtual void  SetCur(DWORD cur) = 0;
  };

protected:
  CBufFile	  *m_fp;
  int		  m_format;
  int		  m_encoding;
  Meter		  *m_mm;
  Bookmarks	  *m_bmk;

  TextParser(Meter *m,CBufFile *fp,Bookmarks *bmk) : m_fp(fp), m_mm(m), m_bmk(bmk) {
    if (m_mm) m_mm->SetMax(m_fp->size());
  }

  void		ProgSetCur(DWORD cur) { if (m_mm) m_mm->SetCur(cur); }

public:
  virtual ~TextParser() { }

  int			GetFormat() { return m_format; }
  int			GetEncoding() { return m_encoding; }

  virtual Paragraph	GetParagraph(int para) = 0;
  virtual int		Length() = 0; // in paragraphs
  virtual int		GetPLength(int para) = 0;

  // footnotes
  virtual Paragraph	GetNoteParagraph(int note,int para) = 0;
  virtual int		GetNoteLength(int note) = 0; // in paragraphs
  virtual int		GetNotePLength(int note,int para) = 0;

  // bookmarks
  virtual bool		SaveBookmarks(Bookmarks& bm,CFile& fp) = 0;
  
  static int		DetectFormat(CBufFile *fp);
  static int		GetNumFormats();
  static const TCHAR	*GetFormatName(int format);
  static TextParser	*Create(Meter *m,CBufFile *fp,int format,int encoding,Bookmarks *bma);
};

#endif // !defined(AFX_TEXTPARSER_H__2F6237F5_E47E_45B8_9597_CB0AAAA1413C__INCLUDED_)
